; WaterPyDesktop — Windows installer (NSIS 3)
; Build:  makensis /DVERSION=0.6.0 installer\WaterPyDesktop.nsi
; Expects the PyInstaller one-folder build in ..\dist\WaterPyDesktop (override with /DSOURCE=...)
Unicode true
!include "MUI2.nsh"
!include "x64.nsh"
!include "FileFunc.nsh"

!ifndef VERSION
  !define VERSION "0.6.0"
!endif
!ifndef SOURCE
  !define SOURCE "..\dist\WaterPyDesktop"
!endif
!ifndef OUTDIR
  !define OUTDIR "..\dist"
!endif
!define APP "WaterPyDesktop"
!define PUBLISHER "WaterPyDesktop"
!define UNINST_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APP}"

Name "${APP} ${VERSION}"
OutFile "${OUTDIR}\${APP}-${VERSION}-setup.exe"
InstallDir "$PROGRAMFILES64\${APP}"
InstallDirRegKey HKLM "Software\${APP}" "InstallDir"
RequestExecutionLevel admin
SetCompressor /SOLID lzma
SetCompressorDictSize 64
BrandingText "${APP} ${VERSION} Professional Edition"

VIProductVersion "${VERSION}.0"
VIAddVersionKey "ProductName" "${APP}"
VIAddVersionKey "CompanyName" "${PUBLISHER}"
VIAddVersionKey "FileDescription" "${APP} Setup"
VIAddVersionKey "FileVersion" "${VERSION}"
VIAddVersionKey "ProductVersion" "${VERSION}"
VIAddVersionKey "LegalCopyright" "${PUBLISHER}"

!define MUI_ICON "..\waterpy\resources\waterpy.ico"
!define MUI_UNICON "..\waterpy\resources\waterpy.ico"
!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TEXT "Setup will install ${APP} ${VERSION}, a visual PySide6 GUI builder with a plugin SDK and AI assistant.$\r$\n$\r$\nTo run and build your own applications from the IDE you also need Python 3.12 (64-bit) with:  pip install PySide6 pyinstaller$\r$\n$\r$\nClick Next to continue."
!define MUI_FINISHPAGE_RUN "$INSTDIR\${APP}.exe"
!define MUI_FINISHPAGE_LINK "Get Python 3.12 (needed for Run / Build EXE)"
!define MUI_FINISHPAGE_LINK_LOCATION "https://www.python.org/downloads/windows/"

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "license.txt"
!insertmacro MUI_PAGE_COMPONENTS
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

Section "${APP} (required)" SecMain
  SectionIn RO
  SetOutPath "$INSTDIR"
  File /r "${SOURCE}\*.*"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  WriteRegStr HKLM "Software\${APP}" "InstallDir" "$INSTDIR"
  WriteRegStr HKLM "${UNINST_KEY}" "DisplayName" "${APP}"
  WriteRegStr HKLM "${UNINST_KEY}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKLM "${UNINST_KEY}" "Publisher" "${PUBLISHER}"
  WriteRegStr HKLM "${UNINST_KEY}" "DisplayIcon" "$INSTDIR\${APP}.exe"
  WriteRegStr HKLM "${UNINST_KEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKLM "${UNINST_KEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegStr HKLM "${UNINST_KEY}" "QuietUninstallString" '"$INSTDIR\Uninstall.exe" /S'
  WriteRegDWORD HKLM "${UNINST_KEY}" "NoModify" 1
  WriteRegDWORD HKLM "${UNINST_KEY}" "NoRepair" 1
  ${GetSize} "$INSTDIR" "/S=0K" $0 $1 $2
  WriteRegDWORD HKLM "${UNINST_KEY}" "EstimatedSize" $0
SectionEnd

Section "Start menu shortcuts" SecStart
  SetShellVarContext all
  CreateDirectory "$SMPROGRAMS\${APP}"
  CreateShortCut "$SMPROGRAMS\${APP}\${APP}.lnk" "$INSTDIR\${APP}.exe"
  CreateShortCut "$SMPROGRAMS\${APP}\Uninstall ${APP}.lnk" "$INSTDIR\Uninstall.exe"
SectionEnd

Section "Desktop shortcut" SecDesktop
  SetShellVarContext all
  CreateShortCut "$DESKTOP\${APP}.lnk" "$INSTDIR\${APP}.exe"
SectionEnd

Section "Open .wpplugin and .ui files with ${APP}" SecAssoc
  WriteRegStr HKLM "Software\Classes\.wpplugin" "" "${APP}.Plugin"
  WriteRegStr HKLM "Software\Classes\${APP}.Plugin" "" "WaterPyDesktop plugin package"
  WriteRegStr HKLM "Software\Classes\${APP}.Plugin\DefaultIcon" "" "$INSTDIR\${APP}.exe,0"
  WriteRegStr HKLM "Software\Classes\${APP}.Plugin\shell\open\command" "" '"$INSTDIR\${APP}.exe" "%1"'
  WriteRegStr HKLM "Software\Classes\.ui\OpenWithProgids" "${APP}.QtForm" ""
  WriteRegStr HKLM "Software\Classes\${APP}.QtForm" "" "Qt Designer form"
  WriteRegStr HKLM "Software\Classes\${APP}.QtForm\shell\open\command" "" '"$INSTDIR\${APP}.exe" "%1"'
  System::Call 'shell32::SHChangeNotify(i 0x08000000, i 0, p 0, p 0)'
SectionEnd

!insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN
  !insertmacro MUI_DESCRIPTION_TEXT ${SecMain} "The IDE, bundled plugins, examples and the Plugin SDK."
  !insertmacro MUI_DESCRIPTION_TEXT ${SecStart} "Shortcuts in the Start menu."
  !insertmacro MUI_DESCRIPTION_TEXT ${SecDesktop} "A shortcut on the desktop."
  !insertmacro MUI_DESCRIPTION_TEXT ${SecAssoc} "Double-click .wpplugin packages to install them; open Qt Designer .ui files as new forms."
!insertmacro MUI_FUNCTION_DESCRIPTION_END

Function .onInit
  ${IfNot} ${RunningX64}
    MessageBox MB_ICONSTOP "${APP} requires 64-bit Windows 10 or later."
    Abort
  ${EndIf}
  SetRegView 64
FunctionEnd

Function un.onInit
  SetRegView 64
FunctionEnd

Section "Uninstall"
  SetShellVarContext all
  Delete "$DESKTOP\${APP}.lnk"
  RMDir /r "$SMPROGRAMS\${APP}"
  RMDir /r "$INSTDIR"
  DeleteRegKey HKLM "${UNINST_KEY}"
  DeleteRegKey HKLM "Software\${APP}"
  DeleteRegKey HKLM "Software\Classes\${APP}.Plugin"
  DeleteRegKey HKLM "Software\Classes\${APP}.QtForm"
  DeleteRegValue HKLM "Software\Classes\.ui\OpenWithProgids" "${APP}.QtForm"
  ReadRegStr $0 HKLM "Software\Classes\.wpplugin" ""
  StrCmp $0 "${APP}.Plugin" 0 +2
    DeleteRegKey HKLM "Software\Classes\.wpplugin"
  System::Call 'shell32::SHChangeNotify(i 0x08000000, i 0, p 0, p 0)'
SectionEnd
