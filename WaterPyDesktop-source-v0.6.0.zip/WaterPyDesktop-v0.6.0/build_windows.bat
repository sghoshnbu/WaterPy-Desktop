@echo off
rem Builds dist\WaterPyDesktop\WaterPyDesktop.exe and, if NSIS is installed, dist\WaterPyDesktop-<version>-setup.exe
setlocal
cd /d "%~dp0"
set /p VERSION=<VERSION
if not exist .venv\Scripts\python.exe (
  py -3.12 -m venv .venv
  if errorlevel 1 goto :error
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 goto :error
python -m PyInstaller --noconfirm --clean --windowed --onedir --name WaterPyDesktop ^
  --icon waterpy\resources\waterpy.ico ^
  --add-data "waterpy\resources;waterpy\resources" ^
  --add-data "plugins;plugins" --add-data "sdk;sdk" --add-data "examples;examples" ^
  --add-data "README.md;." --add-data "PLUGIN_SDK.md;." --add-data "CHANGELOG.md;." ^
  --collect-submodules waterpy ^
  main.py
if errorlevel 1 goto :error
echo.
echo EXE built: dist\WaterPyDesktop\WaterPyDesktop.exe

set MAKENSIS=
where makensis >nul 2>nul && set MAKENSIS=makensis
if not defined MAKENSIS if exist "%ProgramFiles(x86)%\NSIS\makensis.exe" set MAKENSIS="%ProgramFiles(x86)%\NSIS\makensis.exe"
if not defined MAKENSIS if exist "%ProgramFiles%\NSIS\makensis.exe" set MAKENSIS="%ProgramFiles%\NSIS\makensis.exe"
if defined MAKENSIS (
  pushd installer
  %MAKENSIS% /V2 /DVERSION=%VERSION% WaterPyDesktop.nsi
  popd
  if errorlevel 1 goto :error
  echo Installer built: dist\WaterPyDesktop-%VERSION%-setup.exe
) else (
  echo NSIS not found - skipped setup.exe. Install NSIS 3 from https://nsis.sourceforge.io and run this again.
)
pause
exit /b 0
:error
echo Build failed. Read the error above, then retry.
pause
exit /b 1
