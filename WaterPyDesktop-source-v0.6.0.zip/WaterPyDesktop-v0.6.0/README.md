# WaterPyDesktop 0.6.0 — Professional Edition

A visual GUI builder for **native PySide6** desktop applications on Windows: design forms by drag-and-drop,
write event code, generate clean Python, run it, and package it as an EXE — with an **extensible plugin SDK**
and a **multi-provider AI assistant** that can design forms, write handlers, and fix errors.

## What's new in 0.6.0
* **Import**: Qt Designer `.ui` forms (containers flattened, layouts kept), WaterPy layouts/templates (`.json`),
  projects from ZIP, **CSV into a Grid** (headers + cell data), items from text/CSV into lists and combos.
* **Export**: PyQt6 source, WaterPy layout, static **HTML mockup**, **form image (PNG / PDF)**, **form
  documentation** (Markdown / HTML: controls, handlers, helper methods, tab order), *Save form as template*.
* **Professional tools**: live **Preview** (F6) inside the IDE, **Find / Replace** with regex (Ctrl+F / Ctrl+H),
  **Go to line / symbol**, **syntax check** (Ctrl+F7), **snippet library** (dialogs, files, CSV, SQLite, timers…),
  **Tab order** editor, window icon, grid cell data.
* **Build Settings**: app name, version, company, copyright, icon, one-file or folder, console, hidden imports —
  written into the EXE's Windows file properties.
* **Setup.exe builder** for your apps (Run → Setup.exe): Inno Setup 6 or NSIS 3, Start-menu/desktop shortcuts,
  uninstaller, per-user or all-users install, licence page.
* **WaterPyDesktop itself ships as `WaterPyDesktop.exe` + `WaterPyDesktop-<version>-setup.exe`** — see
  `docs/BUILDING.md` (local `build_windows.bat` or the included GitHub Actions workflow).

## Added in 0.5.0
* **41 components** in a categorised, searchable toolbox (19 new built-ins + 3 from the *Extra Controls* plugin):
  Radio Button, Toggle Button, Command Link, Hyperlink, Password Box, Plain Text Edit, Double Spin Box, Slider,
  Dial, Font Combo, Date / Time / Date-Time Edit, Key Sequence, Group Box, LCD Number, Calendar, Tree View,
  Web View (Qt WebEngine with fallback) and a real Media player (Qt Multimedia) — plus Toggle Switch, Star
  Rating and Card Panel.
* **Professional designer**: multi-select (Ctrl/Shift-click, rubber band), **undo/redo**, cut/copy/paste,
  duplicate, align & distribute, same size, z-order, arrow-key nudging, form settings (title, size, colour),
  outline view, minimap and a WYSIWYG canvas that stays light in dark IDE themes.
* **Schema-driven Properties** for every component; **multiple events per control** with a signal list,
  per-signal handlers, and class-level helper methods.
* **Code generator 2**: auto-imports any `Q…` class you use in event code, `resource_path()` for assets in
  PyInstaller builds, readable `on_<control>_<signal>` handlers, protection for manual source edits.
* **Code editor** with line numbers, syntax highlighting, smart indent, Ctrl+/ comments, go-to-error.
* **Templates**: Login, Contact, CRUD records, Settings, Dashboard (+ plugin templates).
* **Plugin system 2.0 + SDK**: package plugins with manifests, hot reload, full roll-back of contributions,
  per-plugin settings, events, exporters, code transforms, AI actions/providers, `.wpplugin` installer,
  scaffolder/validator/packager CLI and *New Plugin* wizard. API 1 plugins still work.
* **AI integration**: Anthropic Claude, OpenAI, Google Gemini, Ollama (local, free), any OpenAI-compatible
  server, or offline templates. Streaming chat with task modes, *Apply layout to designer*, diff-reviewed code
  changes, *Fix with AI* from the console, *Write with AI* for event handlers, teaching-style explanations.
* Docked, rearrangeable layout (saved between sessions), 4 themes, recent projects, auto-save, ZIP export.

## Setup (Windows)
Use standard 64-bit **Python 3.12**.

```bat
py -3.12 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python main.py
```
Optional: `pip install keyring` stores AI keys in Windows Credential Manager; `pip install black` enables
*Code Tools → Format source*.

## A five-minute tour
1. Drag components from **Toolbox** (or double-click), or pick a **Template**, or press **AI Design**
   (Ctrl+Shift+A) and describe the screen.
2. Edit **Properties**; with nothing selected you edit the window (title, size, background).
3. Double-click a control (or use the **Events** tab), choose a signal and type the handler body. Put shared
   logic in **Helper methods** and call it as `self.method()`.
4. **Generate** (F7) to see the Python source; **Run** (F5). If it crashes, use **Go to line** or
   **✦ Fix with AI** in the Console.
5. **Save** writes a runnable folder (`main.py`, `.waterpy.json`, `requirements.txt`, `README.md`, `assets/`).
   **Build EXE** (Ctrl+B) runs PyInstaller into `build_output/dist/<App>/`.

Manual edits in *Python Source* are protected: the designer stops overwriting the file and shows a banner
with **Regenerate from designer** when you want to go back.

## AI assistant
Open **AI → AI Settings…** (or ⚙ in the assistant). Choose a provider, paste a key (*Get a key…* opens the
provider's page) and **Test connection**. Environment variables `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`,
`GEMINI_API_KEY` are detected automatically. Model names are editable, so new models work without an update.

| Provider | Needs | Notes |
|---|---|---|
| Anthropic Claude | API key | default `claude-sonnet-5-5` |
| OpenAI | API key | default `gpt-4.1-mini` |
| Google Gemini | API key | default `gemini-2.5-flash` |
| Ollama | Ollama installed locally | free & private; e.g. `ollama pull qwen2.5-coder` |
| OpenAI-compatible | base URL (+ key) | LM Studio, OpenRouter, Groq, vLLM… |
| Offline | nothing | template-based form design and app generation |

Task modes: *Chat, Design form, Generate app, Modify source, Fix error, Write event handler, Explain
(teaching), Code review*. Choose what context is sent (form, source, console). Code changes are always shown
as a diff first; layouts can replace or be added to the form; everything is undoable. Only the provider you
select receives your project context.

## Plugins
*Plugins → Plugin Manager* lists bundled and user plugins with status, errors and details; install `.py`,
folders or `.wpplugin` archives; enable/disable without restarting; reload while developing; validate and
package. *Plugins → New Plugin…* scaffolds a plugin from five templates. Full reference: **PLUGIN_SDK.md**.

## Build the IDE itself
Run `build_windows.bat` → `dist\WaterPyDesktop\WaterPyDesktop.exe` and (with NSIS installed)
`dist\WaterPyDesktop-<version>-setup.exe`. No Windows PC? Use the GitHub Actions workflow — see `docs/BUILDING.md`.
When frozen, **Run/Build** use the project's `.venv`, the IDE's `.venv`, `python` on PATH, or `py -3.12`.

## Tests
```bat
python -m pip install -r requirements-dev.txt
python -m pytest tests
```
88 headless tests cover code generation for every component (and run the generated app), AI parsing,
streaming against mock servers for all providers, the plugin lifecycle for every SDK template, installer
safety, designer history/clipboard/alignment, and project round-trips.

## Keyboard shortcuts
F5 run · F6 preview · Shift+F5 stop · F7 generate · Ctrl+F7 check syntax · Ctrl+B build · Ctrl+Shift+B setup.exe ·
Ctrl+F / Ctrl+H find / replace · Ctrl+G go to line · Ctrl+Shift+O go to symbol · F12 design/source · Ctrl+Z/Y undo/redo ·
Ctrl+X/C/V/D cut/copy/paste/duplicate · Del delete · arrows nudge (Shift = grid, Alt = resize) · F2 rename ·
Ctrl+Shift+A AI design · Ctrl+Enter send to AI · Ctrl+/ comment · Ctrl+Shift+R reload plugins.

## Limitations
* Controls are positioned absolutely; containers (Group Box, Tab, Card) are visual and do not yet own child
  controls or layouts.
* The design canvas shows placeholders for Web View, Media and Timer.
* Builds are platform-specific: build Windows executables on Windows.
* Plugins are trusted in-process code and are not sandboxed.
* AI output can be wrong — review diffs and test generated code before distributing.

See `CHANGELOG.md` for the full history.

## Screenshots
![Designer](docs/designer-properties.png)
![AI form design](docs/ai-form-design.png)
![Events panel](docs/events-panel.png)
