"""AI Toolkit — extra one-click AI actions built on the Plugin SDK's AI API."""
from PySide6.QtWidgets import QDialog, QInputDialog, QPlainTextEdit, QVBoxLayout


def register(api):
    api.register_ai_action(
        "Accessibility pass",
        "Improve accessibility of the current source: add setAccessibleName/tooltips to every input and button, "
        "sensible tab order with setTabOrder, keyboard mnemonics (&) on buttons and labels with setBuddy. "
        "Keep behaviour identical.",
        mode="modify_source", tooltip="Tooltips, accessible names, tab order and mnemonics")
    api.register_ai_action(
        "Add validation",
        "Add input validation to the current source: QIntValidator/QDoubleValidator/QRegularExpressionValidator "
        "where appropriate, required-field checks before actions run, and friendly QMessageBox warnings.",
        mode="modify_source", tooltip="Validators and required-field checks")
    api.register_ai_action(
        "Write tests",
        "Write pytest + pytest-qt tests for the current application (test file only), covering each event handler.",
        mode="chat", tooltip="Generate a pytest-qt test file")

    def translate():
        lang, ok = QInputDialog.getText(api.window, "Translate UI", "Translate all user-visible texts to which language?",
                                        text="Bengali")
        if ok and lang.strip():
            api.open_ai_panel("modify_source",
                              f"Translate every user-visible string (window title, labels, button texts, placeholders, "
                              f"messages) into {lang.strip()}. Do not change identifiers or logic.", send=True)

    api.add_menu_action("Translate UI texts…", translate, menu="AI")

    def write_readme():
        api.notify("Asking the AI to write README.md…")

        def done(text):
            directory = api.project.directory
            if directory:
                (directory / "README.md").write_text(text, encoding="utf-8")
                api.notify(f"README.md written to {directory}")
                api.log(f"README.md written to {directory}", "success")
            else:
                dlg = QDialog(api.window)
                dlg.setWindowTitle("Generated README (save the project to write it to disk)")
                dlg.resize(700, 520)
                box = QPlainTextEdit(text)
                QVBoxLayout(dlg).addWidget(box)
                dlg.exec()

        api.ask_ai("Write a concise README.md (Markdown) for this desktop application: purpose, features, how to run "
                   "(`python main.py`), how to build an EXE, and a short usage guide. Return only the Markdown.",
                   done, mode="chat")

    api.add_menu_action("Write README.md with AI", write_readme, menu="AI")
