"""Form Linter — live quality checks for the designed form, shown in a dock panel."""
import re

from PySide6.QtCore import Qt, QRect
from PySide6.QtWidgets import QLabel, QListWidget, QListWidgetItem, QVBoxLayout, QWidget

BACKGROUND_KINDS = {"Container", "Group Box", "Tab", "Rectangle", "Card Panel", "Ellipse"}
AUTO_NAME = re.compile(r"^[a-z_]+_\d+$")


def lint(project):
    issues = []
    form = project["form"]
    fw, fh = int(form.get("width", 900)), int(form.get("height", 600))
    controls = [c for c in project["controls"] if c["type"] != "Timer"]
    rects = {c["name"]: QRect(c["x"], c["y"], c["width"], c["height"]) for c in controls}
    for c in controls:
        r = rects[c["name"]]
        if r.right() > fw or r.bottom() > fh:
            issues.append(("error", c["name"], f"{c['name']} extends outside the {fw}×{fh} form"))
        if AUTO_NAME.match(c["name"]):
            issues.append(("info", c["name"], f"{c['name']}: give it a descriptive name (e.g. btn_save, txt_email)"))
        if c["type"] in ("Button", "Command Link") and not (c.get("events") or {}).get("clicked"):
            issues.append(("warning", c["name"], f"{c['name']}: button has no clicked handler"))
        if c.get("text") in ("Click Me", "Label", "Check me") and c["type"] in ("Button", "Label", "Check Box"):
            issues.append(("info", c["name"], f"{c['name']}: still shows the default text '{c['text']}'"))
        if 0 < int(c.get("font_size") or 0) < 8:
            issues.append(("warning", c["name"], f"{c['name']}: font size {c['font_size']}pt is hard to read"))
    names = list(rects)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            ra, rb = rects[a], rects[b]
            if not ra.intersects(rb):
                continue
            ka = next(c["type"] for c in controls if c["name"] == a)
            kb = next(c["type"] for c in controls if c["name"] == b)
            if (ka in BACKGROUND_KINDS and ra.contains(rb)) or (kb in BACKGROUND_KINDS and rb.contains(ra)):
                continue
            issues.append(("warning", b, f"{a} and {b} overlap"))
    return issues


def register(api):
    panel = QWidget()
    lay = QVBoxLayout(panel)
    lay.setContentsMargins(4, 4, 4, 4)
    summary = QLabel()
    view = QListWidget()
    view.setWordWrap(True)
    lay.addWidget(summary)
    lay.addWidget(view, 1)
    icons = {"error": "⛔", "warning": "⚠", "info": "ℹ"}

    def refresh(source=None, project=None):
        project = project or api.project.to_dict()
        issues = lint(project)
        view.clear()
        for level, name, text in issues:
            item = QListWidgetItem(f"{icons[level]}  {text}")
            item.setData(Qt.ItemDataRole.UserRole, name)
            view.addItem(item)
        counts = {k: sum(1 for i in issues if i[0] == k) for k in icons}
        summary.setText("✔ No issues — nice form!" if not issues else
                        f"{counts['error']} errors · {counts['warning']} warnings · {counts['info']} tips")

    def select(item):
        name = item.data(Qt.ItemDataRole.UserRole)
        canvas = api.window.canvas
        control = canvas.find(name)
        if control:
            canvas.set_selection([control])

    view.itemClicked.connect(api.safe(select))
    api.on("code.generated", refresh)
    api.add_dock_panel("Form Linter", panel, area="right")
    refresh()
