"""Extra Controls — custom-painted components contributed through the Plugin SDK.

Each component's widget class is written once as ``SUPPORT_CODE``.  That text is
(1) executed here so the designer can show a live preview, and (2) emitted once
into every generated application that uses the component.
"""
from PySide6.QtCore import Signal

from waterpy.plugin_sdk import ComponentSpec, PropertySpec
from waterpy.registry import qt_namespace

TOGGLE_CODE = '''
class ToggleSwitch(QCheckBox):
    """Modern on/off switch. Drop-in replacement for QCheckBox (toggled, isChecked…)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._on_color = QColor("#22c55e")
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def setOnColor(self, color):
        self._on_color = QColor(color)
        self.update()

    def sizeHint(self):
        return QSize(160, 30)

    def hitButton(self, pos):
        return self.contentsRect().contains(pos)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        h = min(self.height() - 2, 26)
        w = h * 1.8
        track = QRectF(1, (self.height() - h) / 2, w, h)
        p.setPen(Qt.PenStyle.NoPen)
        on = self.isChecked()
        p.setBrush(self._on_color if on else QColor("#cbd5e1"))
        if not self.isEnabled():
            p.setOpacity(0.5)
        p.drawRoundedRect(track, h / 2, h / 2)
        d = h - 6
        x = track.right() - d - 3 if on else track.left() + 3
        p.setBrush(QColor("#ffffff"))
        p.drawEllipse(QRectF(x, track.top() + 3, d, d))
        if self.text():
            p.setPen(self.palette().color(QPalette.ColorRole.WindowText))
            p.drawText(QRectF(w + 10, 0, self.width() - w - 10, self.height()),
                       Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, self.text())
        p.end()
'''

RATING_CODE = '''
class StarRating(QWidget):
    """Clickable 1–N star rating. Emits ratingChanged(int)."""
    ratingChanged = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._rating, self._maximum, self._color = 0, 5, QColor("#f59e0b")
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def rating(self):
        return self._rating

    def setRating(self, value):
        value = max(0, min(self._maximum, int(value)))
        if value != self._rating:
            self._rating = value
            self.ratingChanged.emit(value)
            self.update()

    def setMaximum(self, value):
        self._maximum = max(1, int(value))
        self.update()

    def setColor(self, color):
        self._color = QColor(color)
        self.update()

    def mousePressEvent(self, event):
        cell = self.width() / self._maximum
        self.setRating(int(event.position().x() // cell) + 1)

    def paintEvent(self, event):
        import math
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        cell = self.width() / self._maximum
        r = min(cell, self.height()) * 0.42
        for i in range(self._maximum):
            cx, cy = cell * i + cell / 2, self.height() / 2
            pts = [QPointF(cx + (r if k % 2 == 0 else r * 0.45) * math.cos(math.radians(-90 + k * 36)),
                           cy + (r if k % 2 == 0 else r * 0.45) * math.sin(math.radians(-90 + k * 36))) for k in range(10)]
            p.setPen(QPen(self._color, 1.4))
            p.setBrush(self._color if i < self._rating else Qt.BrushStyle.NoBrush)
            p.drawPolygon(QPolygonF(pts))
        p.end()
'''

_ns = dict(qt_namespace())
_ns["Signal"] = Signal
exec(TOGGLE_CODE, _ns)
exec(RATING_CODE, _ns)
ToggleSwitch, StarRating = _ns["ToggleSwitch"], _ns["StarRating"]


def _card_config(w, p):
    if not p.get("shadow", True):
        return []
    return [f"_shadow = QGraphicsDropShadowEffect({w})", "_shadow.setBlurRadius(24)", "_shadow.setOffset(0, 4)",
            "_shadow.setColor(QColor(15, 23, 42, 60))", f"{w}.setGraphicsEffect(_shadow)"]


def _card_css(p, design=False):
    bg = p.get("background") or "#ffffff"
    radius = int(p.get("radius", 12))
    extra = p.get("stylesheet") or ""
    return f"background-color: {bg}; border: 1px solid #e2e8f0; border-radius: {radius}px; {extra}".strip()


def _card_preview(widget, p, ctx):
    from PySide6.QtGui import QColor
    from PySide6.QtWidgets import QGraphicsDropShadowEffect
    if p.get("shadow", True):
        eff = QGraphicsDropShadowEffect(widget)
        eff.setBlurRadius(24)
        eff.setOffset(0, 4)
        eff.setColor(QColor(15, 23, 42, 60))
        widget.setGraphicsEffect(eff)
    else:
        widget.setGraphicsEffect(None)


SPECS = [
    ComponentSpec("Toggle Switch", "ToggleSwitch", module=None, category="Input", glyph="◐",
                  description="Modern on/off switch (custom-painted QCheckBox)", default_size=(160, 30),
                  support_code=TOGGLE_CODE, signals={"toggled": "checked: bool"},
                  properties=[PropertySpec("text", "Label", "str", "Enable feature", setter="setText"),
                              PropertySpec("checked", "Checked", "bool", False, setter="setChecked", qt_default=False),
                              PropertySpec("on_color", "On colour", "color", "#22c55e", setter="setOnColor")],
                  preview_factory=lambda parent: ToggleSwitch(parent),
                  preview_update=lambda w, p, ctx: (w.setText(p.get("text", "")), w.setChecked(bool(p.get("checked"))),
                                                    w.setOnColor(p.get("on_color") or "#22c55e"))),
    ComponentSpec("Star Rating", "StarRating", module=None, category="Input", glyph="★",
                  description="Clickable star rating (emits ratingChanged)", default_size=(150, 30),
                  support_code=RATING_CODE, extra_imports={"PySide6.QtCore": ["Signal"]},
                  signals={"ratingChanged": "rating: int"},
                  properties=[PropertySpec("maximum", "Stars", "int", 5, setter="setMaximum", minimum=1, maximum=20),
                              PropertySpec("rating", "Rating", "int", 3, setter="setRating", minimum=0, maximum=20),
                              PropertySpec("color", "Star colour", "color", "#f59e0b", setter="setColor")],
                  preview_factory=lambda parent: StarRating(parent),
                  preview_update=lambda w, p, ctx: (w.setMaximum(p.get("maximum", 5)), w.setRating(p.get("rating", 0)),
                                                    w.setColor(p.get("color") or "#f59e0b"))),
    ComponentSpec("Card Panel", "QFrame", category="Containers", glyph="▣",
                  description="Rounded card with soft drop shadow", default_size=(280, 180),
                  style=_card_css, config=_card_config, preview_update=_card_preview,
                  extra_imports={"PySide6.QtWidgets": ["QGraphicsDropShadowEffect"], "PySide6.QtGui": ["QColor"]},
                  properties=[PropertySpec("radius", "Corner radius", "int", 12, minimum=0, maximum=200),
                              PropertySpec("shadow", "Drop shadow", "bool", True)]),
]


def register(api):
    for spec in SPECS:
        api.register_component(spec)
    api.register_template("Feedback Card", [
        {"type": "Card Panel", "name": "card", "x": 24, "y": 24, "width": 372, "height": 230},
        {"type": "Label", "name": "lbl_q", "text": "How was your experience?", "x": 48, "y": 44, "width": 320, "height": 30, "font_size": 13, "bold": True},
        {"type": "Star Rating", "name": "stars", "x": 48, "y": 86, "width": 200, "height": 36, "rating": 0,
         "events": {"ratingChanged": "self.statusBar().showMessage(f'Thanks — you rated {args[0]} star(s)', 3000)"}},
        {"type": "Toggle Switch", "name": "sw_contact", "text": "You may contact me", "x": 48, "y": 138, "width": 260, "height": 30},
        {"type": "Button", "name": "btn_send", "text": "Send", "x": 268, "y": 196, "width": 110, "height": 36,
         "events": {"clicked": "QMessageBox.information(self, 'Feedback', f'Rating: {self.stars.rating()}')"}},
    ], "Card with star rating and toggle (uses Extra Controls)", form={"title": "Feedback", "width": 420, "height": 290})
