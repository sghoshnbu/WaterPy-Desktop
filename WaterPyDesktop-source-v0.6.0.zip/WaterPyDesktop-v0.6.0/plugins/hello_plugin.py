"""Minimal single-file plugin: a menu command, a status message and an event hook."""
PLUGIN_ID = "hello_plugin"
PLUGIN_NAME = "Hello Plugin"
PLUGIN_VERSION = "2.0.0"
PLUGIN_AUTHOR = "WaterPyDesktop"
PLUGIN_DESCRIPTION = "Smallest possible API 2 plugin — use it as a starting point."
PLUGIN_API_VERSION = "2.0"


def register(api):
    def greet():
        n = len(api.project.controls())
        api.notify(f"Hello! '{api.project.name}' has {n} control(s) on the form.")

    api.add_menu_action("Say hello", greet, menu="Extensions", tooltip="Shows a greeting in the status bar")
    api.on("project.saved", lambda project, directory: api.log(f"saved to {directory}"))
