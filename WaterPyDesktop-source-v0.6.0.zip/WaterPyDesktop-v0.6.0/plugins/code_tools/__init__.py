"""Code Tools — formatting, generated-code header and 'copy as Python'."""
import datetime

from PySide6.QtWidgets import QApplication, QInputDialog, QMessageBox


def register(api):
    def header_transform(source, project):
        if not api.settings.get("header", False):
            return source
        author = api.settings.get("author", "")
        stamp = datetime.date.today().isoformat()
        line = f"# Author: {author}  ·  Generated: {stamp}\n" if author else f"# Generated: {stamp}\n"
        return line + source

    api.register_code_transform(header_transform)

    def toggle_header(checked):
        api.settings.set("header", bool(checked))
        if checked and not api.settings.get("author"):
            name, ok = QInputDialog.getText(api.window, "Code header", "Author name for the header comment:")
            if ok:
                api.settings.set("author", name.strip())
        api.project.regenerate()

    action = api.add_menu_action("Add author/date header to generated code", lambda: None, menu="Code Tools")
    action.setCheckable(True)
    action.setChecked(bool(api.settings.get("header", False)))
    action.toggled.connect(api.safe(toggle_header))

    def format_black():
        try:
            import black  # type: ignore
        except ImportError:
            QMessageBox.information(api.window, "Format source",
                                    "The 'black' formatter is not installed in the IDE environment.\n\n"
                                    "Install it with:  python -m pip install black")
            return
        src = api.project.get_source()
        try:
            formatted = black.format_str(src, mode=black.Mode(line_length=110))
        except Exception as exc:
            QMessageBox.warning(api.window, "Format source", f"black could not format the source:\n{exc}")
            return
        if formatted != src:
            api.project.set_source(formatted)
            api.notify("Source formatted with black")
        else:
            api.notify("Source already formatted")

    api.add_menu_action("Format source with black", format_black, menu="Code Tools", shortcut="Ctrl+Alt+L")

    def copy_as_python(names):
        from waterpy.codegen import generate_python
        controls = [api.project.find(n) for n in names] or []
        controls = [c for c in controls if c]
        if not controls:
            api.notify("Select one or more controls first")
            return
        src = generate_python("Snippet", "", controls)
        lines, grab = [], False
        for line in src.splitlines():
            if line.strip().startswith("def setup_ui"):
                grab = True
                continue
            if grab and line.startswith("    def "):
                break
            if grab and '"""' not in line:
                lines.append(line[8:] if line.startswith("        ") else line)
        QApplication.clipboard().setText("\n".join(lines).strip() + "\n")
        api.notify(f"Copied Python for {len(controls)} control(s)")

    api.add_context_action("Copy as Python code", copy_as_python)
