"""Adds a 'Starter' form template plus a one-click menu command that inserts it."""
PLUGIN_ID = "starter_layout"
PLUGIN_NAME = "Starter Layout"
PLUGIN_VERSION = "2.0.0"
PLUGIN_AUTHOR = "WaterPyDesktop"
PLUGIN_DESCRIPTION = "Registers a starter form template (title, name field, Continue button)."
PLUGIN_API_VERSION = "2.0"

CONTROLS = [
    {"type": "Label", "name": "lbl_welcome", "text": "Welcome to WaterPyDesktop", "x": 28, "y": 24,
     "width": 360, "height": 36, "font_size": 16, "bold": True},
    {"type": "Line Edit", "name": "txt_name", "placeholder": "Enter your name…", "x": 28, "y": 78, "width": 260, "height": 34},
    {"type": "Button", "name": "btn_continue", "text": "Continue", "x": 28, "y": 128, "width": 140, "height": 38,
     "events": {"clicked": "name = self.txt_name.text().strip() or 'friend'\n"
                           "self.statusBar().showMessage(f'Hello, {name}!', 3000)"}},
]


def register(api):
    api.register_template("Starter", CONTROLS, "Title, text field and button", form={"title": "Starter", "width": 520, "height": 260})

    def insert():
        for control in CONTROLS:
            api.project.add_control(control["type"], **{k: v for k, v in control.items() if k != "type"})
        api.notify("Starter layout inserted")

    api.add_menu_action("Insert starter layout", insert, menu="Extensions")
