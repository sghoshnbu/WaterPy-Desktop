"""Export the designed form as a Qt Designer ``.ui`` file (absolute geometry)."""
import xml.etree.ElementTree as ET

# property key -> (Qt Designer property name, value type)
TEXT_PROPS = {"text": ("text", "string"), "placeholder": ("placeholderText", "string"), "title": ("title", "string"),
              "tooltip": ("toolTip", "string"), "checked": ("checked", "bool"), "checkable": ("checkable", "bool"),
              "read_only": ("readOnly", "bool"), "minimum": ("minimum", "number"), "maximum": ("maximum", "number"),
              "value": ("value", "number"), "rows": ("rowCount", "number"), "columns": ("columnCount", "number"),
              "word_wrap": ("wordWrap", "bool"), "description": ("description", "string"),
              "interval": ("interval", "number"), "html": ("html", "string")}


def _prop(parent, name, kind, value):
    prop = ET.SubElement(parent, "property", name=name)
    if kind == "bool":
        ET.SubElement(prop, "bool").text = "true" if value else "false"
    elif kind == "number":
        ET.SubElement(prop, "number" if float(value).is_integer() else "double").text = str(int(value) if float(value).is_integer() else value)
    elif kind == "rect":
        rect = ET.SubElement(prop, "rect")
        for k, v in zip(("x", "y", "width", "height"), value):
            ET.SubElement(rect, k).text = str(int(v))
    else:
        ET.SubElement(prop, "string").text = str(value)


def export_ui(project, path):
    from waterpy.registry import REGISTRY
    form = project["form"]
    ui = ET.Element("ui", version="4.0")
    ET.SubElement(ui, "class").text = "MainWindow"
    win = ET.SubElement(ui, "widget", {"class": "QMainWindow", "name": "MainWindow"})
    _prop(win, "geometry", "rect", (0, 0, form.get("width", 900), form.get("height", 600)))
    _prop(win, "windowTitle", "string", form.get("title", project["name"]))
    central = ET.SubElement(win, "widget", {"class": "QWidget", "name": "centralwidget"})
    skipped = []
    for c in project["controls"]:
        spec = REGISTRY.get(c["type"])
        if spec is None or spec.non_visual or not spec.qt_class.startswith("Q") or spec.module is None:
            skipped.append(c["name"])
            continue
        w = ET.SubElement(central, "widget", {"class": spec.qt_class, "name": c["name"]})
        _prop(w, "geometry", "rect", (c["x"], c["y"], c["width"], c["height"]))
        for key, (qt_name, kind) in TEXT_PROPS.items():
            if key in c and spec.property(key) is not None and c[key] not in ("", None):
                _prop(w, qt_name, kind, c[key])
        css = spec.css(c, design=False)
        if css:
            _prop(w, "styleSheet", "string", css)
        if spec.qt_class in ("QComboBox", "QListWidget"):
            for text in c.get("items") or []:
                item = ET.SubElement(w, "item")
                _prop(item, "text", "string", text)
        if spec.qt_class == "QTabWidget":
            for i, title in enumerate(c.get("tabs") or ["Tab 1"]):
                page = ET.SubElement(w, "widget", {"class": "QWidget", "name": f"{c['name']}_page{i + 1}"})
                attr = ET.SubElement(page, "attribute", name="title")
                ET.SubElement(attr, "string").text = title
    ET.SubElement(ui, "resources")
    ET.SubElement(ui, "connections")
    tree = ET.ElementTree(ui)
    ET.indent(tree, space=" ")
    tree.write(path, encoding="UTF-8", xml_declaration=True)
    return skipped


def register(api):
    def exporter(project, path):
        skipped = export_ui(project, path)
        if skipped:
            api.log(f"not exported (non-visual or custom widgets): {', '.join(skipped)}", "warning")

    api.register_exporter("Qt Designer (.ui)", "Qt Designer UI (*.ui)", exporter)
