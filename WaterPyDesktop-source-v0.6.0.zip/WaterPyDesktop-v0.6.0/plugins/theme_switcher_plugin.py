"""Adds a toolbar button that cycles through the IDE themes."""
PLUGIN_ID = "theme_switcher"
PLUGIN_NAME = "Theme Switcher"
PLUGIN_VERSION = "2.0.0"
PLUGIN_AUTHOR = "WaterPyDesktop"
PLUGIN_DESCRIPTION = "Toolbar button + menu to cycle IDE themes; remembers nothing itself (uses host settings)."
PLUGIN_API_VERSION = "2.0"


def register(api):
    themes = list(api.window.THEMES)

    def cycle():
        current = api.window.current_theme
        nxt = themes[(themes.index(current) + 1) % len(themes)] if current in themes else themes[0]
        api.window.apply_theme(nxt)

    api.add_toolbar_action("◐ Theme", cycle, tooltip="Cycle IDE theme")
    for theme in themes:
        api.add_menu_action(theme, lambda t=theme: api.window.apply_theme(t), menu="Themes")
