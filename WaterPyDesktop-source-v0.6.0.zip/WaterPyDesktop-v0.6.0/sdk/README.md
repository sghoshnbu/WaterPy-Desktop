# WaterPyDesktop Plugin SDK kit

* `../PLUGIN_SDK.md` — complete API 2.0 reference (also under *Help → Plugin SDK Guide* in the IDE).
* `waterpy-plugin.py` — scaffold, validate and package plugins (`python sdk/waterpy-plugin.py --help`).
* `examples/echo_provider.py` — adding a custom AI back-end.
* `examples/volume_slider.py` — the smallest possible new palette component.
* `../plugins/` — eight working example plugins (single-file and package) shipped with the IDE.

Install an example: *Plugins → Plugin Manager → Install…* and choose the `.py` file.
