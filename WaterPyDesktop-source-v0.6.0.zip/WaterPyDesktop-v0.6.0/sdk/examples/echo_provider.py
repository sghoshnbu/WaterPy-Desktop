"""Example: register a custom AI provider (shows up in AI Settings)."""
PLUGIN_ID = "echo_provider"
PLUGIN_NAME = "Echo AI Provider (demo)"
PLUGIN_VERSION = "1.0.0"
PLUGIN_API_VERSION = "2.0"

from waterpy.ai.providers import Provider  # noqa: E402


class EchoProvider(Provider):
    id, name, needs_key = "echo", "Echo (demo provider)", False
    default_model, models = "echo", ("echo",)
    notes = "Returns your request — useful for testing plugins without an AI account."

    def stream(self, cfg, system, messages, mode="chat", cancelled=lambda: False):
        request = messages[-1]["content"].split("REQUEST:")[-1].strip()
        for word in f"[{mode}] You asked: {request}".split(" "):
            if cancelled():
                return
            yield word + " "


def register(api):
    api.register_ai_provider(EchoProvider())
