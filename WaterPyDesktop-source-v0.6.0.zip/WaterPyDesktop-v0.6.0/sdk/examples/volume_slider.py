"""Example: the smallest useful palette component."""
PLUGIN_ID = "volume_slider"
PLUGIN_NAME = "Volume Slider"
PLUGIN_VERSION = "1.0.0"
PLUGIN_API_VERSION = "2.0"

from waterpy.plugin_sdk import ComponentSpec, PropertySpec  # noqa: E402

SPEC = ComponentSpec(
    "Volume Slider", "QSlider", category="Input", glyph="🔊", description="0–100 volume slider",
    default_size=(200, 28), signals={"valueChanged": "value: int"},
    properties=[
        PropertySpec("orientation", "Orientation", "choice", "Horizontal", setter="setOrientation",
                     code_map={"Horizontal": "Qt.Orientation.Horizontal", "Vertical": "Qt.Orientation.Vertical"}),
        PropertySpec("maximum", "Maximum", "int", 100, setter="setMaximum"),
        PropertySpec("value", "Value", "int", 80, setter="setValue"),
    ])


def register(api):
    api.register_component(SPEC)
