"""WaterPyDesktop Plugin SDK command-line tool (wrapper around waterpy.sdk_tools).

    python sdk/waterpy-plugin.py new my_plugin --template component
    python sdk/waterpy-plugin.py validate plugins/my_plugin
    python sdk/waterpy-plugin.py package plugins/my_plugin -o dist
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from waterpy.sdk_tools import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
