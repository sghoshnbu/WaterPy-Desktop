"""0.6 features: import/export formats, snippets, installer scripts, build args, preview."""
import ast
import json
import shutil
import subprocess
import textwrap
from pathlib import Path

import pytest

from waterpy import installer as inst
from waterpy import io_formats
from waterpy.codegen import generate_python
from waterpy.snippets import SNIPPETS, render

UI_SAMPLE = """<?xml version="1.0" encoding="UTF-8"?>
<ui version="4.0">
 <class>Dialog</class>
 <widget class="QDialog" name="Dialog">
  <property name="geometry"><rect><x>0</x><y>0</y><width>400</width><height>300</height></rect></property>
  <property name="windowTitle"><string>Library login</string></property>
  <widget class="QGroupBox" name="box">
   <property name="geometry"><rect><x>10</x><y>20</y><width>380</width><height>200</height></rect></property>
   <property name="title"><string>Account</string></property>
   <widget class="QLineEdit" name="user">
    <property name="geometry"><rect><x>20</x><y>30</y><width>200</width><height>28</height></rect></property>
    <property name="placeholderText"><string>Member ID</string></property>
   </widget>
   <widget class="QLineEdit" name="pw">
    <property name="geometry"><rect><x>20</x><y>70</y><width>200</width><height>28</height></rect></property>
    <property name="echoMode"><enum>QLineEdit::Password</enum></property>
   </widget>
   <widget class="QComboBox" name="branch">
    <property name="geometry"><rect><x>20</x><y>110</y><width>200</width><height>28</height></rect></property>
    <item><property name="text"><string>Central</string></property></item>
    <item><property name="text"><string>DLIS</string></property></item>
   </widget>
  </widget>
  <widget class="QPushButton" name="ok">
   <property name="geometry"><rect><x>290</x><y>250</y><width>100</width><height>32</height></rect></property>
   <property name="text"><string>Sign in</string></property>
   <property name="font"><font><pointsize>11</pointsize><bold>true</bold></font></property>
  </widget>
  <widget class="QMysteryWidget" name="odd"/>
  <layout class="QVBoxLayout" name="lay">
   <item><widget class="QLabel" name="footer"><property name="text"><string>v1</string></property></widget></item>
  </layout>
 </widget>
</ui>
"""


def test_import_ui(tmp_path):
    f = tmp_path / "login.ui"
    f.write_text(UI_SAMPLE)
    layout, warnings = io_formats.import_ui(f)
    by = {c["name"]: c for c in layout["controls"]}
    assert layout["form"]["title"] == "Library login"
    assert by["box"]["type"] == "Group Box" and by["box"]["title"] == "Account"
    assert by["user"]["x"] == 30 and by["user"]["y"] == 50          # flattened from the group box
    assert by["pw"]["type"] == "Password Box"
    assert by["branch"]["items"] == ["Central", "DLIS"]
    assert by["ok"]["bold"] is True and by["ok"]["font_size"] == 11
    assert "footer" in by                                           # layout-managed widget kept
    assert any("QMysteryWidget" in w for w in warnings)
    compile(generate_python("Imp", "", layout["controls"], form=layout["form"]), "imp", "exec")


def test_ui_roundtrip_with_exporter(tmp_path):
    import importlib.util
    spec = importlib.util.spec_from_file_location("uiexp", Path(__file__).parent.parent / "plugins" / "qt_ui_exporter" / "__init__.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    controls = [{"type": "Button", "name": "b", "x": 5, "y": 6, "width": 100, "height": 30, "text": "Go"},
                {"type": "Combo Box", "name": "c", "x": 5, "y": 50, "width": 100, "height": 30, "items": ["x", "y"]}]
    from waterpy.codegen import normalize_controls
    project = {"name": "RT", "form": {"title": "RT", "width": 500, "height": 300}, "controls": normalize_controls(controls)}
    mod.export_ui(project, tmp_path / "rt.ui")
    layout, _ = io_formats.import_ui(tmp_path / "rt.ui")
    by = {c["name"]: c for c in layout["controls"]}
    assert by["b"]["text"] == "Go" and (by["b"]["x"], by["b"]["y"]) == (5, 6) and by["c"]["items"] == ["x", "y"]


def test_layout_json_roundtrip(tmp_path):
    project = {"name": "P", "form": {"title": "T"}, "controls": [{"type": "Label", "name": "l"}], "custom_methods": "x"}
    io_formats.export_layout(project, tmp_path / "l.json")
    data = io_formats.import_layout(tmp_path / "l.json")
    assert data["controls"][0]["name"] == "l" and data["custom_methods"] == "x"


def test_csv_import_and_grid_data_runtime(qapp, tmp_path):
    f = tmp_path / "books.csv"
    f.write_bytes("Title;Author\nGitanjali;Tagore\n\"Five Laws; 1931\";Ranganathan\n".encode("cp1252"))
    rows = io_formats.read_csv(f)
    assert rows[0] == ["Title", "Author"] and rows[2][0] == "Five Laws; 1931"
    data = io_formats.rows_to_csv_text(rows[1:])
    src = generate_python("G", "", [{"type": "Grid", "name": "g", "headers": rows[0], "columns": 2, "rows": 0, "data": data}])
    ns = {"__name__": "g"}
    exec(compile(src, "g", "exec"), ns)
    w = ns["MainWindow"]()
    assert w.g.rowCount() == 2 and w.g.item(1, 0).text() == "Five Laws; 1931"


def test_html_docs_pyqt6(tmp_path):
    controls = [{"type": "Button", "name": "b", "text": "<Go>", "x": 1, "y": 2, "width": 50, "height": 20, "events": {"clicked": "print(1)"}},
                {"type": "Grid", "name": "g", "headers": ["A"], "data": "1\n2"}, {"type": "Timer", "name": "t"}]
    from waterpy.codegen import normalize_controls
    project = {"name": "Doc", "form": {"title": "Doc", "width": 300, "height": 200, "tab_order": ["b", "g"]},
               "controls": normalize_controls(controls), "custom_methods": "def helper(self):\n    pass"}
    io_formats.export_html(project, tmp_path / "m.html")
    html = (tmp_path / "m.html").read_text()
    assert "&lt;Go&gt;" in html and "<td>2</td>" in html and "Timer" not in html.split("<body>")[1]
    md = io_formats.documentation_markdown(project)
    assert "`b.clicked`" in md and "def helper" in md and "## Keyboard tab order" in md
    io_formats.export_documentation(project, tmp_path / "d.html")
    assert "<table" in (tmp_path / "d.html").read_text().lower()
    src = generate_python("Q", "", controls)
    pyqt = io_formats.to_pyqt6(src.replace("from PySide6.QtCore import", "from PySide6.QtCore import Signal,"))
    assert "PySide6" not in pyqt and "pyqtSignal as Signal" in pyqt
    ast.parse(pyqt)


@pytest.mark.parametrize("category", list(SNIPPETS))
def test_snippets_compile(category):
    for label, code in SNIPPETS[category]:
        body = textwrap.indent(render(code, "widget"), "    ")
        ast.parse(f"def handler(self):\n{body}\n")


def test_pyinstaller_args(tmp_path):
    (tmp_path / "assets").mkdir()
    (tmp_path / "assets" / "app.ico").write_bytes(b"\0")
    args, name, dist = inst.pyinstaller_args({"app_name": "Lib Search!", "version": "2.1", "onefile": True, "console": True,
                                              "icon": "assets/app.ico", "hidden_imports": "pandas, openpyxl",
                                              "extra_args": "--collect-all reportlab"}, tmp_path, tmp_path / "main.py", "x")
    assert name == "LibSearch" and "--onefile" in args and "--console" in args
    assert args[args.index("--icon") + 1].endswith("app.ico")
    assert args.count("--hidden-import") == 2 and "--collect-all" in args
    vfile = Path(args[args.index("--version-file") + 1]).read_text()
    assert "filevers=(2, 1, 0, 0)" in vfile and "LibSearch.exe" in vfile


@pytest.mark.skipif(not shutil.which("makensis"), reason="NSIS not installed")
@pytest.mark.parametrize("onefile,per_user", [(False, False), (True, True)])
def test_nsis_installer_compiles(tmp_path, onefile, per_user):
    dist = tmp_path / "dist"
    if onefile:
        dist.mkdir()
        (dist / "App.exe").write_bytes(b"MZ")
    else:
        (dist / "App" / "_internal").mkdir(parents=True)
        (dist / "App" / "App.exe").write_bytes(b"MZ")
        (dist / "App" / "_internal" / "x.dll").write_bytes(b"0")
    out = tmp_path / "out"
    out.mkdir()
    script = tmp_path / "s.nsi"
    script.write_text(inst.nsis_script({"app_name": "My App", "version": "1.0"}, {"per_user": per_user}, dist, "App", out))
    subprocess.run(["makensis", "-V1", str(script)], check=True)
    assert (out / "App-1.0-setup.exe").stat().st_size > 30000


def test_inno_script_shape(tmp_path):
    (tmp_path / "App").mkdir()
    text = inst.inno_script({"app_name": "My App", "version": "3.2"}, {"publisher": "NBU"}, tmp_path, "App", tmp_path)
    assert "AppId={{" in text and "recursesubdirs" in text and "OutputBaseFilename=App-3.2-setup" in text
    assert "[Run]" in text and "desktopicon" in text


def test_ide_tools(window, tmp_path, monkeypatch):
    from PySide6.QtWidgets import QFileDialog, QInputDialog, QMessageBox
    w = window
    w.apply_layout({"controls": [{"type": "Line Edit", "name": "a", "x": 10, "y": 10},
                                 {"type": "Line Edit", "name": "b", "x": 10, "y": 60},
                                 {"type": "Button", "name": "go", "x": 10, "y": 110, "events": {"clicked": "self.a.setText('hi')"}}]},
                   confirm=False)
    # tab order
    w.canvas.apply_form_settings(tab_order=["b", "a", "go"])
    assert "QWidget.setTabOrder(self.b, self.a)" in w.generate_source()
    # live preview
    w.refresh_code(force=True)
    w.live_preview()
    assert w._previews and w._previews[-1].a is not None
    w._previews[-1].go.click()
    assert w._previews[-1].a.text() == "hi"
    w._previews[-1].close()
    # snippets insert into handler editor
    w.canvas.set_selection([w.canvas.find("a")])
    w._insert_snippet(w.ev_code, "{control}.clear()")
    assert "self.a.clear()" in w.ev_code.toPlainText()
    # find / replace
    w.find_bar.find.setText("setText")
    w.find_bar.replace.setText("setPlaceholderText")
    w.find_bar.replace_all()
    assert "setPlaceholderText('hi')" in w.editor.toPlainText() and w.source_dirty
    # exports through the IDE
    for kind in ("png", "pdf"):
        monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, k=kind, **kw: (str(tmp_path / f"form.{k}"), ""))
        w.export_form_image(kind)
        assert (tmp_path / f"form.{kind}").stat().st_size > 500
    # save as template -> appears in registry
    answers = iter([("Two inputs", True), ("demo", True)])
    monkeypatch.setattr(QInputDialog, "getText", lambda *a, **k: next(answers))
    w.save_as_template()
    from waterpy.registry import REGISTRY
    assert REGISTRY.template("Two inputs") is not None
    # import csv into a grid
    w.apply_layout({"controls": [{"type": "Grid", "name": "g"}]}, confirm=False)
    w.canvas.set_selection([w.canvas.find("g")])
    csvf = tmp_path / "x.csv"
    csvf.write_text("h1,h2\n1,2\n3,4\n")
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (str(csvf), ""))
    monkeypatch.setattr(QMessageBox, "question", lambda *a, **k: QMessageBox.StandardButton.Yes)
    w.import_csv_grid()
    g = w.canvas.find("g")
    assert g.props["headers"] == ["h1", "h2"] and g.inner.item(1, 1).text() == "4"
    # build settings are saved with the project
    w.build_settings = {"app_name": "X", "version": "9.9"}
    w.project_file, w.project_dir, w.project_name = tmp_path / "p.waterpy.json", tmp_path, "p"
    assert w.save_project()
    assert json.loads((tmp_path / "p.waterpy.json").read_text())["build"]["version"] == "9.9"
