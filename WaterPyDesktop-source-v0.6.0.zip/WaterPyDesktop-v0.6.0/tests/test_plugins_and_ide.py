"""Plugin SDK, plugin manager and IDE integration tests (headless)."""
import json
import zipfile

import pytest

from waterpy import sdk_tools
from waterpy.registry import REGISTRY


def test_bundled_plugins_load(window):
    status = {p.id: p.status for p in window.plugins.plugins.values()}
    assert status and all(s == "loaded" for s in status.values()), status
    assert REGISTRY.get("Toggle Switch") and REGISTRY.get("Star Rating")


@pytest.mark.parametrize("template", list(sdk_tools.TEMPLATES))
def test_scaffold_validate_load_unload(window, tmp_path, template):
    folder = sdk_tools.scaffold(window.plugins.user_folder, f"t_{template}", template=template)
    assert sdk_tools.validate(folder) == []
    window.plugins.scan()
    info = window.plugins.plugins[f"t_{template}"]
    kinds_before = len(REGISTRY.kinds())
    assert window.plugins.load(info, window), info.error
    if template == "component":
        assert len(REGISTRY.kinds()) == kinds_before + 1
    assert window.plugins.unload(info.id, window)
    assert len(REGISTRY.kinds()) == kinds_before
    assert window.plugins.reload(info.id, window)
    package = sdk_tools.package(folder, tmp_path)
    assert package.suffix == ".wpplugin" and zipfile.is_zipfile(package)


def test_contributions_are_removed_on_unload(window):
    folder = sdk_tools.scaffold(window.plugins.user_folder, "contrib", template="basic")
    (folder / "__init__.py").write_text('''
from waterpy.plugin_sdk import ComponentSpec, PropertySpec
def register(api):
    api.add_menu_action("Do it", lambda: None, menu="Contrib Menu")
    api.add_toolbar_action("Tool", lambda: None)
    api.register_component(ComponentSpec("Contrib Box", "QFrame", category="Plugins"))
    api.register_template("Contrib T", [{"type": "Label"}])
    api.register_code_transform(lambda s, p: s + "# contrib\\n")
    api.register_exporter("Contrib export", "*.txt", lambda p, path: path.write_text("x"))
    api.register_ai_action("Contrib AI", "hello")
    api.on("project.saved", lambda *a: None)
    api.add_context_action("Contrib ctx", lambda names: None)
''')
    window.plugins.scan()
    info = window.plugins.plugins["contrib"]
    assert window.plugins.load(info, window), info.error
    menus = [a.text() for a in window.menuBar().actions()]
    assert "Contrib Menu" in menus and REGISTRY.get("Contrib Box") and REGISTRY.template("Contrib T")
    assert window.generate_source().endswith("# contrib\n")
    assert any(e[1] == "Contrib export" for e in window.exporters)
    window.plugins.unload("contrib", window)
    assert "Contrib Menu" not in [a.text() for a in window.menuBar().actions()]
    assert REGISTRY.get("Contrib Box") is None and REGISTRY.template("Contrib T") is None
    assert not window.generate_source().endswith("# contrib\n")
    assert not any(e[1] == "Contrib export" for e in window.exporters)
    assert window.events.subscribers("project.saved") == sum(
        1 for p in window.plugins.plugins.values() if p.status == "loaded" and p.id == "hello_plugin")
    assert not window.canvas.context_actions or all(a.text() != "Contrib ctx" for a in window.canvas.context_actions)


def test_failing_plugin_is_isolated(window):
    bad = window.plugins.user_folder / "bad_plugin.py"
    bad.write_text("PLUGIN_API_VERSION = '2.0'\ndef register(api):\n    api.add_menu_action('half', lambda: None)\n    raise ValueError('nope')\n")
    window.plugins.scan()
    info = window.plugins.plugins["bad_plugin"]
    assert not window.plugins.load(info, window)
    assert info.status == "error" and "nope" in info.error
    assert "half" not in [a.text() for m in window.menuBar().actions() if m.menu() for a in m.menu().actions()]


def test_legacy_v1_plugin(window):
    legacy = window.plugins.user_folder / "legacy.py"
    legacy.write_text("def register(window):\n    window.menuBar().addAction('Legacy!')\n    window.canvas.add_control('Label', data={'name': 'from_legacy'})\n")
    window.plugins.scan()
    assert window.plugins.load(window.plugins.plugins["legacy"], window)
    assert window.canvas.find("from_legacy") is not None
    assert not window.plugins.unload("legacy", window)        # v1 cannot hot-unload
    assert window.plugins.plugins["legacy"].status == "restart required"


def test_incompatible_api_version(window):
    (window.plugins.user_folder / "future.py").write_text("PLUGIN_API_VERSION = '9.0'\ndef register(api): pass\n")
    window.plugins.scan()
    assert not window.plugins.load(window.plugins.plugins["future"], window)
    assert window.plugins.plugins["future"].status == "incompatible"


def test_install_archive_rejects_path_traversal(window, tmp_path):
    evil = tmp_path / "evil.zip"
    with zipfile.ZipFile(evil, "w") as zf:
        zf.writestr("../escape.py", "def register(api): pass")
    with pytest.raises(ValueError, match="Unsafe"):
        window.plugins.install(evil)


def test_install_and_uninstall_package(window, tmp_path):
    src = sdk_tools.scaffold(tmp_path, "shipped", template="panel")
    pkg = sdk_tools.package(src, tmp_path / "dist")
    info = window.plugins.install(pkg, window)
    assert info.id == "shipped" and info.status == "loaded"
    window.plugins.uninstall("shipped", window)
    assert not (window.plugins.user_folder / "shipped").exists()


def test_designer_history_clipboard_align(window):
    c = window.canvas
    a, b, d = c.add_control("Button"), c.add_control("Label"), c.add_control("Line Edit")
    a.move(10, 10); b.move(50, 80); d.move(90, 200)
    for w in (a, b, d):
        w.sync_geometry()
    c.commit()
    c.set_selection([a, b, d], primary=a)
    c.align("left")
    assert {w.x() for w in (a, b, d)} == {10}
    c.undo()
    assert c.find(b.objectName()).x() == 50
    c.redo()
    c.select_all()
    c.copy_selection()
    assert len(c.paste()) == 3 and len(c.controls()) == 6
    names = [x["name"] for x in c.controls()]
    assert len(set(names)) == 6


def test_project_roundtrip(window, tmp_path):
    window.use_template = window.use_template  # templates exist
    window.apply_layout({"form": {"title": "RT", "width": 500, "height": 300},
                         "controls": [{"type": "Button", "name": "go", "events": {"clicked": "print(1)"}}],
                         "custom_methods": "def extra(self):\n    pass\n"}, confirm=False)
    window.project_file, window.project_dir, window.project_name = tmp_path / "RT.waterpy.json", tmp_path, "RT"
    assert window.save_project()
    data = json.loads((tmp_path / "RT.waterpy.json").read_text())
    assert data["version"] == 5 and data["form"]["title"] == "RT"
    assert "def on_go_clicked" in (tmp_path / "main.py").read_text()
    window.modified = False
    window.open_project(str(tmp_path / "RT.waterpy.json"))
    assert window.canvas.find("go").props["events"] == {"clicked": "print(1)"}
    assert "def extra(self)" in window.editor.toPlainText()


def test_manual_source_edits_are_protected(window):
    window.refresh_code(force=True)
    window.editor.appendPlainText("# my edit")
    window.canvas.add_control("Label")
    window.refresh_code()
    assert "# my edit" in window.editor.toPlainText() and not window.source_banner.isHidden()


def test_qt_ui_export(window, tmp_path):
    window.apply_layout({"controls": [{"type": "Combo Box", "name": "cmb", "items": ["a", "b"]}]}, confirm=False)
    fn = next(e[3] for e in window.exporters if e[1].startswith("Qt Designer"))
    out = tmp_path / "form.ui"
    fn(window.project_data(), out)
    xml = out.read_text()
    assert 'class="QComboBox"' in xml and "<string>b</string>" in xml
