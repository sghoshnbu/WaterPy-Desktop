"""Code generation must produce valid, importable Python for every component."""
import importlib.util

import pytest

from waterpy.codegen import generate_python, normalize_controls
from waterpy.registry import REGISTRY

RUNTIME_SKIP = {"Media", "Web View"}  # need audio / GPU stacks that CI machines often lack


def _all_controls():
    controls = []
    for i, kind in enumerate(REGISTRY.kinds()):
        spec = REGISTRY.get(kind)
        d = {"type": kind, "x": 10 + (i % 4) * 220, "y": (i // 4) * 60}
        if spec.default_signal:
            d["events"] = {spec.default_signal: "print('event', args)"}
        controls.append(d)
    return controls


def test_every_component_compiles():
    src = generate_python("All", "All components", _all_controls(), "def helper(self):\n    return 42\n")
    compile(src, "generated", "exec")
    assert "def on_" in src and "def helper(self)" in src


@pytest.mark.parametrize("kind", [k for k in REGISTRY.kinds()])
def test_single_component_compiles(kind):
    compile(generate_python("One", "", [{"type": kind}]), kind, "exec")


def test_generated_app_runs(qapp, tmp_path):
    controls = [c for c in _all_controls() if c["type"] not in RUNTIME_SKIP]
    src = generate_python("Runtime", "Runtime test", controls, "    def helper(self):\n        return 7\n",
                          form={"background": "#fafafa", "width": 900, "height": 700})
    path = tmp_path / "generated_app.py"
    path.write_text(src, encoding="utf-8")
    spec = importlib.util.spec_from_file_location("generated_app", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    win = mod.MainWindow()
    assert win.helper() == 7
    assert win.windowTitle() == "Runtime test"
    win.close()


def test_auto_imports_from_event_code():
    src = generate_python("X", "", [{"type": "Button", "name": "b", "events": {"clicked": "QMessageBox.about(self, 'a', 'b')\nQFileDialog.getOpenFileName(self)"}}])
    header = src.split("class MainWindow")[0]
    assert "QMessageBox" in header and "QFileDialog" in header


def test_names_are_sanitised_and_unique():
    ctrls = normalize_controls([{"type": "Button", "name": "class"}, {"type": "Button", "name": "class"},
                                {"type": "Label", "name": "2 fast"}])
    names = [c["name"] for c in ctrls]
    assert names[0] == "class_" and len(set(names)) == 3 and names[2].startswith("widget_")


def test_enum_values_cannot_inject_code():
    src = generate_python("X", "", [{"type": "Line Edit", "echo_mode": "Password); import os; os.system('x')#"}])
    assert "os.system" not in src


def test_legacy_v4_event_migration():
    c = REGISTRY.normalize({"type": "Line Edit", "on_click": "print(1)", "event_signal": "clicked"})
    assert c["events"] == {"textChanged": "print(1)"}   # invalid legacy signal falls back to default


def test_transform_errors_are_contained():
    def broken(source, project):
        raise RuntimeError("boom")
    src = generate_python("X", "", [], transforms=[broken, lambda s, p: s + "# ok\n"])
    assert "transform" in src and src.endswith("# ok\n")
    compile(src, "x", "exec")
