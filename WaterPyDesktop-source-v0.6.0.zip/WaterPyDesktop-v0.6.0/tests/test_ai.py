"""AI parsing, offline mode and provider streaming against local mock servers."""
import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from waterpy.ai.providers import AIConfig, AIError, get_provider
from waterpy.ai.service import build_system, build_user_message, extract_layout, extract_python, offline_answer


def test_extract_python_prefers_longest_python_block():
    text = "intro\n```python\nx = 1\n```\nmore\n```python\nimport sys\nprint(sys.argv)\n```"
    assert extract_python(text).startswith("import sys")


def test_extract_layout_sanitises():
    text = """Sure!\n```json\n{"form": {"title": "T", "width": 50},
    "controls": [{"type": "Button", "name": "ok", "x": -5, "y": "10", "width": 99999, "height": 30,
                  "events": {"clicked": "print(1)", "bogus": "x"}},
                 {"type": "Hologram", "name": "h"}]}\n```"""
    layout, warnings = extract_layout(text)
    btn = layout["controls"][0]
    assert btn["x"] == 0 and btn["y"] == 10 and btn["width"] == 8000
    assert btn["events"] == {"clicked": "print(1)"}
    assert layout["form"]["width"] == 200
    assert any("Hologram" in w for w in warnings) and any("bogus" in w for w in warnings)


def test_extract_layout_without_fence():
    layout, _ = extract_layout('Here: {"controls": [{"type": "Label", "text": "a {b}"}]} done')
    assert layout["controls"][0]["text"] == "a {b}"


def test_offline_design_and_generate():
    layout, _ = extract_layout(offline_answer("design_form", "REQUEST:\nan inventory screen"))
    assert any(c["type"] == "Grid" for c in layout["controls"])
    code = extract_python(offline_answer("generate_app", "REQUEST:\nhello"))
    compile(code, "offline", "exec")


def test_prompts_include_catalogue_and_context():
    assert "Star Rating" not in build_system("chat")
    system = build_system("design_form")
    assert "Button [QPushButton]" in system and "signals: clicked" in system
    msg = build_user_message("fix it", "fix_error", {"project": {"name": "P", "controls": []}, "source": "x=1",
                                                       "console": "Traceback: boom"})
    assert "Traceback: boom" in msg and "x=1" in msg


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        self.server.seen.append((self.path, self.headers, body))  # case-insensitive
        if self.path.startswith("/v1/messages"):
            events = [{"type": "message_start"},
                      {"type": "content_block_delta", "delta": {"type": "text_delta", "text": "Hel"}},
                      {"type": "content_block_delta", "delta": {"type": "text_delta", "text": "lo"}},
                      {"type": "message_stop"}]
            payload = "".join(f"event: {e['type']}\ndata: {json.dumps(e)}\n\n" for e in events)
        elif self.path.endswith("/chat/completions"):
            if body.get("model") == "bad":
                self.send_response(401)
                self.end_headers()
                self.wfile.write(json.dumps({"error": {"message": "invalid key"}}).encode())
                return
            chunks = [{"choices": [{"delta": {"content": c}}]} for c in ("Hel", "lo")]
            payload = "".join(f"data: {json.dumps(c)}\n\n" for c in chunks) + "data: [DONE]\n\n"
        elif ":streamGenerateContent" in self.path:
            chunks = [{"candidates": [{"content": {"parts": [{"text": t}]}}]} for t in ("Hel", "lo")]
            payload = "".join(f"data: {json.dumps(c)}\n\n" for c in chunks)
        elif self.path == "/api/chat":
            payload = "".join(json.dumps({"message": {"content": t}, "done": False}) + "\n" for t in ("Hel", "lo"))
            payload += json.dumps({"done": True}) + "\n"
        else:
            self.send_response(404)
            self.end_headers()
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.end_headers()
        self.wfile.write(payload.encode())


@pytest.fixture(scope="module")
def server():
    srv = HTTPServer(("127.0.0.1", 0), _Handler)
    srv.seen = []
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield srv
    srv.shutdown()


@pytest.mark.parametrize("provider", ["anthropic", "openai", "openai_compatible", "gemini", "ollama"])
def test_provider_streaming(server, provider):
    url = f"http://127.0.0.1:{server.server_port}" + ("/v1" if provider.startswith("openai") else "")
    cfg = AIConfig(provider=provider, model="m", api_key="k", base_url=url)
    text = "".join(get_provider(provider).stream(cfg, "sys", [{"role": "user", "content": "hi"}]))
    assert text == "Hello"
    path, headers, body = server.seen[-1]
    if provider == "anthropic":
        assert headers["x-api-key"] == "k" and body["system"] == "sys"
    if provider == "openai":
        assert headers["Authorization"] == "Bearer k" and body["messages"][0]["role"] == "system"


def test_provider_http_error_is_readable(server):
    cfg = AIConfig(provider="openai", model="bad", api_key="k", base_url=f"http://127.0.0.1:{server.server_port}/v1")
    with pytest.raises(AIError, match="invalid key"):
        list(get_provider("openai").stream(cfg, "s", [{"role": "user", "content": "x"}]))


def test_missing_key_message():
    with pytest.raises(AIError, match="API key"):
        list(get_provider("anthropic").stream(AIConfig(provider="anthropic", model="m"), "s", []))
