import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


@pytest.fixture(scope="session")
def qapp():
    from PySide6.QtCore import QStandardPaths
    from PySide6.QtWidgets import QApplication
    QStandardPaths.setTestModeEnabled(True)
    app = QApplication.instance() or QApplication([])
    app.setOrganizationName("WaterPyDesktopTests")
    app.setApplicationName("WaterPyDesktopTests")
    app.setStyle("Fusion")
    return app


@pytest.fixture
def window(qapp, tmp_path, monkeypatch):
    from waterpy import main_window
    monkeypatch.setattr(main_window, "user_data_dir", lambda: tmp_path / "userdata")
    (tmp_path / "userdata").mkdir()
    w = main_window.MainWindow()
    w.modified = False
    yield w
    w.modified = False
    w.ai_panel.shutdown()
    for pid in [p.id for p in w.plugins.plugins.values() if p.status == "loaded"]:
        w.plugins.unload(pid, w)
    w.close()
    w.deleteLater()
    qapp.processEvents()
