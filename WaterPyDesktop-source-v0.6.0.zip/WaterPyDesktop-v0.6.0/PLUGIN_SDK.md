# WaterPyDesktop Plugin SDK — API 2.0

Plugins extend WaterPyDesktop with new **palette components**, **form templates**, **menus and toolbar
buttons**, **dock panels**, **code transforms**, **export formats**, **AI actions and AI providers**, and
**event hooks** — and everything they add is removed again when they are disabled, so you can develop
with hot reload.

> Plugins are trusted Python code. They run inside the IDE process with the same permissions as the IDE.
> Install only plugins you trust.

---

## 1. Quick start

**Fastest way:** *Plugins → New Plugin…* (or `python -m waterpy.sdk_tools new my_plugin`). Pick a template,
edit the generated `__init__.py`, then *Plugins → Plugin Manager → Reload* to hot-reload.

A complete single-file plugin:

```python
"""Shows a greeting."""
PLUGIN_ID = "hello"
PLUGIN_NAME = "Hello"
PLUGIN_VERSION = "1.0.0"
PLUGIN_API_VERSION = "2.0"

def register(api):
    api.add_menu_action("Say hello", lambda: api.notify("Hello!"))
```

A package plugin is a folder:

```
my_plugin/
├── plugin.json        manifest (read without executing your code)
├── __init__.py        entry point: register(api) [, unregister(api)]
└── …                  any other modules / assets (relative imports work)
```

```json
{
  "id": "my_plugin", "name": "My Plugin", "version": "1.0.0", "author": "You",
  "description": "What it does", "api_version": "2.0", "min_host": "0.5.0",
  "entry": "__init__.py", "homepage": ""
}
```

## 2. Where plugins live and how they are installed

| Location | Purpose |
|---|---|
| `<IDE folder>/plugins/` | **Bundled** plugins shipped with the IDE (cannot be uninstalled, only disabled) |
| User plugins folder (*Plugins → Open User Plugins Folder*; on Windows `%APPDATA%\WaterPyDesktop\WaterPyDesktop\plugins`) | Plugins you install or create. Writable even if the IDE is in *Program Files*. A user plugin with the same `id` overrides a bundled one. |

The **Plugin Manager** installs a `.py` file, a plugin folder, or a `.zip` / `.wpplugin` archive (archives are
checked for unsafe paths). Enable/disable state is remembered per user. Metadata is read with `ast`/JSON
**before** any plugin code runs.

## 3. Lifecycle

1. `register(api)` is called when the plugin is enabled (at start-up or when ticked in the Plugin Manager).
2. Everything you add **through `api`** is tracked: menus, toolbar actions, docks, components, templates,
   transforms, exporters, AI actions/providers, context-menu entries and event subscriptions.
3. On disable/reload, the optional `unregister(api)` runs, then the host removes all tracked contributions
   and unloads your modules from `sys.modules`.
4. If `register` raises, the plugin is marked **error**, its partial contributions are rolled back, and
   the IDE keeps running. Callbacks you register through `api` are wrapped so exceptions are logged to the
   Console instead of crashing the IDE (use `api.safe(fn)` for callbacks you connect yourself).

## 4. `HostAPI` reference

### Information & utilities
| Member | Description |
|---|---|
| `api.plugin_id`, `api.plugin_dir` | Your id and folder |
| `api.window` | The `MainWindow` (escape hatch — prefer the documented API) |
| `api.log(msg, level="info")` | Write to the Console (`info`, `warning`, `error`, `success`) |
| `api.notify(msg, timeout_ms=4000)` | Status-bar message |
| `api.safe(fn)` | Wrap a callback so exceptions are logged |
| `api.settings` | Persistent per-plugin key/value store: `get(key, default)`, `set(key, value)`, `remove(key)`, `all()` |

### UI contributions
| Method | Description |
|---|---|
| `api.menu(title="Extensions")` | Get/create a top-level menu (shared between plugins; built-in menus such as `"AI"` can be extended) |
| `api.add_menu_action(text, callback, menu="Extensions", shortcut=None, tooltip="")` | Returns the `QAction` |
| `api.add_toolbar_action(text, callback, tooltip="", icon=None)` | Adds to the *Plugins* toolbar |
| `api.add_dock_panel(title, widget, area="right")` | Dock tabbed with the Inspector (`left`, `right`, `bottom`, `top`) |
| `api.add_context_action(text, callback)` | Designer right-click menu; `callback(selected_names: list[str])` |

### Designer and code generation
| Method | Description |
|---|---|
| `api.register_component(spec, replace=False)` | Add a palette tool (see §5) |
| `api.register_template(name, controls, description="", custom_methods="", form=None, category=None)` | Appears in *Templates* and *File → New from Template* |
| `api.register_snippet(id, code, imports=None)` | Module-level helper code components can request with `snippets=(id,)` |
| `api.register_code_transform(fn)` | `fn(source: str, project: dict) -> str`, runs after every generation |
| `api.register_exporter(name, file_filter, fn)` | *File → Export → name*; `fn(project: dict, path: Path)` |

### Project access — `api.project`
| Member | Description |
|---|---|
| `name`, `directory`, `form` | Project name, folder (`None` until saved), form settings dict |
| `set_form(title=…, width=…, height=…, background=…)` | Change the window settings |
| `controls()`, `find(name)`, `selected()`, `selected_names()` | Read controls as dicts |
| `add_control(kind, **props)` → name | Insert a control (`events={"clicked": "…"}` supported) |
| `update_control(name, **props)`, `remove_control(name)` | Modify / delete (undoable) |
| `load_layout(controls, form=None, custom_methods=None)` | Replace the whole form |
| `custom_methods` (get/set) | Class-level helper methods |
| `get_source()`, `set_source(text)`, `regenerate()`, `save()`, `to_dict()` | Source & project |

### AI
| Method | Description |
|---|---|
| `api.register_ai_action(label, prompt, mode="chat", tooltip="")` | Adds to *⚡ Quick actions*. Placeholders `{selected}`, `{project}`, `{source}` are filled in. |
| `api.ask_ai(prompt, callback, mode="chat", on_error=None, include_context=True)` | Runs on a worker thread; `callback(text)` runs on the GUI thread |
| `api.open_ai_panel(mode="chat", prompt="", send=False)` | Show the assistant with a task selected |
| `api.register_ai_provider(provider)` | Add a model back-end (see §8) |

Modes: `chat`, `design_form`, `generate_app`, `modify_source`, `fix_error`, `event_handler`, `explain`, `review`.
Use `waterpy.ai.extract_python(text)` / `waterpy.ai.extract_layout(text)` to parse answers.

### Events — `api.on(event, callback)`
| Event | Callback arguments |
|---|---|
| `project.new` / `project.opened` | `project: dict` |
| `project.saved` | `project: dict, directory: Path` |
| `code.generated` | `source: str, project: dict` |
| `run.before` | `script_path: Path` |
| `build.before` | `pyinstaller_args: list` — mutable, append options (e.g. `--hidden-import`) |
| `process.finished` | `exit_code: int, mode: "run" \| "build"` |
| `selection.changed` | `names: list[str]` |
| `control.added` | `control: dict` |
| `theme.changed` | `theme: str` |
| `ai.response` | `mode: str, text: str` |
| `plugins.loaded` | `plugin_ids: list[str]` |

`python -m waterpy.sdk_tools events` prints this list.

## 5. Components: `ComponentSpec` and `PropertySpec`

The registry is the single source of truth for the palette, canvas preview, property grid, Events panel and
code generator. A `PropertySpec` names the Qt **setter**, and the *same* call is used for the canvas preview
and for generated code — what you see is what the app does.

```python
from waterpy.plugin_sdk import ComponentSpec, PropertySpec

spec = ComponentSpec(
    kind="Volume Slider",            # palette name & project-file identifier (must be unique)
    qt_class="QSlider",              # class instantiated in generated code
    module="PySide6.QtWidgets",      # imported automatically; None for classes in support_code
    category="Input",                # Common, Input, Containers, Display, Data, Shapes, System, Plugins
    glyph="🔊", description="0–100 volume", default_size=(200, 28),
    signals={"valueChanged": "value: int"},           # shown in the Events panel
    properties=[
        PropertySpec("orientation", "Orientation", "choice", "Horizontal", setter="setOrientation",
                     code_map={"Horizontal": "Qt.Orientation.Horizontal", "Vertical": "Qt.Orientation.Vertical"}),
        PropertySpec("maximum", "Maximum", "int", 100, setter="setMaximum"),
        PropertySpec("value", "Value", "int", 80, setter="setValue"),
    ],
)
api.register_component(spec)
```

### `ComponentSpec` fields
| Field | Meaning |
|---|---|
| `kind`, `qt_class`, `module` | Identity; `module=None` when the class comes from `support_code` or a snippet |
| `category`, `glyph`, `icon`, `description` | Palette presentation (`icon` may be a `QIcon` or image path) |
| `default_size`, `min_size` | Initial and minimum size on the canvas |
| `properties` | Component-specific `PropertySpec`s (common ones — name, geometry, font, colours, tooltip, enabled, visible, extra style sheet — are added automatically) |
| `signals`, `default_signal` | Qt signals → argument description |
| `constructor` | Format string, default `"{cls}({parent})"` |
| `extra_imports` | `{"PySide6.QtCore": ["Signal"]}` — any `Q…` name used in code is imported automatically, others must be listed |
| `support_code` | Module-level code (e.g. your custom widget class) emitted once into generated apps |
| `snippets` | Ids of shared helpers (built-in: `resource_path`, `webengine`) |
| `config(w, props) -> list[str]` | Extra generated lines; `w` is `"self.<name>"` |
| `preview_factory(parent)`, `preview_update(widget, props, ctx)` | Custom design-time widget; `ctx["project_dir"]` is available |
| `style(props, design) -> str` | CSS for preview (`design=True`) and generated code |
| `non_visual` | Like *Timer*: created with `self` as parent, no geometry |

### `PropertySpec` fields
| Field | Meaning |
|---|---|
| `key`, `label`, `type` | `str`, `text`, `int`, `float`, `bool`, `color`, `choice`, `list`, `file`, `font` |
| `default`, `minimum`, `maximum`, `choices`, `tooltip`, `group` | Editor behaviour |
| `setter` | Qt method called in preview and generated code (`addItems` clears first in preview) |
| `code_map` / `enum` / `to_code` | Turn a value into a Python expression (`enum="QLineEdit.EchoMode"` + member names) |
| `qt_default` | Skip emitting the setter when the value equals Qt's default (cleaner code) |
| `keep_empty` | Emit even for empty strings/lists |
| `preview` | `False` to skip on the canvas (e.g. `visible`) |

Choice values are validated against `choices`, so a crafted project file cannot inject code through them.

### Custom widgets
Write the class once as a string, execute it for the preview and ship it with `support_code`
(see `plugins/extra_controls` and the `component` scaffold template):

```python
from waterpy.registry import qt_namespace
CODE = '''
class Badge(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
'''
ns = dict(qt_namespace()); exec(CODE, ns); Badge = ns["Badge"]
spec = ComponentSpec("Badge", "Badge", module=None, support_code=CODE,
                     preview_factory=lambda parent: Badge(parent),
                     properties=[PropertySpec("text", "Text", "str", "NEW", setter="setText")])
```

## 6. Templates, transforms and exporters

```python
api.register_template("Two buttons", [
    {"type": "Button", "name": "btn_ok", "text": "OK", "x": 20, "y": 20, "events": {"clicked": "self.close()"}},
    {"type": "Button", "name": "btn_help", "text": "Help", "x": 170, "y": 20},
], "OK and Help", form={"title": "Dialog", "width": 320, "height": 120})

api.register_code_transform(lambda source, project: "# SPDX-License-Identifier: MIT\n" + source)
api.register_exporter("Control list (.txt)", "Text (*.txt)",
                      lambda project, path: path.write_text("\n".join(c["name"] for c in project["controls"])))
```

## 7. Project format (`.waterpy.json`, version 5)

```json
{ "format": "waterpy-project", "version": 5, "name": "Demo",
  "form": {"title": "Demo", "width": 900, "height": 600, "background": ""},
  "controls": [ {"type": "Button", "name": "btn_ok", "x": 20, "y": 20, "width": 140, "height": 36,
                 "text": "OK", "events": {"clicked": "self.close()"}} ],
  "custom_methods": "    def helper(self): ...", "source": "…", "source_dirty": false }
```
Older (v3/v4) projects open unchanged; `on_click`/`event_signal` are migrated to `events`.

## 8. Adding an AI provider

```python
from waterpy.ai.providers import Provider, AIError

class EchoProvider(Provider):
    id, name, needs_key, default_model, models = "echo", "Echo (demo)", False, "echo", ("echo",)
    def stream(self, cfg, system, messages, mode="chat", cancelled=lambda: False):
        yield "You said: " + messages[-1]["content"][-200:]

def register(api):
    api.register_ai_provider(EchoProvider())   # appears in AI Settings
```
`stream()` runs on a worker thread — never touch widgets there. Raise `AIError("…")` for user-facing errors.

## 9. SDK command line

```
python -m waterpy.sdk_tools templates                      # list scaffold templates
python -m waterpy.sdk_tools new my_plugin --template component --name "My Plugin" --dest plugins
python -m waterpy.sdk_tools validate plugins/my_plugin     # manifest, syntax, register()
python -m waterpy.sdk_tools package plugins/my_plugin -o dist   # → dist/my_plugin-0.1.0.wpplugin
python -m waterpy.sdk_tools events                         # host events
```
(`sdk/waterpy-plugin.py` is the same tool, runnable from anywhere.)

Templates: `basic` (menu + event), `component` (custom widget), `ai` (AI action + `ask_ai`), `panel` (dock
reacting to selection), `exporter` (export format + transform).

## 10. Compatibility

* **API 1 (v0.4) plugins still load**: `register(window)` receives the main window. They cannot be
  hot-unloaded (the manager shows *restart required*). `waterpy.plugin_sdk.add_menu_action / notify /
  add_designer_control` and `waterpy.designer.WIDGETS` remain available.
* Declare `PLUGIN_API_VERSION = "2.0"` (or `"api_version"` in `plugin.json`) to receive `HostAPI`.
  A plugin requiring a newer major API, or a newer host than `min_host`, is shown as *incompatible*.

## 11. Bundled examples

| Plugin | Shows |
|---|---|
| `hello_plugin.py` | Minimal single-file plugin, event hook |
| `starter_layout_plugin.py` | Templates + inserting controls through `api.project` |
| `theme_switcher_plugin.py` | Toolbar action, extra menu |
| `extra_controls/` | Three components incl. custom-painted widgets with `support_code`, a template using them |
| `form_linter/` | Dock panel driven by `code.generated`, selecting controls |
| `qt_ui_exporter/` | Exporter writing Qt Designer `.ui` XML |
| `code_tools/` | Code transform with settings, black formatting, designer context action |
| `ai_toolkit/` | AI quick actions, `open_ai_panel`, `ask_ai` writing README.md |

## 12. Good practice

* Keep `register()` fast; defer heavy imports into callbacks.
* Use `api.settings` instead of writing files next to the IDE.
* Never block the GUI thread; use `api.ask_ai` or your own `QThread` for slow work.
* Give components stable `kind` names — they are stored in users' project files.
* Validate with `sdk_tools validate` before publishing; ship as a `.wpplugin` archive.
