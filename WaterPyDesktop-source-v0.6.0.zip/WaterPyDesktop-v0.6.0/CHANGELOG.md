# Changelog

## 0.6.0
### Import / export
- Import Qt Designer `.ui`, WaterPy layout/template JSON, project ZIP (path-safe), CSV into grids, list/combo items.
- Export PyQt6 source, layout JSON, HTML mockup, PNG/PDF form image, Markdown/HTML documentation; save form as a
  reusable template (stored per user, shown under *My templates*).
### Tools
- Live in-IDE preview (F6) with uncaught exceptions routed to the Console; find/replace bar with regex and
  whole-word options; go to line/symbol outline; syntax check; snippet library in the Events panel, source
  toolbar and Edit menu; tab-order editor; window icon; Grid cell data property.
### Build & deployment
- Build Settings (name, version, company, copyright, icon, one-file, console, hidden imports, extra options) with
  a generated Windows version resource.
- Installer builder for user apps (Inno Setup 6 / NSIS 3) with shortcuts, uninstaller, licence page and
  per-user option; scripts are written even when no compiler is installed.
- WaterPyDesktop's own NSIS installer (components, file associations for `.wpplugin` / `.ui`, Apps & features
  entry), application icon, `build_windows.bat` producing EXE + setup, CI workflow publishing both.
- Opening a `.wpplugin` or `.ui` file with the IDE installs the plugin / imports the form.

## 0.5.0 — Professional Edition
### Toolbox
- Component registry (`waterpy/registry.py`) drives palette, preview, properties, events and codegen.
- 19 new built-in components; categorised palette with search, coloured glyph icons and tooltips.
- Real implementations for Media (Qt Multimedia), Web View (Qt WebEngine with HTML fallback), Image
  (`resource_path` helper works in PyInstaller builds), Ellipse/Rectangle (border, radius) and Line (vertical).
- Built-in form templates; plugins can add more.

### Designer
- Multi-selection, rubber band, undo/redo history, clipboard, duplicate, delete, align/distribute/same-size,
  centre in form, z-order, keyboard nudge/resize, outline (multi-select), minimap click-to-select.
- Form settings (title, size, background) and a window-style frame around the canvas.
- Schema-driven property grid; multi-selection editing.
- Events: any number of signals per control; helper-methods editor; *Show in source*; *Write with AI*.
- Canvas preview palette isolated from IDE theme (true WYSIWYG).

### Code
- New generator: auto-imports, `setup_ui()`, `on_<name>_<signal>` handlers, `main()`, enum values validated,
  plugin transforms with error isolation. Manual source edits are no longer overwritten silently.
- Code editor with highlighting, line numbers, auto-indent, block (un)indent and comment toggling.
- Console: Stop, *Go to line*, *Fix with AI*; syntax check before running.

### Plugins & SDK
- Plugin API 2.0 (`HostAPI`), package plugins with `plugin.json`, user plugin folder, hot (un)load with full
  roll-back, per-plugin settings, events, exporters, code transforms, dock panels, context-menu actions,
  AI actions/providers. Legacy API 1 plugins still load.
- Plugin Manager 2: details, errors, install `.py`/folder/`.zip`/`.wpplugin`, uninstall, reload, validate, package.
- `waterpy.sdk_tools` CLI + *New Plugin* wizard with five templates. Eight bundled example plugins.

### AI
- Providers: Anthropic, OpenAI, Gemini, Ollama, OpenAI-compatible, Offline — streaming over stdlib HTTP.
- Assistant panel with task modes, quick actions, context selection, diff review, layout apply, handler apply.
- AI Settings with key storage (OS keyring when available) and connection test.

### Other
- Docked layout persisted between sessions; four themes; preferences; recent projects; auto-save; ZIP export.
- Project format v5 (older projects open and migrate automatically).
- Headless test suite (73 tests).

## 0.4.0
- Additional class methods editor; more signal connections; project workflow fixes.

## 0.3.5
- Run/Build locate a real Python interpreter when the IDE is frozen.

## 0.3.4
- Interface refresh; complete project folder on save.
