from PySide6.QtWidgets import QApplication, QMainWindow, QPushButton, QWidget
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Test App')
        self.resize(1100, 760)
        self.form = QWidget(self)
        self.form.setObjectName("form")
        self.setCentralWidget(self.form)

        self.btn_add = QPushButton('Add', self.form)
        self.btn_add.setObjectName('btn_add')
        self.btn_add.setGeometry(20, 20, 100, 32)
        self.btn_add.setFont(QFont('Segoe UI', 10, 400))
        self.btn_add.setStyleSheet("color: #243247; background-color: #ffffff;")
        self.btn_add.clicked.connect(self.btn_add_clicked)

    def btn_add_clicked(self, *args):
        self.add_product("Phone")

# Additional user-defined class methods
    def add_product(self, name):
        self.statusBar().showMessage(f"Added {name}", 3000)

if __name__ == "__main__":
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec()
