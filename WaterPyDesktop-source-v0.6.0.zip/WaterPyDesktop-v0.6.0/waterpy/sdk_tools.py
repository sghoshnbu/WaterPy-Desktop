"""Plugin SDK tooling: scaffold, validate and package WaterPyDesktop plugins.

Command line::

    python -m waterpy.sdk_tools new my_plugin --template component --name "My Plugin"
    python -m waterpy.sdk_tools validate plugins/my_plugin
    python -m waterpy.sdk_tools package plugins/my_plugin -o dist/
    python -m waterpy.sdk_tools templates
    python -m waterpy.sdk_tools events
"""
from __future__ import annotations

import argparse
import ast
import json
import re
import sys
import zipfile
from pathlib import Path

ID_RE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")

_COMMON_HEAD = '''"""{name} — {description}"""
from waterpy.plugin_sdk import ComponentSpec, PropertySpec  # noqa: F401  (available for your plugin)

'''

TEMPLATES: dict[str, tuple[str, str]] = {
    "basic": ("Menu command + event hook", _COMMON_HEAD + '''
def register(api):
    """Called when the plugin is enabled.  Everything added through ``api`` is removed on disable."""
    api.add_menu_action("{name}: Say hello", lambda: api.notify("Hello from {name}!"), menu="Extensions")

    def on_saved(project, directory):
        api.log(f"Project {{project['name']}} saved to {{directory}}")

    api.on("project.saved", on_saved)


def unregister(api):
    """Optional: release resources you created yourself (timers, files, threads…)."""
'''),
    "component": ("New palette component with a custom widget class", '''"""{name} — {description}"""
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import QWidget

from waterpy.plugin_sdk import ComponentSpec, PropertySpec

# This source is emitted once into every generated application that uses the component,
# *and* executed here so the designer can show a live preview.
SUPPORT_CODE = """
class Badge(QWidget):
    \\"\\"\\"Rounded coloured badge with centred text.\\"\\"\\"
    def __init__(self, parent=None):
        super().__init__(parent)
        self._text, self._color = "NEW", QColor("#2563eb")

    def setText(self, text):
        self._text = str(text); self.update()

    def setColor(self, color):
        self._color = QColor(color); self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setBrush(self._color); p.setPen(Qt.PenStyle.NoPen)
        p.drawRoundedRect(self.rect(), self.height() / 2, self.height() / 2)
        p.setPen(QColor("white"))
        p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self._text)
        p.end()
"""
_ns = {{"Qt": Qt, "QColor": QColor, "QPainter": QPainter, "QWidget": QWidget}}
exec(SUPPORT_CODE, _ns)
Badge = _ns["Badge"]

SPEC = ComponentSpec(
    kind="{name} Badge", qt_class="Badge", module=None, category="Plugins", glyph="★",
    description="{description}", default_size=(90, 28),
    support_code=SUPPORT_CODE,
    properties=[
        PropertySpec("text", "Text", "str", "NEW", setter="setText", keep_empty=True),
        PropertySpec("color", "Badge colour", "color", "#2563eb", setter="setColor"),
    ],
    preview_factory=lambda parent: Badge(parent),
    preview_update=lambda w, p, ctx: (w.setText(p.get("text", "")), w.setColor(p.get("color") or "#2563eb")),
)


def register(api):
    api.register_component(SPEC)
'''),
    "ai": ("AI quick action + menu command using the configured model", _COMMON_HEAD + '''
PROMPT = ("Review the selected control {{selected}} and the current source. Suggest three concrete "
          "usability improvements for this form, each with a short code example.")


def register(api):
    # A one-click button in the AI Assistant panel.
    api.register_ai_action("UX review", PROMPT, mode="chat", tooltip="Ask the AI for usability ideas")

    # Or call the model yourself and handle the answer in code:
    def summarise():
        api.notify("Asking the AI…")
        api.ask_ai("Summarise what this application does in two sentences.",
                   lambda text: api.log(text), mode="chat")

    api.add_menu_action("{name}: Summarise app with AI", summarise)
'''),
    "panel": ("Dockable panel that reacts to selection changes", _COMMON_HEAD + '''
from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget


def register(api):
    panel = QWidget()
    layout = QVBoxLayout(panel)
    info = QLabel("Select a control on the form")
    info.setWordWrap(True)
    layout.addWidget(info)
    layout.addStretch(1)

    def on_selection(names):
        if not names:
            info.setText("Nothing selected")
            return
        c = api.project.find(names[-1]) or {{}}
        info.setText(f"<b>{{c.get('name')}}</b> ({{c.get('type')}})<br>"
                     f"position {{c.get('x')}}, {{c.get('y')}} · size {{c.get('width')}} × {{c.get('height')}}")

    api.on("selection.changed", on_selection)
    api.add_dock_panel("{name}", panel, area="right")
'''),
    "exporter": ("File → Export format + code transform", _COMMON_HEAD + '''
import json


def export_summary(project, path):
    lines = [f"# {{project['name']}}", "", "| Control | Type | Position | Size |", "|---|---|---|---|"]
    for c in project["controls"]:
        lines.append(f"| {{c['name']}} | {{c['type']}} | {{c['x']}},{{c['y']}} | {{c.get('width')}}×{{c.get('height')}} |")
    path.write_text("\\n".join(lines) + "\\n", encoding="utf-8")


def add_licence_header(source, project):
    header = "# SPDX-License-Identifier: MIT\\n"
    return source if source.startswith(header) else header + source


def register(api):
    api.register_exporter("Markdown control summary", "Markdown (*.md)", export_summary)
    if api.settings.get("add_header", False):
        api.register_code_transform(add_licence_header)
'''),
}


def scaffold(dest_root: Path, plugin_id: str, name: str = "", template: str = "basic", author: str = "",
             description: str = "") -> Path:
    if not ID_RE.match(plugin_id):
        raise ValueError("Plugin id must be lower-case letters, digits or underscores (2–64 chars), starting with a letter")
    if template not in TEMPLATES:
        raise ValueError(f"Unknown template {template!r}; choose from {', '.join(TEMPLATES)}")
    name = name or plugin_id.replace("_", " ").title()
    description = description or TEMPLATES[template][0]
    folder = Path(dest_root) / plugin_id
    if folder.exists():
        raise FileExistsError(f"{folder} already exists")
    folder.mkdir(parents=True)
    manifest = {"id": plugin_id, "name": name, "version": "0.1.0", "author": author, "description": description,
                "api_version": "2.0", "min_host": "0.5.0", "entry": "__init__.py", "homepage": ""}
    (folder / "plugin.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    code = TEMPLATES[template][1].format(name=name, description=description.replace('"', "'"))
    (folder / "__init__.py").write_text(code, encoding="utf-8")
    (folder / "README.md").write_text(f"# {name}\n\n{description}\n\nCreated from the `{template}` template of the "
                                      "WaterPyDesktop Plugin SDK. Edit `__init__.py`, then use **Plugins → Reload** "
                                      "in the IDE to hot-reload your changes.\n", encoding="utf-8")
    return folder


def validate(path: Path) -> list[str]:
    """Return a list of problems (empty list = valid)."""
    path = Path(path)
    issues: list[str] = []
    if path.is_file() and path.suffix == ".py":
        files, meta = [path], {}
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in tree.body:
                if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id.startswith("PLUGIN_"):
                    meta[node.targets[0].id[7:].lower()] = ast.literal_eval(node.value)
        except Exception as exc:
            return [f"{path.name}: {exc}"]
        entry = path
    elif path.is_dir():
        manifest = path / "plugin.json"
        if not manifest.is_file():
            issues.append("missing plugin.json")
            meta = {}
        else:
            try:
                meta = json.loads(manifest.read_text(encoding="utf-8"))
            except ValueError as exc:
                return [f"plugin.json is not valid JSON: {exc}"]
        entry = path / str(meta.get("entry") or "__init__.py")
        if not entry.is_file():
            issues.append(f"missing entry file {entry.name}")
        files = [p for p in path.rglob("*.py") if "__pycache__" not in p.parts]
    else:
        return [f"{path} is not a plugin file or folder"]
    for key in ("id", "name", "version"):
        if not meta.get(key):
            issues.append(f"metadata field '{key}' is missing")
    if meta.get("id") and not ID_RE.match(str(meta["id"])):
        issues.append("id must be lower-case letters, digits or underscores")
    if str(meta.get("api_version", "1.0")).split(".")[0] not in ("1", "2"):
        issues.append(f"unsupported api_version {meta.get('api_version')}")
    for f in files:
        try:
            compile(f.read_text(encoding="utf-8"), str(f), "exec")
        except SyntaxError as exc:
            issues.append(f"{f.name}:{exc.lineno}: {exc.msg}")
    if entry.is_file():
        try:
            tree = ast.parse(entry.read_text(encoding="utf-8"))
            if not any(isinstance(n, ast.FunctionDef) and n.name == "register" for n in tree.body):
                issues.append(f"{entry.name} must define register(api)")
        except SyntaxError:
            pass
    return issues


def package(path: Path, out_dir: Path | None = None) -> Path:
    path = Path(path)
    problems = validate(path)
    if problems:
        raise ValueError("Plugin is not valid:\n  " + "\n  ".join(problems))
    out_dir = Path(out_dir or path.parent)
    out_dir.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        target = out_dir / (path.stem + ".wpplugin")
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(path, path.name)
        return target
    meta = json.loads((path / "plugin.json").read_text(encoding="utf-8"))
    target = out_dir / f"{meta['id']}-{meta.get('version', '0.0.0')}.wpplugin"
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(path.rglob("*")):
            if f.is_file() and "__pycache__" not in f.parts and f.suffix != ".pyc":
                zf.write(f, Path(meta["id"]) / f.relative_to(path))
    return target


def main(argv=None):
    from .events import EVENTS
    parser = argparse.ArgumentParser(prog="waterpy-plugin", description="WaterPyDesktop Plugin SDK tools")
    sub = parser.add_subparsers(dest="cmd", required=True)
    n = sub.add_parser("new", help="create a plugin from a template")
    n.add_argument("id")
    n.add_argument("--name", default="")
    n.add_argument("--template", default="basic", choices=list(TEMPLATES))
    n.add_argument("--author", default="")
    n.add_argument("--description", default="")
    n.add_argument("--dest", default="plugins")
    v = sub.add_parser("validate", help="check a plugin file or folder")
    v.add_argument("path")
    pk = sub.add_parser("package", help="build an installable .wpplugin archive")
    pk.add_argument("path")
    pk.add_argument("-o", "--out", default=None)
    sub.add_parser("templates", help="list scaffold templates")
    sub.add_parser("events", help="list host events plugins can subscribe to")
    args = parser.parse_args(argv)
    try:
        if args.cmd == "new":
            print(f"Created {scaffold(Path(args.dest), args.id, args.name, args.template, args.author, args.description)}")
        elif args.cmd == "validate":
            problems = validate(Path(args.path))
            print("OK — plugin is valid" if not problems else "Problems:\n  " + "\n  ".join(problems))
            return 1 if problems else 0
        elif args.cmd == "package":
            print(f"Packaged {package(Path(args.path), Path(args.out) if args.out else None)}")
        elif args.cmd == "templates":
            for key, (desc, _) in TEMPLATES.items():
                print(f"{key:10} {desc}")
        elif args.cmd == "events":
            for key, sig in EVENTS.items():
                print(f"{key:20} {sig}")
    except (ValueError, FileExistsError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
