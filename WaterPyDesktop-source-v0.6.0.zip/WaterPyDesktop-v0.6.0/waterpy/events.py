"""Tiny publish/subscribe bus used by the IDE and by plugins.

Every subscriber is isolated: an exception in one plugin's handler is reported
through ``on_error`` and never stops the IDE or other plugins.
"""
from __future__ import annotations

import traceback
from typing import Any, Callable

#: Events emitted by the host.  Arguments are listed after the colon.
EVENTS = {
    "project.new": "project: dict",
    "project.opened": "project: dict",
    "project.saved": "project: dict, directory: Path",
    "code.generated": "source: str, project: dict",
    "run.before": "script_path: Path",
    "build.before": "pyinstaller_args: list  (mutable — append extra options)",
    "process.finished": "exit_code: int, mode: 'run' | 'build'",
    "selection.changed": "names: list[str]",
    "control.added": "control: dict",
    "theme.changed": "theme: str",
    "ai.response": "mode: str, text: str",
    "plugins.loaded": "plugin_ids: list[str]",
}


class EventBus:
    def __init__(self, on_error: Callable[[str], None] | None = None):
        self._subs: dict[str, list[tuple[Callable, Any]]] = {}
        self.on_error = on_error

    def subscribe(self, event: str, callback: Callable, owner: Any = None):
        self._subs.setdefault(event, []).append((callback, owner))
        return callback

    def unsubscribe(self, event: str, callback: Callable):
        self._subs[event] = [(cb, o) for cb, o in self._subs.get(event, []) if cb is not callback]

    def unsubscribe_owner(self, owner: Any):
        for event in list(self._subs):
            self._subs[event] = [(cb, o) for cb, o in self._subs[event] if o != owner]

    def emit(self, event: str, *args, **kwargs) -> list:
        results = []
        for callback, owner in list(self._subs.get(event, [])):
            try:
                results.append(callback(*args, **kwargs))
            except Exception as exc:
                if self.on_error:
                    self.on_error(f"[{owner or 'host'}] handler for '{event}' failed: {exc}\n{traceback.format_exc(limit=3)}")
        return results

    def subscribers(self, event: str) -> int:
        return len(self._subs.get(event, []))
