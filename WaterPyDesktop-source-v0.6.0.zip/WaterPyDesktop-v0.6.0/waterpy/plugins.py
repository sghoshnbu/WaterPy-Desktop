"""Plugin discovery, metadata, hot (un)loading and installation.

Two plugin layouts are supported:

* **single file**  ``plugins/my_plugin.py`` with module-level ``PLUGIN_*`` constants
* **package**      ``plugins/my_plugin/plugin.json`` + ``__init__.py`` (+ any other files)

Metadata is read *without executing* plugin code (JSON manifest or ``ast`` literal
parsing), so the Plugin Manager can list plugins safely before they are enabled.
Bundled plugins live next to the IDE; user-installed plugins live in a per-user folder
that is writable even when the IDE is installed in Program Files.
"""
from __future__ import annotations

import ast
import importlib.util
import json
import shutil
import sys
import tempfile
import traceback
import types
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from . import __version__

HOST_API_VERSION = "2.0"
PACKAGE_EXTENSIONS = (".zip", ".wpplugin")


@dataclass
class PluginInfo:
    id: str
    name: str
    path: Path
    kind: str = "file"                 # "file" | "package"
    version: str = "0.0.0"
    author: str = ""
    description: str = ""
    api_version: str = "1.0"
    homepage: str = ""
    min_host: str = ""
    bundled: bool = False
    enabled: bool = True
    status: str = "not loaded"         # loaded | disabled | error | not loaded | incompatible | restart required
    error: str = ""
    module: Any = None
    api: Any = None
    extra: dict = field(default_factory=dict)

    @property
    def is_v2(self) -> bool:
        try:
            return int(str(self.api_version).split(".")[0]) >= 2
        except ValueError:
            return False

    @property
    def file_name(self) -> str:
        return self.path.name


def _version_tuple(v: str):
    out = []
    for part in str(v).split("."):
        digits = "".join(ch for ch in part if ch.isdigit())
        out.append(int(digits or 0))
    return tuple(out + [0] * (3 - len(out)))


def read_file_metadata(path: Path) -> dict:
    """Extract ``PLUGIN_*`` constants and the module docstring without importing the file."""
    meta = {}
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except (SyntaxError, UnicodeDecodeError, OSError) as exc:
        return {"_syntax_error": str(exc)}
    doc = ast.get_docstring(tree)
    if doc:
        meta["description"] = doc.strip().splitlines()[0]
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            key = node.targets[0].id
            if key.startswith("PLUGIN_"):
                try:
                    meta[key[7:].lower()] = ast.literal_eval(node.value)
                except ValueError:
                    pass
    meta["has_register"] = any(isinstance(n, ast.FunctionDef) and n.name == "register" for n in tree.body)
    return meta


class PluginManager:
    def __init__(self, folder: Path, user_folder: Path | None = None):
        self.folder = Path(folder)                       # bundled plugins (v0.4 attribute name kept)
        self.user_folder = Path(user_folder) if user_folder else self.folder
        self.state_file = self.user_folder / "plugins_state.json"
        self.plugins: dict[str, PluginInfo] = {}
        self.loaded: list[str] = []                      # v0.4 compatibility: loaded file names
        self.errors: list[str] = []

    # -- state -------------------------------------------------------------------
    def _state(self) -> dict:
        try:
            return json.loads(self.state_file.read_text(encoding="utf-8"))
        except Exception:
            return {"disabled": []}

    def _save_state(self, state):
        self.user_folder.mkdir(parents=True, exist_ok=True)
        self.state_file.write_text(json.dumps(state, indent=2), encoding="utf-8")

    def set_enabled(self, plugin_id: str, enabled: bool, window=None):
        state = self._state()
        disabled = set(state.get("disabled", []))
        info = self.plugins.get(plugin_id) or next((p for p in self.plugins.values() if p.file_name == plugin_id), None)
        pid = info.id if info else plugin_id
        (disabled.discard if enabled else disabled.add)(pid)
        state["disabled"] = sorted(disabled)
        self._save_state(state)
        if info:
            info.enabled = enabled
            if window is not None:
                if enabled and info.status != "loaded":
                    self.load(info, window)
                elif not enabled and info.status == "loaded":
                    self.unload(info.id, window)

    def enabled_plugins(self) -> list[str]:
        if not self.plugins:
            self.scan()
        return [p.file_name for p in self.plugins.values() if p.enabled]

    # -- discovery -------------------------------------------------------------
    def scan(self) -> dict[str, PluginInfo]:
        disabled = set(self._state().get("disabled", []))
        found: dict[str, PluginInfo] = {}
        roots = [(self.folder, True)]
        if self.user_folder.resolve() != self.folder.resolve():
            roots.append((self.user_folder, False))
        for root, bundled in roots:
            root.mkdir(parents=True, exist_ok=True)
            for path in sorted(root.iterdir()):
                if path.name.startswith(("_", ".")):
                    continue
                info = self._describe(path, bundled)
                if info is None:
                    continue
                info.enabled = info.id not in disabled
                previous = self.plugins.get(info.id)
                if previous and previous.path == info.path and previous.status in ("loaded", "restart required"):
                    previous.enabled = info.enabled
                    info = previous                 # keep the live object (its HostAPI points at it)
                found[info.id] = info          # user folder overrides bundled ids
        for pid, prev in self.plugins.items():
            if pid not in found and prev.status == "loaded":
                found[pid] = prev               # keep track of loaded plugins whose files vanished
        self.plugins = found
        return found

    def _describe(self, path: Path, bundled: bool) -> PluginInfo | None:
        if path.is_file() and path.suffix == ".py":
            meta = read_file_metadata(path)
            info = PluginInfo(id=str(meta.get("id") or path.stem), name=str(meta.get("name") or path.stem.replace("_", " ").title()),
                              path=path, kind="file", bundled=bundled)
        elif path.is_dir() and (path / "plugin.json").is_file():
            try:
                meta = json.loads((path / "plugin.json").read_text(encoding="utf-8"))
            except ValueError as exc:
                meta = {"_syntax_error": f"plugin.json: {exc}"}
            info = PluginInfo(id=str(meta.get("id") or path.name), name=str(meta.get("name") or path.name),
                              path=path, kind="package", bundled=bundled)
        elif path.is_dir() and (path / "__init__.py").is_file():
            meta = read_file_metadata(path / "__init__.py")
            info = PluginInfo(id=str(meta.get("id") or path.name), name=str(meta.get("name") or path.name),
                              path=path, kind="package", bundled=bundled)
        else:
            return None
        info.version = str(meta.get("version", info.version))
        info.author = str(meta.get("author", ""))
        info.description = str(meta.get("description", ""))
        info.api_version = str(meta.get("api_version", "1.0"))
        info.homepage = str(meta.get("homepage", ""))
        info.min_host = str(meta.get("min_host", ""))
        info.extra = {k: v for k, v in meta.items() if k not in info.__dataclass_fields__}
        if "_syntax_error" in meta:
            info.status, info.error = "error", meta["_syntax_error"]
        return info

    # -- loading ---------------------------------------------------------------
    def _module_name(self, info):
        return f"waterpy_plugins.{info.id}"

    def load(self, info: PluginInfo, window) -> bool:
        if info.status == "loaded":
            return True
        if _version_tuple(info.api_version)[0] > _version_tuple(HOST_API_VERSION)[0]:
            info.status, info.error = "incompatible", f"needs plugin API {info.api_version}; host provides {HOST_API_VERSION}"
            return False
        if info.min_host and _version_tuple(info.min_host) > _version_tuple(__version__):
            info.status, info.error = "incompatible", f"needs WaterPyDesktop {info.min_host}+"
            return False
        sys.modules.setdefault("waterpy_plugins", types.ModuleType("waterpy_plugins"))
        name = self._module_name(info)
        info.module, info.api = None, None
        try:
            if info.kind == "package":
                init = info.path / "__init__.py"
                entry = info.extra.get("entry")
                if entry and (info.path / entry).is_file():
                    init = info.path / entry
                spec = importlib.util.spec_from_file_location(name, init, submodule_search_locations=[str(info.path)])
            else:
                spec = importlib.util.spec_from_file_location(name, info.path)
            if not spec or not spec.loader:
                raise ImportError("cannot create import spec")
            module = importlib.util.module_from_spec(spec)
            sys.modules[name] = module
            spec.loader.exec_module(module)
            if info.kind == "file":  # refresh metadata from the live module
                info.api_version = str(getattr(module, "PLUGIN_API_VERSION", info.api_version))
            register = getattr(module, "register", None)
            if not callable(register):
                raise AttributeError("plugin has no register() function")
            info.module = module
            if info.is_v2:
                from .plugin_sdk import HostAPI
                info.api = HostAPI(window, info)
                register(info.api)
            else:
                info.api = None
                register(window)                    # legacy v1 plugin
            info.status, info.error = "loaded", ""
            return True
        except Exception as exc:
            if info.api is not None:
                try:
                    info.api._dispose()
                except Exception:
                    pass
            sys.modules.pop(name, None)
            info.module, info.api = None, None
            info.status = "error"
            info.error = f"{type(exc).__name__}: {exc}\n{traceback.format_exc(limit=4)}"
            return False

    def unload(self, plugin_id: str, window) -> bool:
        info = self.plugins.get(plugin_id)
        if not info or info.status != "loaded":
            return False
        if not info.is_v2:
            info.status = "restart required"
            return False
        try:
            unregister = getattr(info.module, "unregister", None)
            if callable(unregister):
                unregister(info.api)
        except Exception as exc:
            window.log(f"[{plugin_id}] unregister failed: {exc}", "error")
        try:
            info.api._dispose()
        finally:
            prefix = self._module_name(info)
            for mod in [m for m in sys.modules if m == prefix or m.startswith(prefix + ".")]:
                sys.modules.pop(mod, None)
            info.module, info.api = None, None
            info.status = "disabled" if not info.enabled else "not loaded"
        return True

    def reload(self, plugin_id: str, window) -> bool:
        info = self.plugins.get(plugin_id)
        if not info:
            return False
        if info.status == "loaded":
            self.unload(plugin_id, window)
        self.scan()
        info = self.plugins.get(plugin_id)
        return bool(info and info.enabled and self.load(info, window))

    def load_all(self, window):
        self.scan()
        for info in self.plugins.values():
            if info.enabled and info.status not in ("loaded", "error"):
                self.load(info, window)
            elif not info.enabled and info.status != "loaded":
                info.status = "disabled"
        self.loaded = [p.file_name for p in self.plugins.values() if p.status == "loaded"]
        self.errors = [f"{p.file_name}: {p.error.splitlines()[0] if p.error else p.status}"
                       for p in self.plugins.values() if p.status in ("error", "incompatible")]
        return self.loaded, self.errors

    def reload_all(self, window):
        for pid in [p.id for p in self.plugins.values() if p.status == "loaded"]:
            self.unload(pid, window)
        for info in self.plugins.values():
            if info.status == "error":
                info.status = "not loaded"
        return self.load_all(window)

    def discover(self, window):  # v0.4 name
        return self.load_all(window)

    # -- install / uninstall --------------------------------------------------
    def install(self, source: Path, window=None) -> PluginInfo:
        """Install a ``.py`` file, a plugin folder, or a ``.zip`` / ``.wpplugin`` archive."""
        source = Path(source)
        self.user_folder.mkdir(parents=True, exist_ok=True)
        if source.is_file() and source.suffix == ".py":
            target = self.user_folder / source.name
            if source.resolve() != target.resolve():
                shutil.copy2(source, target)
        elif source.is_dir():
            target = self.user_folder / source.name
            if target.exists():
                shutil.rmtree(target)
            shutil.copytree(source, target, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        elif source.is_file() and source.suffix.lower() in PACKAGE_EXTENSIONS:
            target = self._install_archive(source)
        else:
            raise ValueError("Choose a .py file, a plugin folder, or a .zip/.wpplugin package")
        self.scan()
        info = next((p for p in self.plugins.values() if p.path == target), None)
        if info is None:
            raise ValueError("The installed item is not a valid WaterPyDesktop plugin")
        if window is not None and info.enabled:
            if info.id in self.plugins and info.status == "loaded":
                self.unload(info.id, window)
            self.load(info, window)
        return info

    def _install_archive(self, archive: Path) -> Path:
        with zipfile.ZipFile(archive) as zf:
            names = [n for n in zf.namelist() if n and not n.endswith("/")]
            for n in names:
                p = Path(n)
                if p.is_absolute() or ".." in p.parts:
                    raise ValueError(f"Unsafe path in plugin archive: {n}")
            tops = {Path(n).parts[0] for n in names}
            with tempfile.TemporaryDirectory() as tmp:
                zf.extractall(tmp)
                tmp = Path(tmp)
                if (tmp / "plugin.json").is_file():
                    meta = json.loads((tmp / "plugin.json").read_text(encoding="utf-8"))
                    src, dest_name = tmp, str(meta.get("id") or archive.stem)
                elif len(tops) == 1 and (tmp / next(iter(tops))).is_dir():
                    src = tmp / next(iter(tops))
                    dest_name = src.name
                elif len(names) == 1 and names[0].endswith(".py"):
                    target = self.user_folder / Path(names[0]).name
                    shutil.copy2(tmp / names[0], target)
                    return target
                else:
                    raise ValueError("Archive must contain plugin.json, one plugin folder, or a single .py file")
                target = self.user_folder / dest_name
                if target.exists():
                    shutil.rmtree(target)
                shutil.copytree(src, target, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
                return target

    def uninstall(self, plugin_id: str, window=None):
        info = self.plugins.get(plugin_id)
        if not info:
            return
        if info.bundled:
            raise PermissionError("Bundled plugins cannot be removed; disable them instead.")
        if window is not None and info.status == "loaded":
            self.unload(plugin_id, window)
        if info.path.is_dir():
            shutil.rmtree(info.path)
        elif info.path.exists():
            info.path.unlink()
        self.plugins.pop(plugin_id, None)
