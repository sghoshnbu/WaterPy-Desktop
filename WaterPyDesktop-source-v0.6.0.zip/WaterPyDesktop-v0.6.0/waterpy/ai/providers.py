"""AI model back-ends.

All providers talk HTTP with the standard library (``urllib``) and stream tokens,
so no vendor SDK is required.  Plugins can add more back-ends with
``api.register_ai_provider(MyProvider())``.
"""
from __future__ import annotations

import json
import os
import socket
import ssl
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Callable, Iterator


class AIError(Exception):
    pass


@dataclass
class AIConfig:
    provider: str = "offline"
    model: str = ""
    api_key: str = ""
    base_url: str = ""
    temperature: float = 0.2
    max_tokens: int = 8000
    timeout: int = 180
    extra: dict = field(default_factory=dict)


Message = dict  # {"role": "user" | "assistant", "content": str}


def _post_stream(url: str, headers: dict, body: dict, timeout: int, cancelled: Callable[[], bool]) -> Iterator[str]:
    """POST JSON and yield decoded response lines as they arrive."""
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST",
                                 headers={"Content-Type": "application/json", "Accept": "text/event-stream, application/json", **headers})
    try:
        ctx = ssl.create_default_context()
        resp = urllib.request.urlopen(req, timeout=timeout, context=ctx) if url.startswith("https") else \
            urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")
        try:
            err = json.loads(detail)
            err = err.get("error", err)
            detail = err.get("message", detail) if isinstance(err, dict) else str(err)
        except ValueError:
            pass
        raise AIError(f"HTTP {exc.code}: {detail[:600]}") from None
    except urllib.error.URLError as exc:
        raise AIError(f"Cannot reach {url.split('/')[2] if '//' in url else url}: {exc.reason}") from None
    except (socket.timeout, TimeoutError):
        raise AIError("The AI service did not respond in time") from None
    with resp:
        for raw in resp:
            if cancelled():
                return
            line = raw.decode("utf-8", "replace").rstrip("\r\n")
            if line:
                yield line


def _sse_json(lines: Iterator[str]) -> Iterator[dict]:
    for line in lines:
        if not line.startswith("data:"):
            continue
        payload = line[5:].strip()
        if payload == "[DONE]":
            return
        try:
            yield json.loads(payload)
        except ValueError:
            continue


class Provider:
    id = "base"
    name = "Base"
    needs_key = True
    key_env: tuple = ()
    default_model = ""
    default_base_url = ""
    models: tuple = ()
    key_url = ""
    notes = ""

    def stream(self, cfg: AIConfig, system: str, messages: list, mode: str = "chat",
               cancelled: Callable[[], bool] = lambda: False) -> Iterator[str]:
        raise NotImplementedError

    def env_key(self) -> str:
        for name in self.key_env:
            if os.getenv(name):
                return os.getenv(name)
        return ""

    def check(self, cfg: AIConfig):
        if self.needs_key and not cfg.api_key:
            raise AIError(f"No API key configured for {self.name}. Open AI Settings (⚙) and paste your key"
                          + (f", or set {self.key_env[0]}." if self.key_env else "."))
        if not cfg.model:
            raise AIError(f"Choose a model for {self.name} in AI Settings.")


class AnthropicProvider(Provider):
    id, name = "anthropic", "Anthropic Claude"
    key_env = ("ANTHROPIC_API_KEY",)
    default_model = "claude-sonnet-5-5"
    default_base_url = "https://api.anthropic.com"
    models = ("claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-5-5", "claude-fable-5-2")
    key_url = "https://console.anthropic.com/settings/keys"

    def stream(self, cfg, system, messages, mode="chat", cancelled=lambda: False):
        self.check(cfg)
        url = (cfg.base_url or self.default_base_url).rstrip("/") + "/v1/messages"
        body = {"model": cfg.model, "max_tokens": int(cfg.max_tokens), "system": system, "stream": True,
                "messages": [{"role": m["role"], "content": m["content"]} for m in messages],
                "temperature": float(cfg.temperature)}
        headers = {"x-api-key": cfg.api_key, "anthropic-version": "2023-06-01"}
        for event in _sse_json(_post_stream(url, headers, body, cfg.timeout, cancelled)):
            kind = event.get("type")
            if kind == "content_block_delta" and event.get("delta", {}).get("type") == "text_delta":
                yield event["delta"].get("text", "")
            elif kind == "error":
                raise AIError(event.get("error", {}).get("message", "Anthropic API error"))


class OpenAIProvider(Provider):
    id, name = "openai", "OpenAI"
    key_env = ("OPENAI_API_KEY",)
    default_model = "gpt-4.1-mini"
    default_base_url = "https://api.openai.com/v1"
    models = ("gpt-4.1-mini", "gpt-4.1", "gpt-4o-mini", "gpt-4o")
    key_url = "https://platform.openai.com/api-keys"

    def _body(self, cfg, system, messages):
        body = {"model": cfg.model, "stream": True,
                "messages": [{"role": "system", "content": system}] + [{"role": m["role"], "content": m["content"]} for m in messages]}
        if cfg.extra.get("send_temperature", True):
            body["temperature"] = float(cfg.temperature)
        if cfg.max_tokens:
            body["max_tokens" if self.id != "openai" else "max_completion_tokens"] = int(cfg.max_tokens)
        return body

    def stream(self, cfg, system, messages, mode="chat", cancelled=lambda: False):
        self.check(cfg)
        url = (cfg.base_url or self.default_base_url).rstrip("/") + "/chat/completions"
        headers = {"Authorization": f"Bearer {cfg.api_key}"} if cfg.api_key else {}
        for event in _sse_json(_post_stream(url, headers, self._body(cfg, system, messages), cfg.timeout, cancelled)):
            if "error" in event:
                err = event["error"]
                raise AIError(err.get("message", str(err)) if isinstance(err, dict) else str(err))
            for choice in event.get("choices", []):
                text = (choice.get("delta") or {}).get("content")
                if text:
                    yield text


class OpenAICompatibleProvider(OpenAIProvider):
    id, name = "openai_compatible", "OpenAI-compatible (LM Studio, OpenRouter, Groq…)"
    needs_key = False
    key_env = ("OPENAI_COMPATIBLE_API_KEY",)
    default_model = "local-model"
    default_base_url = "http://localhost:1234/v1"
    models = ()
    key_url = ""
    notes = "Any server exposing /v1/chat/completions. API key optional for local servers."


class GeminiProvider(Provider):
    id, name = "gemini", "Google Gemini"
    key_env = ("GEMINI_API_KEY", "GOOGLE_API_KEY")
    default_model = "gemini-2.5-flash"
    default_base_url = "https://generativelanguage.googleapis.com"
    models = ("gemini-2.5-flash", "gemini-2.5-pro")
    key_url = "https://aistudio.google.com/apikey"

    def stream(self, cfg, system, messages, mode="chat", cancelled=lambda: False):
        self.check(cfg)
        base = (cfg.base_url or self.default_base_url).rstrip("/")
        url = f"{base}/v1beta/models/{cfg.model}:streamGenerateContent?alt=sse"
        body = {"systemInstruction": {"parts": [{"text": system}]},
                "contents": [{"role": "model" if m["role"] == "assistant" else "user", "parts": [{"text": m["content"]}]}
                             for m in messages],
                "generationConfig": {"temperature": float(cfg.temperature), "maxOutputTokens": int(cfg.max_tokens)}}
        for event in _sse_json(_post_stream(url, {"x-goog-api-key": cfg.api_key}, body, cfg.timeout, cancelled)):
            if "error" in event:
                raise AIError(event["error"].get("message", "Gemini API error"))
            for cand in event.get("candidates", []):
                for part in (cand.get("content") or {}).get("parts", []):
                    if part.get("text"):
                        yield part["text"]


class OllamaProvider(Provider):
    id, name = "ollama", "Ollama (local, free)"
    needs_key = False
    default_model = "qwen2.5-coder"
    default_base_url = "http://localhost:11434"
    models = ("qwen2.5-coder", "llama3.1", "codellama", "mistral")
    key_url = "https://ollama.com/download"
    notes = "Runs models on your own PC. Install Ollama, then: ollama pull qwen2.5-coder"

    def stream(self, cfg, system, messages, mode="chat", cancelled=lambda: False):
        if not cfg.model:
            raise AIError("Choose an Ollama model in AI Settings.")
        url = (cfg.base_url or self.default_base_url).rstrip("/") + "/api/chat"
        body = {"model": cfg.model, "stream": True,
                "messages": [{"role": "system", "content": system}] + messages,
                "options": {"temperature": float(cfg.temperature), "num_predict": int(cfg.max_tokens)}}
        for line in _post_stream(url, {}, body, cfg.timeout, cancelled):
            try:
                event = json.loads(line)
            except ValueError:
                continue
            if event.get("error"):
                raise AIError(str(event["error"]))
            text = (event.get("message") or {}).get("content")
            if text:
                yield text
            if event.get("done"):
                return


class OfflineProvider(Provider):
    """Works without any account: answers from built-in templates."""
    id, name = "offline", "Offline (built-in templates, no AI account)"
    needs_key = False
    default_model = "templates"
    models = ("templates",)
    notes = "No network. Supports 'Design form' and 'Generate app' for common forms (login, contact, records, settings, dashboard)."

    def stream(self, cfg, system, messages, mode="chat", cancelled=lambda: False):
        from .service import offline_answer
        yield offline_answer(mode, messages[-1]["content"] if messages else "")


PROVIDERS: dict[str, Provider] = {}


def register_provider(provider: Provider):
    PROVIDERS[provider.id] = provider


def unregister_provider(provider_id: str):
    if provider_id not in ("offline",):
        PROVIDERS.pop(provider_id, None)


def get_provider(provider_id: str) -> Provider:
    return PROVIDERS.get(provider_id) or PROVIDERS["offline"]


for _p in (AnthropicProvider(), OpenAIProvider(), GeminiProvider(), OllamaProvider(), OpenAICompatibleProvider(), OfflineProvider()):
    register_provider(_p)
