"""Prompt construction, project context and response parsing (no Qt dependency)."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass

from ..registry import REGISTRY

SYSTEM_BASE = """You are the AI assistant built into WaterPyDesktop, a visual GUI builder that generates native \
PySide6 (Qt for Python 6) desktop applications for Windows.
Ground rules:
- Target Python 3.12 and PySide6 6.7+. Use fully-qualified Qt enums (e.g. Qt.AlignmentFlag.AlignCenter).
- The generated app defines `class MainWindow(QMainWindow)` with a central `self.form` widget; controls are \
attributes such as `self.btn_save` positioned with setGeometry. Event handlers are methods named \
`on_<control>_<signal>` and helper methods live on the same class.
- Prefer clear, well-structured, beginner-readable code with short comments; validate user input; never block \
the GUI thread with long work.
- Never claim you ran or tested code. If something is ambiguous, state your assumption briefly.
- When you return code, return complete runnable code in a single fenced block unless told otherwise."""


@dataclass
class Mode:
    key: str
    label: str
    instruction: str
    result: str = "text"       # text | code | layout | handler
    needs_source: bool = True


MODES: dict[str, Mode] = {m.key: m for m in [
    Mode("chat", "Chat", "Answer the user's question about their project. Be concise and practical."),
    Mode("design_form", "Design form", """Design a form layout for the request. Respond with ONLY one ```json fenced block \
containing an object: {"form": {"title": str, "width": int, "height": int}, "controls": [ ... ], \
"custom_methods": "<python methods indented 4 spaces, or empty>"}.
Each control is {"type": <component type>, "name": <snake_case identifier>, "x": int, "y": int, "width": int, \
"height": int, ...component properties..., "events": {"<signal>": "<python statements for the handler body>"}}.
Use ONLY the component types, property keys and signals in the catalogue below. Lay controls out on an 8-px grid with \
consistent margins (24 px), aligned labels and inputs, and no overlaps. Keep event code short; put longer logic in \
custom_methods and call it (e.g. "self.save_record()").""", result="layout", needs_source=False),
    Mode("generate_app", "Generate app", "Write a complete, runnable single-file PySide6 application (main.py) that fulfils "
         "the request. Return it in one ```python block, followed by at most three bullet notes.", result="code", needs_source=False),
    Mode("modify_source", "Modify source", "Apply the requested change to the CURRENT SOURCE. Return the COMPLETE updated "
         "file in one ```python block, then a short bullet list of what changed.", result="code"),
    Mode("fix_error", "Fix error", "The program failed. Using the CONSOLE OUTPUT and CURRENT SOURCE, explain the root cause "
         "in 1–3 sentences, then return the COMPLETE corrected file in one ```python block.", result="code"),
    Mode("event_handler", "Write event handler", "Write ONLY the body statements of the event handler described (no `def` "
         "line, no class), using `self.<control>` attributes that exist in the form. Return them in one ```python block.",
         result="handler"),
    Mode("explain", "Explain (teaching)", "Explain the code for a learner: start with a one-paragraph overview, then walk "
         "through the important parts step by step, naming the Qt classes and signals involved. End with two short "
         "exercises the learner could try to extend the program."),
    Mode("review", "Code review", "Review the CURRENT SOURCE for bugs, crashes, poor UX, accessibility and maintainability. "
         "Give a prioritised list (High/Medium/Low) with concrete fixes and small code snippets."),
]}

DEFAULT_QUICK_ACTIONS = [
    ("Design a form…", "design_form", "", "Describe a screen and let the AI lay it out on the designer"),
    ("Generate full app…", "generate_app", "", "Create a complete main.py from a description"),
    ("Explain this code", "explain", "Explain how the current application works.", "Step-by-step teaching explanation"),
    ("Fix last error", "fix_error", "Fix the error shown in the console output.", "Use the console traceback to repair the code"),
    ("Review code", "review", "Review the current source.", "Bugs, UX and maintainability review"),
    ("Add comments", "modify_source", "Add clear docstrings and comments throughout the current source without changing behaviour.", ""),
    ("Handler for selection", "event_handler", "Write a sensible handler for the selected control's main event.", ""),
]


def component_catalogue() -> str:
    lines = []
    for spec in REGISTRY.specs():
        props = [f"{p.key}:{p.type}" + (f"({'|'.join(map(str, p.choices))})" if p.choices else "")
                 for p in spec.properties]
        sig = ", ".join(spec.signals) or "—"
        lines.append(f"- {spec.kind} [{spec.qt_class}] size≈{spec.default_size[0]}x{spec.default_size[1]}; "
                     f"props: {', '.join(props) or '—'}; signals: {sig}")
    lines.append("Common props for every visual control: text colour 'foreground' and 'background' (#RRGGBB), "
                 "font_family, font_size (pt), bold, italic, tooltip, enabled, stylesheet (extra Qt CSS).")
    return "\n".join(lines)


def build_system(mode_key: str) -> str:
    mode = MODES.get(mode_key, MODES["chat"])
    text = SYSTEM_BASE + "\n\nTASK MODE: " + mode.label + "\n" + mode.instruction
    if mode.key == "design_form":
        text += "\n\nCOMPONENT CATALOGUE:\n" + component_catalogue()
    return text


def build_user_message(request: str, mode_key: str, ctx: dict, include: dict | None = None) -> str:
    include = {"form": True, "source": True, "console": False, **(include or {})}
    mode = MODES.get(mode_key, MODES["chat"])
    parts = []
    project = ctx.get("project") or {}
    if include.get("form"):
        form = project.get("form") or {}
        controls = [{k: v for k, v in c.items() if k in ("type", "name", "x", "y", "width", "height", "text", "items", "events", "title")}
                    for c in project.get("controls", [])]
        parts.append(f"PROJECT: {project.get('name', 'Untitled')} — window '{form.get('title', '')}' "
                     f"{form.get('width', '?')}x{form.get('height', '?')}\nFORM CONTROLS (JSON):\n{json.dumps(controls, ensure_ascii=False)[:12000]}")
    selected = ctx.get("selected")
    if selected:
        spec = REGISTRY.get(selected.get("type", ""))
        signals = ", ".join(spec.signals) if spec else ""
        parts.append(f"SELECTED CONTROL: {selected.get('name')} ({selected.get('type')}); available signals: {signals}"
                     + (f"; target signal: {ctx.get('signal')}" if ctx.get("signal") else ""))
    if include.get("source") and mode.needs_source and ctx.get("source"):
        parts.append("CURRENT SOURCE (main.py):\n```python\n" + ctx["source"][:30000] + "\n```")
    if (include.get("console") or mode.key == "fix_error") and ctx.get("console"):
        parts.append("CONSOLE OUTPUT (most recent last):\n```\n" + ctx["console"][-6000:] + "\n```")
    parts.append("REQUEST:\n" + (request.strip() or mode.label))
    return "\n\n".join(parts)


def fill_placeholders(prompt: str, ctx: dict) -> str:
    selected = ctx.get("selected") or {}
    project = ctx.get("project") or {}
    return (prompt.replace("{selected}", f"{selected.get('name', '(none)')} ({selected.get('type', '')})")
                  .replace("{project}", str(project.get("name", "")))
                  .replace("{source}", ctx.get("source", "")[:20000]))


# ---------------------------------------------------------------------------
# Response parsing
# ---------------------------------------------------------------------------
FENCE_RE = re.compile(r"```([\w+-]*)[^\n]*\n(.*?)(?:```|\Z)", re.S)


def code_blocks(text: str) -> list[tuple[str, str]]:
    return [(m.group(1).lower(), m.group(2).rstrip()) for m in FENCE_RE.finditer(text or "")]


def extract_python(text: str) -> str:
    blocks = code_blocks(text)
    py = [b for lang, b in blocks if lang in ("python", "py", "python3")]
    candidates = py or [b for lang, b in blocks if lang in ("",)]
    if candidates:
        return max(candidates, key=len)
    stripped = (text or "").strip()
    try:
        compile(stripped, "<ai>", "exec")
        return stripped
    except SyntaxError:
        return ""


def _first_json_object(text: str) -> str:
    start = text.find("{")
    while start != -1:
        depth, in_str, esc = 0, False, False
        for i in range(start, len(text)):
            ch = text[i]
            if in_str:
                esc = (ch == "\\") and not esc
                if ch == '"' and not esc:
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return text[start:i + 1]
        start = text.find("{", start + 1)
    return ""


def extract_layout(text: str) -> tuple[dict | None, list[str]]:
    """Parse and sanitise an AI-designed layout. Returns (layout | None, warnings)."""
    warnings: list[str] = []
    raw = None
    for lang, block in code_blocks(text):
        if lang in ("json", ""):
            try:
                raw = json.loads(block)
                break
            except ValueError:
                continue
    if raw is None:
        snippet = _first_json_object(text or "")
        if snippet:
            try:
                raw = json.loads(snippet)
            except ValueError as exc:
                return None, [f"Could not parse layout JSON: {exc}"]
    if raw is None:
        return None, ["The response did not contain a JSON layout."]
    if isinstance(raw, list):
        raw = {"controls": raw}
    controls = []
    for i, c in enumerate(raw.get("controls") or []):
        if not isinstance(c, dict):
            continue
        kind = REGISTRY.resolve_kind(str(c.get("type", "")))
        spec = REGISTRY.get(kind)
        if spec is None:
            warnings.append(f"Skipped unknown component type {c.get('type')!r}")
            continue
        c = dict(c)
        c["type"] = kind
        for key in ("x", "y", "width", "height"):
            try:
                c[key] = max(0 if key in ("x", "y") else 4, min(8000, int(float(c.get(key, 0 if key in "xy" else 40)))))
            except (TypeError, ValueError):
                c.pop(key, None)
        events = c.get("events") or {}
        if isinstance(events, dict):
            bad = [s for s in events if s not in spec.signals]
            for s in bad:
                warnings.append(f"{c.get('name', kind)}: ignored unknown signal {s!r}")
            c["events"] = {s: str(v) for s, v in events.items() if s in spec.signals}
        else:
            c["events"] = {}
        controls.append(c)
    form = raw.get("form") if isinstance(raw.get("form"), dict) else {}
    clean_form = {}
    if form.get("title"):
        clean_form["title"] = str(form["title"])[:200]
    for key in ("width", "height"):
        if key in form:
            try:
                clean_form[key] = max(200, min(8000, int(form[key])))
            except (TypeError, ValueError):
                pass
    if form.get("background"):
        clean_form["background"] = str(form["background"])
    methods = raw.get("custom_methods") or ""
    if methods and not isinstance(methods, str):
        methods = "\n".join(map(str, methods))
    if not controls:
        warnings.append("The layout contained no usable controls.")
    return {"form": clean_form, "controls": controls, "custom_methods": methods}, warnings


# ---------------------------------------------------------------------------
# Offline fallback (no account needed)
# ---------------------------------------------------------------------------
_KEYWORDS = [
    ("Login Form", ("login", "sign in", "signin", "password", "log in")),
    ("Contact Form", ("contact", "feedback", "enquiry", "inquiry", "message")),
    ("Data Entry (CRUD)", ("crud", "record", "inventory", "table", "entry", "stock", "product")),
    ("Settings Panel", ("setting", "preference", "option", "config")),
    ("Dashboard", ("dashboard", "kpi", "overview", "stats", "statistics", "report")),
]


def _match_template(request: str):
    req = request.lower()
    for name, words in _KEYWORDS:
        if any(w in req for w in words):
            return REGISTRY.template(name)
    return None


def offline_answer(mode: str, request: str) -> str:
    req = request.split("REQUEST:")[-1]
    tpl = _match_template(req)
    names = ", ".join(n for n, _ in _KEYWORDS)
    if mode == "design_form":
        if not tpl:
            return ("Offline mode can lay out these forms: " + names + ". Mention one of them, or connect an AI provider "
                    "in AI Settings (⚙) to design any form you describe.")
        layout = {"form": tpl.form, "controls": tpl.controls, "custom_methods": tpl.custom_methods}
        return f"Here is a **{tpl.name}** layout (offline template).\n\n```json\n{json.dumps(layout, indent=2)}\n```"
    if mode == "generate_app":
        from ..codegen import generate_python
        if tpl:
            code = generate_python(tpl.name.replace(" ", ""), tpl.form.get("title", tpl.name), tpl.controls,
                                   tpl.custom_methods, form=tpl.form)
            return f"Generated from the offline **{tpl.name}** template:\n\n```python\n{code}```"
        code = generate_python("HelloApp", "Hello PySide6", [
            {"type": "Label", "name": "lbl_hello", "text": "Hello from PySide6!", "x": 24, "y": 24, "width": 320, "height": 32, "font_size": 14},
            {"type": "Button", "name": "btn_click", "text": "Click me", "x": 24, "y": 72, "width": 140, "height": 36,
             "events": {"clicked": "self.btn_click.setText('It works!')"}}])
        return ("Offline starter window (connect an AI provider for custom apps; offline templates: " + names + "):\n\n```python\n"
                + code + "```")
    return ("**Offline mode** — no AI provider is configured, so I can only use built-in templates.\n\n"
            "Open **AI Settings (⚙)** and choose a provider:\n"
            "- **Anthropic Claude**, **OpenAI** or **Google Gemini** with your API key, or\n"
            "- **Ollama** to run a free model locally on this PC (no key needed).\n\n"
            "Offline you can still use **Design form** / **Generate app** for: " + names + ".")
