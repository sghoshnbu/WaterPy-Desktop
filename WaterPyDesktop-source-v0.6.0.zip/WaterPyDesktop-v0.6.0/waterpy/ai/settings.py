"""AI configuration storage and the AI Settings dialog."""
from __future__ import annotations

from PySide6.QtCore import QSettings, QThread, QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox, QFormLayout,
                               QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QSpinBox, QVBoxLayout)

from .providers import PROVIDERS, AIConfig, AIError, get_provider

try:  # optional: store API keys in the OS credential vault (Windows Credential Manager)
    import keyring  # type: ignore
except Exception:  # pragma: no cover
    keyring = None

SERVICE = "WaterPyDesktop-AI"


def _settings() -> QSettings:
    return QSettings("WaterPyDesktop", "WaterPyDesktop")


def get_key(provider_id: str) -> str:
    if keyring is not None:
        try:
            value = keyring.get_password(SERVICE, provider_id)
            if value:
                return value
        except Exception:
            pass
    value = str(_settings().value(f"ai/{provider_id}/api_key", "") or "")
    return value or get_provider(provider_id).env_key()


def set_key(provider_id: str, key: str) -> str:
    """Persist a key. Returns where it was stored."""
    if keyring is not None:
        try:
            if key:
                keyring.set_password(SERVICE, provider_id, key)
            else:
                try:
                    keyring.delete_password(SERVICE, provider_id)
                except Exception:
                    pass
            _settings().remove(f"ai/{provider_id}/api_key")
            return "the operating-system credential store"
        except Exception:
            pass
    _settings().setValue(f"ai/{provider_id}/api_key", key)
    return "WaterPyDesktop settings (install the 'keyring' package to use the OS credential store)"


def active_provider_id() -> str:
    pid = str(_settings().value("ai/provider", "") or "")
    if pid in PROVIDERS:
        return pid
    for candidate in ("anthropic", "openai", "gemini"):     # auto-detect keys from the environment
        if PROVIDERS[candidate].env_key():
            return candidate
    return "offline"


def load_config(provider_id: str | None = None) -> AIConfig:
    pid = provider_id or active_provider_id()
    prov = get_provider(pid)
    s = _settings()
    return AIConfig(
        provider=prov.id,
        model=str(s.value(f"ai/{prov.id}/model", prov.default_model) or prov.default_model),
        api_key=get_key(prov.id),
        base_url=str(s.value(f"ai/{prov.id}/base_url", prov.default_base_url) or prov.default_base_url),
        temperature=float(s.value("ai/temperature", 0.2)),
        max_tokens=int(s.value("ai/max_tokens", 8000)),
        timeout=int(s.value("ai/timeout", 180)),
    )


def save_config(cfg: AIConfig, make_active: bool = True) -> str:
    s = _settings()
    if make_active:
        s.setValue("ai/provider", cfg.provider)
    s.setValue(f"ai/{cfg.provider}/model", cfg.model)
    s.setValue(f"ai/{cfg.provider}/base_url", cfg.base_url)
    s.setValue("ai/temperature", cfg.temperature)
    s.setValue("ai/max_tokens", cfg.max_tokens)
    s.setValue("ai/timeout", cfg.timeout)
    return set_key(cfg.provider, cfg.api_key)


class _TestThread(QThread):
    result = Signal(bool, str)

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg

    def run(self):
        try:
            prov = get_provider(self.cfg.provider)
            text = "".join(prov.stream(self.cfg, "Reply with the single word: ready", [{"role": "user", "content": "ping"}]))
            self.result.emit(True, text.strip()[:200] or "(empty reply)")
        except AIError as exc:
            self.result.emit(False, str(exc))
        except Exception as exc:  # pragma: no cover
            self.result.emit(False, f"{type(exc).__name__}: {exc}")


class AISettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AI Settings")
        self.setMinimumWidth(560)
        lay = QVBoxLayout(self)
        intro = QLabel("Choose the AI model WaterPyDesktop uses for designing forms, generating and fixing code, and "
                       "explaining programs. Your project context is sent only to the provider you select.")
        intro.setWordWrap(True)
        lay.addWidget(intro)
        form = QFormLayout()
        self.provider = QComboBox()
        for pid, prov in PROVIDERS.items():
            self.provider.addItem(prov.name, pid)
        self.model = QComboBox()
        self.model.setEditable(True)
        self.key = QLineEdit()
        self.key.setEchoMode(QLineEdit.EchoMode.Password)
        self.key.setPlaceholderText("Paste API key")
        show = QCheckBox("Show")
        show.toggled.connect(lambda on: self.key.setEchoMode(QLineEdit.EchoMode.Normal if on else QLineEdit.EchoMode.Password))
        key_row = QHBoxLayout()
        key_row.addWidget(self.key, 1)
        key_row.addWidget(show)
        self.get_key = QPushButton("Get a key…")
        self.get_key.clicked.connect(self._open_key_page)
        key_row.addWidget(self.get_key)
        self.base_url = QLineEdit()
        self.temperature = QDoubleSpinBox()
        self.temperature.setRange(0, 2)
        self.temperature.setSingleStep(0.1)
        self.max_tokens = QSpinBox()
        self.max_tokens.setRange(256, 128000)
        self.max_tokens.setSingleStep(1000)
        self.timeout = QSpinBox()
        self.timeout.setRange(10, 900)
        self.timeout.setSuffix(" s")
        self.notes = QLabel()
        self.notes.setWordWrap(True)
        self.notes.setStyleSheet("color:#64748b;")
        form.addRow("Provider", self.provider)
        form.addRow("Model", self.model)
        form.addRow("API key", key_row)
        form.addRow("Base URL", self.base_url)
        form.addRow("Temperature", self.temperature)
        form.addRow("Max output tokens", self.max_tokens)
        form.addRow("Timeout", self.timeout)
        lay.addLayout(form)
        lay.addWidget(self.notes)
        self.status = QLabel("")
        self.status.setWordWrap(True)
        lay.addWidget(self.status)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        self.test_btn = buttons.addButton("Test connection", QDialogButtonBox.ButtonRole.ActionRole)
        self.test_btn.clicked.connect(self._test)
        buttons.accepted.connect(self._save)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)
        self.provider.currentIndexChanged.connect(self._load_provider)
        idx = self.provider.findData(active_provider_id())
        self.provider.setCurrentIndex(max(0, idx))
        self._load_provider()
        self._thread = None

    def _pid(self):
        return self.provider.currentData()

    def _load_provider(self, *args):
        cfg = load_config(self._pid())
        prov = get_provider(self._pid())
        self.model.clear()
        self.model.addItems(list(prov.models))
        self.model.setCurrentText(cfg.model)
        self.key.setText(cfg.api_key)
        self.key.setEnabled(prov.id != "offline")
        self.base_url.setText(cfg.base_url)
        self.base_url.setEnabled(prov.id != "offline")
        self.temperature.setValue(cfg.temperature)
        self.max_tokens.setValue(cfg.max_tokens)
        self.timeout.setValue(cfg.timeout)
        self.get_key.setVisible(bool(prov.key_url))
        env = f" Environment variable: {', '.join(prov.key_env)}." if prov.key_env else ""
        self.notes.setText((prov.notes or "") + env)
        self.status.clear()

    def _config(self) -> AIConfig:
        return AIConfig(provider=self._pid(), model=self.model.currentText().strip(), api_key=self.key.text().strip(),
                        base_url=self.base_url.text().strip(), temperature=self.temperature.value(),
                        max_tokens=self.max_tokens.value(), timeout=self.timeout.value())

    def _open_key_page(self):
        url = get_provider(self._pid()).key_url
        if url:
            QDesktopServices.openUrl(QUrl(url))

    def _test(self):
        self.status.setText("Testing…")
        self.test_btn.setEnabled(False)
        self._thread = _TestThread(self._config())
        self._thread.result.connect(self._tested)
        self._thread.start()

    def _tested(self, ok, message):
        self.test_btn.setEnabled(True)
        colour = "#15803d" if ok else "#b91c1c"
        self.status.setText(f"<span style='color:{colour}'>{'✔ Connected' if ok else '✖ Failed'}:</span> {message}")

    def _save(self):
        where = save_config(self._config())
        if self._pid() != "offline" and self.key.text().strip():
            QMessageBox.information(self, "AI Settings", f"Saved. The API key is stored in {where}.")
        self.accept()
