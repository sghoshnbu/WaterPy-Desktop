"""AI integration for WaterPyDesktop: providers, prompts and the assistant panel."""
from .providers import PROVIDERS, AIConfig, AIError, Provider, get_provider, register_provider  # noqa: F401
from .service import MODES, extract_layout, extract_python  # noqa: F401
