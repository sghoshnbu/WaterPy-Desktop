"""AI Assistant panel: streaming chat, task modes, quick actions and safe apply."""
from __future__ import annotations

import difflib
import html

from PySide6.QtCore import QPoint, QRect, QSize, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QFont, QKeySequence, QShortcut
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QHBoxLayout, QLabel,
                               QLayout, QMenu, QPlainTextEdit, QPushButton, QTextBrowser, QToolButton,
                               QVBoxLayout, QWidget)

from .providers import AIError, get_provider
from .service import (DEFAULT_QUICK_ACTIONS, MODES, build_system, build_user_message, extract_layout, extract_python,
                      fill_placeholders)
from .settings import AISettingsDialog, load_config


class AIWorker(QThread):
    chunk = Signal(str)
    succeeded = Signal(str)
    failed = Signal(str)

    def __init__(self, cfg, system, messages, mode):
        super().__init__()
        self.cfg, self.system, self.messages, self.mode = cfg, system, messages, mode
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def run(self):
        parts = []
        try:
            provider = get_provider(self.cfg.provider)
            for piece in provider.stream(self.cfg, self.system, self.messages, self.mode, cancelled=lambda: self._cancel):
                if self._cancel:
                    break
                parts.append(piece)
                self.chunk.emit(piece)
            self.succeeded.emit("".join(parts))
        except AIError as exc:
            self.failed.emit(str(exc))
        except Exception as exc:  # pragma: no cover - defensive
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class FlowLayout(QLayout):
    """Wraps child widgets onto new lines (used for quick-action chips)."""
    def __init__(self, parent=None, spacing=4):
        super().__init__(parent)
        self._items = []
        self.setSpacing(spacing)
        self.setContentsMargins(0, 0, 0, 0)

    def addItem(self, item):
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, i):
        return self._items[i] if 0 <= i < len(self._items) else None

    def takeAt(self, i):
        return self._items.pop(i) if 0 <= i < len(self._items) else None

    def expandingDirections(self):
        return Qt.Orientation(0)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return self._layout(QRect(0, 0, width, 0), True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._layout(rect, False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        size = QSize()
        for item in self._items:
            size = size.expandedTo(item.minimumSize())
        return size

    def _layout(self, rect, test):
        x, y, line = rect.x(), rect.y(), 0
        for item in self._items:
            hint = item.sizeHint()
            nx = x + hint.width() + self.spacing()
            if nx - self.spacing() > rect.right() and line > 0:
                x, y = rect.x(), y + line + self.spacing()
                nx, line = x + hint.width() + self.spacing(), 0
            if not test:
                item.setGeometry(QRect(QPoint(x, y), hint))
            x, line = nx, max(line, hint.height())
        return y + line - rect.y()


class DiffDialog(QDialog):
    """Shows a colourised unified diff and asks before replacing the source."""
    def __init__(self, old: str, new: str, title="Review AI changes", parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(900, 640)
        lay = QVBoxLayout(self)
        diff = list(difflib.unified_diff(old.splitlines(), new.splitlines(), "current main.py", "AI proposal", lineterm="", n=3))
        added = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
        removed = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))
        lay.addWidget(QLabel(f"<b>{added}</b> lines added, <b>{removed}</b> removed. The previous source stays in Undo (Ctrl+Z in the editor)."))
        view = QTextBrowser()
        view.setFont(QFont("Consolas", 9))
        rows = []
        for line in diff or ["(no differences)"]:
            esc = html.escape(line) or "&nbsp;"
            if line.startswith("+") and not line.startswith("+++"):
                rows.append(f"<div style='background:#dcfce7;color:#14532d'>{esc}</div>")
            elif line.startswith("-") and not line.startswith("---"):
                rows.append(f"<div style='background:#fee2e2;color:#7f1d1d'>{esc}</div>")
            elif line.startswith("@@"):
                rows.append(f"<div style='color:#6d28d9'>{esc}</div>")
            else:
                rows.append(f"<div style='color:#475569'>{esc}</div>")
        view.setHtml("<pre style='margin:0;white-space:pre'>" + "".join(rows) + "</pre>")
        lay.addWidget(view, 1)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        buttons.addButton("Apply changes", QDialogButtonBox.ButtonRole.AcceptRole)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)


class AIPanel(QWidget):
    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        self.history: list[dict] = []
        self.transcript: list[tuple[str, str, str]] = []   # role, mode, text
        self.worker: AIWorker | None = None
        self._bg_workers: list[AIWorker] = []
        self._quick: list[tuple] = []
        self.last_text, self.last_mode = "", "chat"
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(5)

        top = QHBoxLayout()
        self.provider_label = QLabel()
        self.provider_label.setStyleSheet("color:#64748b;")
        settings_btn = QToolButton()
        settings_btn.setText("⚙")
        settings_btn.setToolTip("AI Settings — provider, model, API key")
        settings_btn.clicked.connect(self.open_settings)
        top.addWidget(self.provider_label, 1)
        top.addWidget(settings_btn)
        lay.addLayout(top)

        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("Task"))
        self.mode = QComboBox()
        for key, mode in MODES.items():
            self.mode.addItem(mode.label, key)
        self.mode.currentIndexChanged.connect(self._mode_changed)
        mode_row.addWidget(self.mode, 1)
        self.quick_btn = QToolButton()
        self.quick_btn.setText("⚡ Quick actions")
        self.quick_btn.setObjectName("chip")
        self.quick_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.quick_menu = QMenu(self.quick_btn)
        self.quick_menu.setToolTipsVisible(True)
        self.quick_btn.setMenu(self.quick_menu)
        mode_row.addWidget(self.quick_btn)
        lay.addLayout(mode_row)

        self.quick_host = QWidget()                      # pinned chips for the most common actions
        self.quick_layout = FlowLayout(self.quick_host)
        lay.addWidget(self.quick_host)
        for label, mode, prompt, tip in DEFAULT_QUICK_ACTIONS:
            self.add_quick_action(label, prompt, mode, tip)
        for label, mode, prompt, tip in DEFAULT_QUICK_ACTIONS[:3]:
            chip = QToolButton()
            chip.setText(label)
            chip.setObjectName("chip")
            chip.setToolTip(tip)
            chip.clicked.connect(lambda checked=False, p=prompt, m=mode: self._quick_clicked(p, m))
            self.quick_layout.addWidget(chip)

        self.view = QTextBrowser()
        self.view.setOpenExternalLinks(True)
        self.view.setPlaceholderText("Ask about your project, design a form, generate or fix code…")
        lay.addWidget(self.view, 1)

        self.result_row = QHBoxLayout()
        self.apply_code_btn = QPushButton("Review && apply code…")
        self.apply_code_btn.clicked.connect(self.apply_code)
        self.apply_layout_btn = QPushButton("Apply layout to designer")
        self.apply_layout_btn.clicked.connect(self.apply_layout)
        self.apply_handler_btn = QPushButton("Use as event handler")
        self.apply_handler_btn.clicked.connect(self.apply_handler)
        copy_btn = QPushButton("Copy")
        copy_btn.clicked.connect(lambda: QApplication.clipboard().setText(self.last_text))
        for b in (self.apply_code_btn, self.apply_layout_btn, self.apply_handler_btn):
            b.setVisible(False)
            b.setObjectName("accentButton")
            self.result_row.addWidget(b)
        self.result_row.addStretch(1)
        self.result_row.addWidget(copy_btn)
        lay.addLayout(self.result_row)

        ctx_row = QHBoxLayout()
        ctx_row.addWidget(QLabel("Send:"))
        self.inc_form = QCheckBox("Form")
        self.inc_form.setChecked(True)
        self.inc_source = QCheckBox("Source")
        self.inc_source.setChecked(True)
        self.inc_console = QCheckBox("Console")
        for cb in (self.inc_form, self.inc_source, self.inc_console):
            ctx_row.addWidget(cb)
        ctx_row.addStretch(1)
        lay.addLayout(ctx_row)

        self.input = QPlainTextEdit()
        self.input.setPlaceholderText("Describe what you want…  (Ctrl+Enter to send)")
        self.input.setMaximumHeight(96)
        lay.addWidget(self.input)
        QShortcut(QKeySequence("Ctrl+Return"), self.input, activated=self.send)
        QShortcut(QKeySequence("Ctrl+Enter"), self.input, activated=self.send)

        btns = QHBoxLayout()
        self.send_btn = QPushButton("Send")
        self.send_btn.setObjectName("primaryButton")
        self.send_btn.clicked.connect(self.send)
        self.stop_btn = QPushButton("Stop")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stop)
        clear = QPushButton("New chat")
        clear.clicked.connect(self.clear)
        btns.addWidget(self.send_btn, 1)
        btns.addWidget(self.stop_btn)
        btns.addWidget(clear)
        lay.addLayout(btns)

        self._render_timer = QTimer(self)
        self._render_timer.setSingleShot(True)
        self._render_timer.setInterval(90)
        self._render_timer.timeout.connect(self._render)
        self.refresh_provider_label()
        self._render()

    # -- quick actions --------------------------------------------------------
    def add_quick_action(self, label, prompt, mode="chat", tooltip="", owner="builtin"):
        """Add an entry to the ⚡ Quick actions menu (plugins get their own section)."""
        if owner != "builtin" and not any(o == owner for o, _ in self._quick):
            self._quick.append((owner, self.quick_menu.addSection(owner.replace("_", " ").title())))
        action = self.quick_menu.addAction(label)
        action.setToolTip(tooltip or prompt or MODES.get(mode, MODES["chat"]).label)
        action.triggered.connect(lambda checked=False: self._quick_clicked(prompt, mode))
        self._quick.append((owner, action))
        return action

    def remove_quick_actions(self, owner):
        for o, action in list(self._quick):
            if o == owner:
                self.quick_menu.removeAction(action)
                action.deleteLater()
                self._quick.remove((o, action))

    def _quick_clicked(self, prompt, mode):
        idx = self.mode.findData(mode)
        if idx >= 0:
            self.mode.setCurrentIndex(idx)
        if prompt:
            self.ask(prompt, mode)
        else:
            self.input.setFocus()
            self.input.setPlaceholderText({"design_form": "e.g. A student registration form with name, email, course drop-down and Save/Clear buttons",
                                           "generate_app": "e.g. A unit converter for length and temperature with a history list"}
                                          .get(mode, "Describe what you want…"))

    def _mode_changed(self):
        mode = self.mode.currentData()
        self.inc_console.setChecked(mode == "fix_error")

    # -- provider ----------------------------------------------------------------
    def refresh_provider_label(self):
        cfg = load_config()
        prov = get_provider(cfg.provider)
        dot = "🟢" if (cfg.api_key or not prov.needs_key) and cfg.provider != "offline" else "⚪"
        self.provider_label.setText(f"{dot} {prov.name.split(' (')[0]} · {cfg.model}")
        self.provider_label.setToolTip("Configured AI provider. Click ⚙ to change.")

    def open_settings(self):
        if AISettingsDialog(self).exec():
            self.refresh_provider_label()
            self.host.statusBar().showMessage("AI settings saved", 3000)

    # -- sending -------------------------------------------------------------------
    def ask(self, prompt: str, mode: str = "chat"):
        idx = self.mode.findData(mode)
        if idx >= 0:
            self.mode.setCurrentIndex(idx)
        self.input.setPlainText(prompt)
        self.send()

    def _include(self):
        return {"form": self.inc_form.isChecked(), "source": self.inc_source.isChecked(), "console": self.inc_console.isChecked()}

    def send(self):
        if self.worker is not None:
            return
        mode = self.mode.currentData() or "chat"
        request = self.input.toPlainText().strip()
        if not request and mode in ("chat", "design_form", "generate_app", "modify_source"):
            self.input.setFocus()
            self.host.statusBar().showMessage("Describe what you want the AI to do", 3000)
            return
        ctx = self.host.ai_context()
        request = fill_placeholders(request, ctx)
        user_msg = build_user_message(request, mode, ctx, self._include())
        messages = self.history[-8:] + [{"role": "user", "content": user_msg}]
        self._pending = (request, mode)
        self.transcript.append(("user", mode, request or MODES[mode].label))
        self.transcript.append(("assistant", mode, ""))
        self.input.clear()
        for b in (self.apply_code_btn, self.apply_layout_btn, self.apply_handler_btn):
            b.setVisible(False)
        cfg = load_config()
        self.worker = AIWorker(cfg, build_system(mode), messages, mode)
        self.worker.chunk.connect(self._on_chunk)
        self.worker.succeeded.connect(self._on_done)
        self.worker.failed.connect(self._on_failed)
        self.worker.finished.connect(self._cleanup)
        self.send_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.send_btn.setText("Thinking…")
        self.worker.start()
        self._render()

    def stop(self):
        if self.worker:
            self.worker.cancel()
            self.host.statusBar().showMessage("AI request stopped", 3000)

    def _on_chunk(self, text):
        role, mode, current = self.transcript[-1]
        self.transcript[-1] = (role, mode, current + text)
        if not self._render_timer.isActive():
            self._render_timer.start()

    def _on_done(self, text):
        request, mode = self._pending
        self.transcript[-1] = ("assistant", mode, text or "_(empty response)_")
        self.history += [{"role": "user", "content": f"[{MODES[mode].label}] {request}"},
                         {"role": "assistant", "content": text[:12000]}]
        self.last_text, self.last_mode = text, mode
        result = MODES[mode].result
        has_code = bool(extract_python(text))
        self.apply_code_btn.setVisible(has_code and result in ("code", "text"))
        self.apply_handler_btn.setVisible(has_code and (result == "handler" or self.host.canvas.selected is not None) and result != "code")
        if result == "layout":
            layout, warnings = extract_layout(text)
            self.apply_layout_btn.setVisible(bool(layout and layout["controls"]))
            if layout and layout["controls"]:
                note = f"\n\n> ✅ **{len(layout['controls'])} controls ready.** Click *Apply layout to designer*."
                if warnings:
                    note += "\n>\n> " + "\n> ".join("⚠ " + w for w in warnings[:6])
                self.transcript[-1] = ("assistant", mode, text + note)
        self.host.events.emit("ai.response", mode, text)
        self._render()

    def _on_failed(self, message):
        mode = self._pending[1]
        self.transcript[-1] = ("error", mode, message)
        self.host.log(f"AI error: {message}", "error")
        self._render()

    def _cleanup(self):
        self.worker = None
        self.send_btn.setEnabled(True)
        self.send_btn.setText("Send")
        self.stop_btn.setEnabled(False)

    def clear(self):
        if self.worker:
            self.worker.cancel()
        self.history.clear()
        self.transcript.clear()
        self.last_text = ""
        for b in (self.apply_code_btn, self.apply_layout_btn, self.apply_handler_btn):
            b.setVisible(False)
        self._render()

    def _render(self):
        if not self.transcript:
            self.view.setMarkdown("### AI Assistant\n\nPick a **task** or a quick action, describe what you need, "
                                  "and press **Send**. Results can be applied to the designer or the source with a "
                                  "preview first.\n\n*Tip:* select a control and choose **Write event handler** to "
                                  "generate its code.")
            return
        out = []
        for role, mode, text in self.transcript:
            if role == "user":
                out.append(f"**You** · _{MODES.get(mode, MODES['chat']).label}_\n\n{text}")
            elif role == "error":
                out.append(f"**⚠ Error**\n\n{text}")
            else:
                out.append(f"**Assistant**\n\n{text or '_…thinking…_'}")
        self.view.setMarkdown("\n\n---\n\n".join(out))
        bar = self.view.verticalScrollBar()
        bar.setValue(bar.maximum())

    # -- applying results -----------------------------------------------------
    def apply_code(self):
        code = extract_python(self.last_text)
        if code:
            self.host.apply_ai_source(code)

    def apply_layout(self):
        layout, warnings = extract_layout(self.last_text)
        if layout:
            self.host.apply_layout(layout, confirm=True)

    def apply_handler(self):
        code = extract_python(self.last_text)
        if code:
            self.host.apply_event_code(code)

    # -- background requests for plugins and IDE features -------------------------
    def run_background(self, prompt, mode, callback, on_error, include_context=True):
        ctx = self.host.ai_context() if include_context else {}
        prompt = fill_placeholders(prompt, ctx)
        user = build_user_message(prompt, mode, ctx, self._include()) if include_context else prompt
        worker = AIWorker(load_config(), build_system(mode), [{"role": "user", "content": user}], mode)
        worker.succeeded.connect(callback)
        worker.failed.connect(on_error)
        worker.finished.connect(lambda w=worker: self._bg_workers.remove(w) if w in self._bg_workers else None)
        self._bg_workers.append(worker)
        worker.start()
        return worker

    def shutdown(self):
        for w in [self.worker] + self._bg_workers:
            if w is not None:
                w.cancel()
                w.wait(1500)
