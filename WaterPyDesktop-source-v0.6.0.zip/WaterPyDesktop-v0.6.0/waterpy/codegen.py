"""Native PySide6 source generation, driven by the component registry.

Features
* one handler per (control, signal) — several events per control,
* automatic imports: any ``Q…`` name used in generated code *or in your event code*
  is imported from QtWidgets / QtGui / QtCore,
* module-level snippets and plugin support classes emitted once,
* form settings (title, size, background) and plugin post-processing transforms.
"""
from __future__ import annotations

import ast
import io
import keyword
import re
import textwrap
import tokenize
from typing import Callable, Iterable

from . import __version__
from .registry import REGISTRY, SNIPPETS, SPECIAL_KEYS, ComponentRegistry, qt_module_for, snake, valid_color

DEFAULT_FORM = {"title": "My PySide6 App", "width": 900, "height": 600, "background": "", "icon": "", "tab_order": []}

# Kept for backward compatibility with plugins that imported it from v0.4.
TYPE_MAP = {spec.kind: spec.qt_class for spec in REGISTRY.specs()}


def safe_name(value, fallback):
    value = re.sub(r"\W+", "_", str(value or fallback), flags=re.UNICODE).strip("_") or fallback
    if value[0].isdigit():
        value = "widget_" + value
    if keyword.iskeyword(value):
        value += "_"
    return value


def _indent_block(code: str, spaces: int) -> list[str]:
    code = textwrap.dedent(str(code or "")).strip("\n")
    if not code.strip():
        return [" " * spaces + "pass"]
    return [(" " * spaces + line) if line.strip() else "" for line in code.splitlines()]


def _normalize_methods(methods: str) -> list[str]:
    """Accept helper methods written with or without the 4-space class indent."""
    text = str(methods or "").strip("\n")
    if not text.strip():
        return []
    first = next((l for l in text.splitlines() if l.strip()), "")
    if first and not first.startswith((" ", "\t")):
        return [("    " + l) if l.strip() else "" for l in text.splitlines()]
    return text.splitlines()


def _names_used(source: str) -> set[str]:
    names = set()
    try:
        for tok in tokenize.generate_tokens(io.StringIO(source).readline):
            if tok.type == tokenize.NAME and (tok.string == "Qt" or re.match(r"^Q[A-Z]\w*$", tok.string)):
                names.add(tok.string)
    except (tokenize.TokenError, IndentationError, SyntaxError):
        names.update(re.findall(r"\b(Qt|Q[A-Z]\w*)\b", source))
    return names


def _names_defined(code: str) -> set[str]:
    names = set()
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return set(re.findall(r"^\s*(?:class|def)\s+(\w+)", code, re.M))
    for node in ast.walk(tree):
        if isinstance(node, (ast.ClassDef, ast.FunctionDef)):
            names.add(node.name)
        elif isinstance(node, ast.Assign):
            names.update(t.id for t in node.targets if isinstance(t, ast.Name))
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            names.update((a.asname or a.name).split(".")[0] for a in node.names)
    return names


def normalize_controls(controls: Iterable[dict], registry: ComponentRegistry = REGISTRY) -> list[dict]:
    normalized, used = [], set()
    for i, raw in enumerate(controls or [], 1):
        c = registry.normalize(dict(raw))
        if c is None:
            continue
        spec = registry.get(c["type"])
        base = safe_name(c.get("name"), f"{snake(spec.qt_class.lstrip('Q'))}_{i}")
        name = base if base not in used else f"{base}_{i}"
        while name in used or name in ("form", "setup_ui"):
            name += "_"
        c["name"] = name
        used.add(name)
        normalized.append(c)
    return normalized


def generate_python(project_name: str, title: str, controls: list[dict], custom_methods: str = "",
                    form: dict | None = None, registry: ComponentRegistry = REGISTRY,
                    transforms: Iterable[Callable[[str, dict], str]] = ()) -> str:
    """Generate editable native PySide6 source from a WaterPy form definition."""
    given = dict(form or {})
    form = {**DEFAULT_FORM, **given}
    if title and not given.get("title"):
        form["title"] = title
    items = normalize_controls(controls, registry)

    explicit_imports: dict[str, set] = {"PySide6.QtWidgets": {"QApplication", "QMainWindow", "QWidget"}}
    snippet_ids: list[str] = []
    support_blocks: list[str] = []
    body: list[str] = []
    handlers: list[tuple[str, str, str]] = []

    def add_import(module, name):
        explicit_imports.setdefault(module, set()).add(name)

    for c in items:
        spec = registry.get(c["type"])
        name, w = c["name"], f"self.{c['name']}"
        if spec.module:
            add_import(spec.module, spec.qt_class)
        for module, names in (spec.extra_imports or {}).items():
            for n in names:
                add_import(module, n)
        for sid in spec.snippets:
            if sid not in snippet_ids:
                snippet_ids.append(sid)
        if spec.support_code and spec.support_code.strip() not in support_blocks:
            support_blocks.append(textwrap.dedent(spec.support_code).strip())

        parent = "self" if spec.non_visual else "self.form"
        body.append(f"# {name} ({spec.kind})")
        body.append(f"{w} = " + spec.constructor.format(cls=spec.qt_class, parent=parent))
        body.append(f"{w}.setObjectName({name!r})")
        if not spec.non_visual:
            x, y = max(0, int(c.get("x", 0))), max(0, int(c.get("y", 0)))
            wd = max(spec.min_size[0], int(c.get("width", spec.default_size[0])))
            ht = max(spec.min_size[1], int(c.get("height", spec.default_size[1])))
            body.append(f"{w}.setGeometry({x}, {y}, {wd}, {ht})")
        for prop in spec.all_properties():
            if prop.key in SPECIAL_KEYS or not prop.setter:
                continue
            value = c.get(prop.key, prop.default)
            if prop.should_emit(value):
                body.append(f"{w}.{prop.setter}({prop.expr(value)})")
        if spec.config:
            body.extend(spec.config(w, c) or [])
        if not spec.non_visual:
            family, size = str(c.get("font_family") or ""), int(c.get("font_size") or 0)
            if family or size or c.get("bold") or c.get("italic"):
                body.append(f"_font = {w}.font()")
                if family:
                    body.append(f"_font.setFamily({family!r})")
                if size:
                    body.append(f"_font.setPointSize({size})")
                if c.get("bold"):
                    body.append("_font.setBold(True)")
                if c.get("italic"):
                    body.append("_font.setItalic(True)")
                body.append(f"{w}.setFont(_font)")
            css = spec.css(c, design=False)
            if css:
                body.append(f"{w}.setStyleSheet({css!r})")
        for signal, code in (c.get("events") or {}).items():
            if signal in spec.signals and str(code).strip():
                method = f"on_{name}_{snake(signal)}"
                body.append(f"{w}.{signal}.connect(self.{method})")
                handlers.append((method, signal, code))
        body.append("")

    names_present = {c["name"] for c in items}
    order = [n for n in (form.get("tab_order") or []) if n in names_present]
    if len(order) >= 2:
        body.append("# keyboard focus order")
        body += [f"QWidget.setTabOrder(self.{a}, self.{b})" for a, b in zip(order, order[1:])]
    if not items:
        body.append("pass  # Drag components from the toolbox onto the form")

    # -- class assembly ----------------------------------------------------
    cls: list[str] = [
        "class MainWindow(QMainWindow):",
        '    """Main application window generated by WaterPyDesktop."""',
        "",
        "    def __init__(self):",
        "        super().__init__()",
        f"        self.setWindowTitle({str(form['title'] or project_name)!r})",
        f"        self.resize({max(200, int(form['width']))}, {max(150, int(form['height']))})",
        "        self.form = QWidget(self)",
        '        self.form.setObjectName("form")',
    ]
    icon = str(form.get("icon") or "").replace("\\", "/")
    if icon:
        if "resource_path" not in snippet_ids:
            snippet_ids.append("resource_path")
        cls.append(f"        self.setWindowIcon(QIcon(resource_path({icon!r})))")
    bg = valid_color(form.get("background"))
    if bg:
        cls.append(f'        self.form.setStyleSheet("QWidget#form {{ background-color: {bg}; }}")')
    cls += ["        self.setCentralWidget(self.form)", "        self.setup_ui()", "",
            "    def setup_ui(self):", '        """Create and configure the form controls."""']
    cls += [("        " + l) if l else "" for l in body]
    while cls and cls[-1] == "":
        cls.pop()
    if handlers:
        cls += ["", "    # ---- Event handlers -------------------------------------------------"]
    for method, signal, code in handlers:
        cls += ["", f"    def {method}(self, *args):", f'        """Handles {signal}."""']
        cls += _indent_block(code, 8)
    methods = _normalize_methods(custom_methods)
    if methods:
        cls += ["", "    # ---- Additional user-defined class methods --------------------------", ""] + methods

    main = ["", "", "def main():", "    app = QApplication(sys.argv)", "    window = MainWindow()",
            "    window.show()", "    sys.exit(app.exec())", "", "", 'if __name__ == "__main__":', "    main()", ""]

    snippets_code = [SNIPPETS[s][0] for s in snippet_ids if s in SNIPPETS]
    module_level = "\n\n\n".join(snippets_code + support_blocks)
    defined = _names_defined(module_level)

    # -- automatic Qt imports for everything referenced ---------------------
    class_text = "\n".join(cls) + "\n" + module_level
    already = {n for names in explicit_imports.values() for n in names}
    for name in sorted(_names_used(class_text) - already - defined):
        module = qt_module_for(name)
        if module:
            add_import(module, name)
    need_os = any("os" in SNIPPETS[s][1] for s in snippet_ids if s in SNIPPETS)

    header = [f'"""{project_name} — generated by WaterPyDesktop {__version__}.',
              "", "Edit freely; regenerate from the visual designer to refresh the form code.", '"""']
    if need_os:
        header.append("import os")
    header.append("import sys")
    header.append("")
    order = {"PySide6.QtCore": 0, "PySide6.QtGui": 1, "PySide6.QtWidgets": 2}
    for module in sorted(explicit_imports, key=lambda m: (order.get(m, 3), m)):
        names = sorted(explicit_imports[module])
        line = f"from {module} import {', '.join(names)}"
        if len(line) > 100:
            line = f"from {module} import (\n    " + ",\n    ".join(names) + ",\n)"
        header.append(line)
    parts = ["\n".join(header)]
    if module_level:
        parts.append(module_level)
    parts.append("\n".join(cls))
    source = "\n\n\n".join(parts) + "\n".join(main)

    project = {"name": project_name, "form": form, "controls": items, "custom_methods": custom_methods}
    for transform in transforms or ():
        try:
            result = transform(source, project)
            if isinstance(result, str) and result.strip():
                source = result
        except Exception as exc:  # a broken plugin must never break code generation
            source = f"# [WaterPy] code transform {getattr(transform, '__name__', transform)!r} failed: {exc}\n" + source
    return source
