"""Secondary IDE dialogs."""
from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QProcess, Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QHBoxLayout,
                               QHeaderView, QLabel, QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QSpinBox,
                               QSplitter, QTableWidget, QTableWidgetItem, QTextBrowser, QVBoxLayout, QWidget)

from . import sdk_tools


def open_folder(path: Path):
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    if sys.platform == "win32":
        os.startfile(str(path))  # noqa: S606
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])


class NewPluginDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("New Plugin")
        self.setMinimumWidth(480)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Create a plugin skeleton in your user plugins folder. It is enabled immediately; "
                             "edit the code, then use <b>Reload</b> in the Plugin Manager to hot-reload it."))
        form = QFormLayout()
        self.name = QLineEdit()
        self.name.setPlaceholderText("My Extension")
        self.pid = QLineEdit()
        self.pid.setPlaceholderText("my_extension")
        self.name.textChanged.connect(lambda t: self.pid.setText(re.sub(r"[^a-z0-9_]+", "_", t.lower()).strip("_")))
        self.template = QComboBox()
        for key, (desc, _) in sdk_tools.TEMPLATES.items():
            self.template.addItem(f"{key} — {desc}", key)
        self.author = QLineEdit()
        self.description = QLineEdit()
        form.addRow("Name", self.name)
        form.addRow("Plugin id", self.pid)
        form.addRow("Template", self.template)
        form.addRow("Author", self.author)
        form.addRow("Description", self.description)
        lay.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)

    def values(self):
        return dict(plugin_id=self.pid.text().strip(), name=self.name.text().strip(), template=self.template.currentData(),
                    author=self.author.text().strip(), description=self.description.text().strip())


class PluginManagerDialog(QDialog):
    COLS = ["On", "Plugin", "Version", "Author", "Source", "API", "Status"]

    def __init__(self, window):
        super().__init__(window)
        self.window = window
        self.manager = window.plugins
        self.setWindowTitle("Plugin Manager")
        self.resize(900, 560)
        lay = QVBoxLayout(self)
        split = QSplitter(Qt.Orientation.Vertical)
        self.table = QTableWidget(0, len(self.COLS))
        self.table.setHorizontalHeaderLabels(self.COLS)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        for i in (0, 2, 3, 4, 5, 6):
            hh.setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
        self.table.itemSelectionChanged.connect(self._show_details)
        self.details = QTextBrowser()
        self.details.setOpenExternalLinks(True)
        split.addWidget(self.table)
        split.addWidget(self.details)
        split.setSizes([330, 170])
        lay.addWidget(split, 1)
        row = QHBoxLayout()
        for text, slot in [("Install…", self.install), ("New plugin…", self.new_plugin), ("Reload", self.reload_selected),
                           ("Reload all", self.reload_all), ("Validate", self.validate_selected),
                           ("Package…", self.package_selected), ("Uninstall", self.uninstall), ("Open folder", self.open_user_folder)]:
            b = QPushButton(text)
            b.clicked.connect(slot)
            row.addWidget(b)
        lay.addLayout(row)
        close = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        close.rejected.connect(self.reject)
        lay.addWidget(close)
        self.refresh()

    def _ids(self):
        return [p.id for p in sorted(self.manager.plugins.values(), key=lambda p: (not p.bundled, p.name.lower()))]

    def refresh(self, select: str | None = None):
        current = select or self._selected_id()
        self.manager.scan()
        ids = self._ids()
        self.table.setRowCount(0)
        colours = {"loaded": "#15803d", "error": "#b91c1c", "incompatible": "#b45309", "restart required": "#b45309"}
        for pid in ids:
            p = self.manager.plugins[pid]
            r = self.table.rowCount()
            self.table.insertRow(r)
            cb = QCheckBox()
            cb.setChecked(p.enabled)
            cb.toggled.connect(lambda on, i=pid: self._toggle(i, on))
            holder = QWidget()
            hl = QHBoxLayout(holder)
            hl.setContentsMargins(8, 0, 0, 0)
            hl.addWidget(cb)
            self.table.setCellWidget(r, 0, holder)
            name = QTableWidgetItem(p.name)
            name.setData(Qt.ItemDataRole.UserRole, pid)
            self.table.setItem(r, 1, name)
            self.table.setItem(r, 2, QTableWidgetItem(p.version))
            self.table.setItem(r, 3, QTableWidgetItem(p.author))
            self.table.setItem(r, 4, QTableWidgetItem("Bundled" if p.bundled else "User"))
            self.table.setItem(r, 5, QTableWidgetItem(p.api_version))
            st = QTableWidgetItem(p.status)
            st.setForeground(Qt.GlobalColor.black)
            if p.status in colours:
                from PySide6.QtGui import QColor
                st.setForeground(QColor(colours[p.status]))
            self.table.setItem(r, 6, st)
            if pid == current:
                self.table.selectRow(r)
        if self.table.rowCount() and not self.table.selectedItems():
            self.table.selectRow(0)
        self._show_details()

    def _selected_id(self):
        items = self.table.selectedItems() if hasattr(self, "table") else []
        for it in items:
            if it.column() == 1:
                return it.data(Qt.ItemDataRole.UserRole)
        return None

    def _selected(self):
        pid = self._selected_id()
        return self.manager.plugins.get(pid) if pid else None

    def _show_details(self):
        p = self._selected()
        if not p:
            self.details.setHtml("<i>No plugin selected.</i>")
            return
        error = f"<pre style='color:#b91c1c;white-space:pre-wrap'>{p.error}</pre>" if p.error else ""
        home = f"<br>Homepage: <a href='{p.homepage}'>{p.homepage}</a>" if p.homepage else ""
        self.details.setHtml(f"<h3 style='margin:0'>{p.name} <span style='color:#64748b'>{p.version}</span></h3>"
                             f"<p>{p.description or '<i>No description</i>'}</p>"
                             f"<p style='color:#475569'>id <code>{p.id}</code> · {p.kind} · API {p.api_version}"
                             f"{' (legacy v1)' if not p.is_v2 else ''}<br>Location: <code>{p.path}</code>{home}</p>{error}")

    def _toggle(self, pid, on):
        self.manager.set_enabled(pid, on, self.window)
        info = self.manager.plugins.get(pid)
        if info and info.status == "restart required":
            QMessageBox.information(self, "Plugin Manager", f"{info.name} is a legacy (API 1) plugin; restart the IDE to fully unload it.")
        self.window.after_plugins_changed()
        self.refresh(pid)

    def install(self):
        path, _ = QFileDialog.getOpenFileName(self, "Install plugin", "", "Plugins (*.py *.zip *.wpplugin);;All files (*.*)")
        if not path:
            folder = QFileDialog.getExistingDirectory(self, "…or choose a plugin folder")
            path = folder or ""
        if not path:
            return
        try:
            info = self.manager.install(Path(path), self.window)
            self.window.after_plugins_changed()
            self.refresh(info.id)
            msg = f"Installed {info.name} {info.version} ({info.status})."
            if info.status == "error":
                msg += "\n\n" + info.error.splitlines()[0]
            QMessageBox.information(self, "Plugin installed", msg)
        except Exception as exc:
            QMessageBox.critical(self, "Install failed", str(exc))

    def new_plugin(self):
        dlg = NewPluginDialog(self)
        if not dlg.exec():
            return
        v = dlg.values()
        try:
            folder = sdk_tools.scaffold(self.manager.user_folder, v["plugin_id"], v["name"], v["template"], v["author"], v["description"])
        except Exception as exc:
            QMessageBox.critical(self, "New plugin", str(exc))
            return
        self.manager.scan()
        info = self.manager.plugins.get(v["plugin_id"])
        if info:
            self.manager.load(info, self.window)
        self.window.after_plugins_changed()
        self.refresh(v["plugin_id"])
        if QMessageBox.question(self, "New plugin", f"Created {folder}.\n\nOpen the folder now?") == QMessageBox.StandardButton.Yes:
            open_folder(folder)

    def reload_selected(self):
        p = self._selected()
        if not p:
            return
        ok = self.manager.reload(p.id, self.window)
        self.window.after_plugins_changed()
        self.refresh(p.id)
        self.window.statusBar().showMessage(f"{p.name}: {'reloaded' if ok else self.manager.plugins[p.id].status}", 4000)

    def reload_all(self):
        loaded, errors = self.manager.reload_all(self.window)
        self.window.after_plugins_changed()
        self.refresh()
        if errors:
            QMessageBox.warning(self, "Plugins reloaded", "Some plugins failed:\n\n" + "\n".join(errors))

    def validate_selected(self):
        p = self._selected()
        if not p:
            return
        problems = sdk_tools.validate(p.path)
        QMessageBox.information(self, "Validate plugin", "✔ No problems found." if not problems else "\n".join(problems))

    def package_selected(self):
        p = self._selected()
        if not p:
            return
        out = QFileDialog.getExistingDirectory(self, "Save .wpplugin package to…")
        if out:
            try:
                target = sdk_tools.package(p.path, Path(out))
                QMessageBox.information(self, "Package", f"Created {target}")
            except Exception as exc:
                QMessageBox.critical(self, "Package failed", str(exc))

    def uninstall(self):
        p = self._selected()
        if not p:
            return
        if p.bundled:
            QMessageBox.information(self, "Uninstall", "Bundled plugins can't be removed. Untick them to disable.")
            return
        if QMessageBox.question(self, "Uninstall", f"Remove {p.name} and delete {p.path}?") != QMessageBox.StandardButton.Yes:
            return
        try:
            self.manager.uninstall(p.id, self.window)
        except Exception as exc:
            QMessageBox.critical(self, "Uninstall failed", str(exc))
        self.window.after_plugins_changed()
        self.refresh()

    def open_user_folder(self):
        open_folder(self.manager.user_folder)


class MarkdownViewer(QDialog):
    def __init__(self, title: str, path: Path, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(900, 700)
        lay = QVBoxLayout(self)
        view = QTextBrowser()
        view.setOpenExternalLinks(True)
        try:
            view.setMarkdown(Path(path).read_text(encoding="utf-8"))
        except OSError:
            view.setPlainText(f"{path} was not found.")
        lay.addWidget(view)
        close = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        close.rejected.connect(self.reject)
        lay.addWidget(close)


class PackageManagerDialog(QDialog):
    """Install packages into the interpreter that runs the *generated* app."""
    def __init__(self, interpreter: str, prefix: list[str], parent=None):
        super().__init__(parent)
        self.interpreter, self.prefix = interpreter, prefix
        self.setWindowTitle("Python Package Manager")
        self.resize(760, 500)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"Target interpreter: <code>{interpreter} {' '.join(prefix)}</code>"))
        row = QHBoxLayout()
        self.package_name = QLineEdit()
        self.package_name.setPlaceholderText("Package name, e.g. requests or pandas")
        install = QPushButton("Install / Upgrade")
        install.clicked.connect(self.install_package)
        uninstall = QPushButton("Uninstall")
        uninstall.clicked.connect(self.uninstall_package)
        refresh = QPushButton("Refresh list")
        refresh.clicked.connect(self.refresh_packages)
        row.addWidget(self.package_name, 1)
        for b in (install, uninstall, refresh):
            row.addWidget(b)
        layout.addLayout(row)
        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        self.output.setFont(QFont("Consolas", 9))
        layout.addWidget(self.output, 1)
        self.process = QProcess(self)
        self.process.readyReadStandardOutput.connect(lambda: self.output.insertPlainText(bytes(self.process.readAllStandardOutput()).decode(errors="replace")))
        self.process.readyReadStandardError.connect(lambda: self.output.insertPlainText(bytes(self.process.readAllStandardError()).decode(errors="replace")))
        self.process.finished.connect(lambda code, st: self.output.appendPlainText(f"\n[Process finished: exit {code}]"))
        self.refresh_packages()

    def _start(self, args):
        if self.process.state() != QProcess.ProcessState.NotRunning:
            return
        full = self.prefix + args
        self.output.appendPlainText("> " + self.interpreter + " " + " ".join(full) + "\n")
        self.process.start(self.interpreter, full)

    def _name(self):
        name = self.package_name.text().strip()
        if not name or not re.fullmatch(r"[A-Za-z0-9_.\-\[\],]+(?:[<>=!~]=?[A-Za-z0-9_.*]+)?", name):
            QMessageBox.warning(self, "Package name", "Enter a valid package name.")
            return None
        return name

    def refresh_packages(self):
        self._start(["-m", "pip", "list", "--format=columns"])

    def install_package(self):
        if name := self._name():
            self._start(["-m", "pip", "install", "--upgrade", name])

    def uninstall_package(self):
        if name := self._name():
            self._start(["-m", "pip", "uninstall", "-y", name])


class PreferencesDialog(QDialog):
    def __init__(self, window):
        super().__init__(window)
        self.window = window
        self.setWindowTitle("Preferences")
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.theme = QComboBox()
        self.theme.addItems(list(window.THEMES))
        self.theme.setCurrentText(window.current_theme)
        self.font_size = QSpinBox()
        self.font_size.setRange(7, 28)
        self.font_size.setValue(window.editor.font().pointSize())
        self.grid = QSpinBox()
        self.grid.setRange(4, 64)
        self.grid.setValue(window.canvas.grid_size)
        self.autosave = QSpinBox()
        self.autosave.setRange(0, 60)
        self.autosave.setSuffix(" min (0 = off)")
        self.autosave.setValue(window.autosave_minutes)
        self.autoregen = QCheckBox("Regenerate source automatically while designing")
        self.autoregen.setChecked(window.auto_regenerate)
        form.addRow("Theme", self.theme)
        form.addRow("Editor font size", self.font_size)
        form.addRow("Grid size", self.grid)
        form.addRow("Auto-save", self.autosave)
        form.addRow("", self.autoregen)
        lay.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)

    def apply(self):
        w = self.window
        w.apply_theme(self.theme.currentText())
        w.editor.set_font_size(self.font_size.value())
        w.canvas.grid_size = self.grid.value()
        w.canvas.update()
        w.set_autosave(self.autosave.value())
        w.auto_regenerate = self.autoregen.isChecked()
        w.save_settings()


# ---------------------------------------------------------------------------
# Build settings, installer builder and tab order
# ---------------------------------------------------------------------------
class _PathRow(QWidget):
    def __init__(self, value="", pick=None, placeholder=""):
        super().__init__()
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.edit = QLineEdit(value)
        self.edit.setPlaceholderText(placeholder)
        btn = QPushButton("…")
        btn.setFixedWidth(30)
        btn.clicked.connect(lambda: (lambda p: self.edit.setText(p) if p else None)(pick(self) if pick else ""))
        lay.addWidget(self.edit, 1)
        lay.addWidget(btn)

    def text(self):
        return self.edit.text().strip()


class BuildSettingsDialog(QDialog):
    """Executable metadata and PyInstaller options stored in the project."""
    def __init__(self, settings: dict, asset_picker, parent=None):
        super().__init__(parent)
        from .installer import DEFAULT_BUILD
        s = {**DEFAULT_BUILD, **(settings or {})}
        self.setWindowTitle("Build Settings")
        self.setMinimumWidth(520)
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.app_name = QLineEdit(s["app_name"])
        self.app_name.setPlaceholderText("Defaults to the project name")
        self.version = QLineEdit(s["version"])
        self.company = QLineEdit(s["company"])
        self.description = QLineEdit(s["description"])
        self.copyright = QLineEdit(s["copyright"])
        self.icon = _PathRow(s["icon"], asset_picker, "assets/app.ico (Windows .ico)")
        self.onefile = QCheckBox("Single-file EXE (slower start, one file to share)")
        self.onefile.setChecked(bool(s["onefile"]))
        self.console = QCheckBox("Show a console window (useful for debugging print output)")
        self.console.setChecked(bool(s["console"]))
        self.hidden = QLineEdit(s["hidden_imports"])
        self.hidden.setPlaceholderText("e.g. pandas, openpyxl (modules imported dynamically)")
        self.extra = QLineEdit(s["extra_args"])
        self.extra.setPlaceholderText("Extra PyInstaller options, e.g. --collect-all reportlab")
        for label, w in (("Application name", self.app_name), ("Version", self.version), ("Company", self.company),
                         ("Description", self.description), ("Copyright", self.copyright), ("Icon", self.icon),
                         ("", self.onefile), ("", self.console), ("Hidden imports", self.hidden), ("Extra options", self.extra)):
            form.addRow(label, w)
        lay.addLayout(form)
        note = QLabel("These values appear in the EXE's Windows file properties and are reused by the installer builder.")
        note.setWordWrap(True)
        note.setStyleSheet("color:#64748b;")
        lay.addWidget(note)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)

    def values(self) -> dict:
        return {"app_name": self.app_name.text().strip(), "version": self.version.text().strip() or "1.0.0",
                "company": self.company.text().strip(), "description": self.description.text().strip(),
                "copyright": self.copyright.text().strip(), "icon": self.icon.text(), "onefile": self.onefile.isChecked(),
                "console": self.console.isChecked(), "hidden_imports": self.hidden.text().strip(),
                "extra_args": self.extra.text().strip()}


class InstallerDialog(QDialog):
    """Options for packaging the built EXE into setup.exe."""
    def __init__(self, settings: dict, compilers: dict, parent=None):
        super().__init__(parent)
        from .installer import DEFAULT_INSTALLER
        s = {**DEFAULT_INSTALLER, **(settings or {})}
        self.setWindowTitle("Create Installer (setup.exe)")
        self.setMinimumWidth(560)
        lay = QVBoxLayout(self)
        found = [f"{k}: {v}" for k, v in compilers.items() if v]
        info = QLabel("Packages the built application into one <b>setup.exe</b> with Start-menu and desktop shortcuts, "
                      "an uninstaller and an <i>Apps &amp; features</i> entry.<br>"
                      + ("Compilers found: " + "; ".join(found) if found else
                         "<span style='color:#b45309'>No installer compiler found. Install <b>Inno Setup 6</b> "
                         "(jrsoftware.org) or <b>NSIS 3</b> (nsis.sourceforge.io); the script is still written so you "
                         "can compile it later.</span>"))
        info.setWordWrap(True)
        info.setTextFormat(Qt.TextFormat.RichText)
        lay.addWidget(info)
        form = QFormLayout()
        self.compiler = QComboBox()
        self.compiler.addItem("Automatic (Inno Setup, then NSIS)", "auto")
        self.compiler.addItem("Inno Setup 6", "inno")
        self.compiler.addItem("NSIS 3", "nsis")
        self.compiler.setCurrentIndex(max(0, self.compiler.findData(s["compiler"])))
        self.publisher = QLineEdit(s["publisher"])
        self.url = QLineEdit(s["url"])
        self.url.setPlaceholderText("https://")
        self.license = _PathRow(s["license_file"], lambda p: QFileDialog.getOpenFileName(p, "License text", "", "Text (*.txt *.rtf)")[0],
                                "optional licence .txt shown during setup")
        self.desktop = QCheckBox("Desktop shortcut")
        self.desktop.setChecked(bool(s["desktop_icon"]))
        self.start = QCheckBox("Start-menu shortcuts")
        self.start.setChecked(bool(s["start_menu"]))
        self.run_after = QCheckBox("Offer to launch after installation")
        self.run_after.setChecked(bool(s["run_after"]))
        self.per_user = QCheckBox("Per-user install (no administrator rights needed)")
        self.per_user.setChecked(bool(s["per_user"]))
        self.rebuild = QCheckBox("Build the EXE first")
        self.rebuild.setChecked(True)
        for label, w in (("Compiler", self.compiler), ("Publisher", self.publisher), ("Website", self.url),
                         ("Licence", self.license), ("", self.desktop), ("", self.start), ("", self.run_after),
                         ("", self.per_user), ("", self.rebuild)):
            form.addRow(label, w)
        lay.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        buttons.addButton("Create setup.exe", QDialogButtonBox.ButtonRole.AcceptRole)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)

    def values(self) -> dict:
        return {"compiler": self.compiler.currentData(), "publisher": self.publisher.text().strip(), "url": self.url.text().strip(),
                "license_file": self.license.text(), "desktop_icon": self.desktop.isChecked(), "start_menu": self.start.isChecked(),
                "run_after": self.run_after.isChecked(), "per_user": self.per_user.isChecked()}


class TabOrderDialog(QDialog):
    """Drag (or use the buttons) to set the keyboard Tab order of input controls."""
    FOCUSABLE_SKIP = {"Label", "Image", "Rectangle", "Ellipse", "Line", "Container", "Group Box", "Progress Bar",
                      "LCD Number", "Timer", "Media", "Card Panel", "Hyperlink"}

    def __init__(self, controls: list[dict], current: list[str], parent=None):
        super().__init__(parent)
        from PySide6.QtWidgets import QAbstractItemView, QListWidget
        self.setWindowTitle("Tab Order")
        self.resize(420, 480)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Order in which <b>Tab</b> moves between controls when the app runs. Drag to reorder."))
        self.list = QListWidget()
        self.list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        names = [c["name"] for c in controls if c["type"] not in self.FOCUSABLE_SKIP]
        kinds = {c["name"]: c["type"] for c in controls}
        ordered = [n for n in current if n in names] + [n for n in names if n not in current]
        if not current:  # sensible default: reading order (top-to-bottom, left-to-right)
            pos = {c["name"]: (c["y"] // 12, c["x"]) for c in controls}
            ordered.sort(key=lambda n: pos[n])
        for n in ordered:
            from PySide6.QtWidgets import QListWidgetItem
            item = QListWidgetItem(f"{n}    ({kinds[n]})")
            item.setData(Qt.ItemDataRole.UserRole, n)
            self.list.addItem(item)
        lay.addWidget(self.list, 1)
        row = QHBoxLayout()
        for text, step in (("Move up", -1), ("Move down", 1)):
            b = QPushButton(text)
            b.clicked.connect(lambda checked=False, s=step: self._move(s))
            row.addWidget(b)
        auto = QPushButton("Reading order")
        auto.clicked.connect(lambda: self._reading_order(controls))
        row.addWidget(auto)
        lay.addLayout(row)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)

    def _move(self, step):
        r = self.list.currentRow()
        if r < 0 or not (0 <= r + step < self.list.count()):
            return
        item = self.list.takeItem(r)
        self.list.insertItem(r + step, item)
        self.list.setCurrentRow(r + step)

    def _reading_order(self, controls):
        pos = {c["name"]: (c["y"] // 12, c["x"]) for c in controls}
        items = [self.list.takeItem(0) for _ in range(self.list.count())]
        for it in sorted(items, key=lambda it: pos[it.data(Qt.ItemDataRole.UserRole)]):
            self.list.addItem(it)

    def order(self) -> list[str]:
        return [self.list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.list.count())]
