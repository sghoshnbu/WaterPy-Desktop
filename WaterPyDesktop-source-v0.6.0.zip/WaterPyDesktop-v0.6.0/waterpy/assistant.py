"""Backward-compatible synchronous assistant facade (v0.4 API).

New code should use the AI Assistant panel or ``api.ask_ai`` from a plugin.
"""
from __future__ import annotations

from .ai.providers import AIError, get_provider
from .ai.service import SYSTEM_BASE as SYSTEM_PROMPT, build_system, build_user_message  # noqa: F401


class ProjectAssistant:
    def answer(self, request: str, project_name: str, current_code: str = "", project_context: str = "",
               mode: str = "generate_app") -> str:
        from .ai.settings import load_config
        cfg = load_config()
        ctx = {"project": {"name": project_name}, "source": current_code}
        message = build_user_message(request + ("\n\nPROJECT CONTEXT:\n" + project_context if project_context else ""), mode, ctx)
        try:
            return "".join(get_provider(cfg.provider).stream(cfg, build_system(mode), [{"role": "user", "content": message}], mode))
        except AIError as exc:
            return f"AI request failed: {exc}"
