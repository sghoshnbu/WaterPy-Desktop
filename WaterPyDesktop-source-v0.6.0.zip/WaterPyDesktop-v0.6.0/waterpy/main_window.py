"""WaterPyDesktop main window."""
from __future__ import annotations

import html
import json
import os
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

from PySide6.QtCore import QByteArray, QProcess, QSettings, QSize, QStandardPaths, Qt, QTimer
from PySide6.QtGui import QAction, QActionGroup, QColor, QFont, QIcon, QKeySequence, QPainter, QPalette, QPen, QPixmap, QTextCursor
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QDockWidget, QFileDialog, QFrame, QHBoxLayout,
                               QInputDialog, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMenu,
                               QMessageBox, QPlainTextEdit, QPushButton, QScrollArea, QSizePolicy, QSplitter, QStatusBar, QStyle,
                               QTabWidget, QToolBar, QToolButton, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from . import __edition__, __version__
from .ai.panel import AIPanel, DiffDialog
from .code_editor import CodeEditor, FindBar, OutlineCombo
from .codegen import DEFAULT_FORM, generate_python
from .designer import ALIGN_ACTIONS, ComponentPalette, DesignCanvas, FormFrame, make_icon
from .dialogs import (BuildSettingsDialog, InstallerDialog, MarkdownViewer, PackageManagerDialog, TabOrderDialog, PluginManagerDialog, PreferencesDialog,
                      open_folder)
from . import installer as inst
from . import io_formats
from .events import EventBus
from .snippets import SNIPPETS, render as render_snippet
from .plugins import PluginManager
from .property_grid import PropertyGrid
from .registry import REGISTRY, CATEGORY_COLORS

APP_DIR = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))


def user_data_dir() -> Path:
    base = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation)
    path = Path(base or Path.home() / ".waterpydesktop")
    path.mkdir(parents=True, exist_ok=True)
    return path


def glyph_icon(glyph: str, color: str = "#2563eb", size: int = 18) -> QIcon:
    pm = QPixmap(size * 2, size * 2)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(QColor(color))
    f = QFont("Segoe UI Symbol")
    f.setPixelSize(int(size * 1.5))
    f.setBold(True)
    p.setFont(f)
    p.drawText(pm.rect(), Qt.AlignmentFlag.AlignCenter, glyph)
    p.end()
    return QIcon(pm)


class MiniMap(QWidget):
    """Live overview of controls on the design surface (click to select)."""
    def __init__(self, window, parent=None):
        super().__init__(parent)
        self.window_ref = window
        self.setMinimumSize(160, 90)
        self.setToolTip("Overview of the form — click a box to select that control")

    def _geometry(self):
        canvas = self.window_ref.canvas
        area = self.rect().adjusted(8, 8, -8, -8)
        sx = area.width() / max(1, canvas.width())
        sy = area.height() / max(1, canvas.height())
        s = min(sx, sy)
        ox = area.x() + (area.width() - canvas.width() * s) / 2
        oy = area.y() + (area.height() - canvas.height() * s) / 2
        return s, ox, oy

    def paintEvent(self, event):
        canvas = self.window_ref.canvas
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor("#20252d"))
        s, ox, oy = self._geometry()
        p.setPen(QPen(QColor("#4b5563"), 1))
        p.setBrush(QColor("#f8fafc"))
        p.drawRect(int(ox), int(oy), int(canvas.width() * s), int(canvas.height() * s))
        for c in canvas.controls_widgets():
            sel = c in canvas.selection
            p.setPen(QPen(QColor("#1677ff" if sel else "#94a3b8"), 1))
            p.setBrush(QColor("#8ec5ff" if sel else CATEGORY_COLORS.get(c.spec.category, "#cbd5e1")).lighter(160 if not sel else 100))
            p.drawRect(int(ox + c.x() * s), int(oy + c.y() * s), max(2, int(c.width() * s)), max(2, int(c.height() * s)))
        p.end()

    def mousePressEvent(self, event):
        s, ox, oy = self._geometry()
        x, y = (event.position().x() - ox) / s, (event.position().y() - oy) / s
        canvas = self.window_ref.canvas
        hits = [c for c in canvas.controls_widgets() if c.geometry().contains(int(x), int(y))]
        canvas.set_selection(hits[-1:])


THEMES = {
    #               window     panel      text       border     accent     hover      dark
    "Professional Light": ("#f3f6fa", "#ffffff", "#1f2937", "#d7dee8", "#2563eb", "#e8f0fe", False),
    "Ocean Blue": ("#e8f3fa", "#ffffff", "#123247", "#c4d9e7", "#0a7ea8", "#d6eef8", False),
    "Midnight Dark": ("#161a21", "#1e232c", "#e6e9ef", "#323946", "#5b9dff", "#28303d", True),
    "Graphite": ("#202124", "#2a2b2f", "#e8eaed", "#3c3f45", "#8ab4f8", "#35373c", True),
}


class MainWindow(QMainWindow):
    THEMES = THEMES

    def __init__(self):
        super().__init__()
        self.setWindowTitle("WaterPyDesktop")
        self.resize(1440, 900)
        self.setMinimumSize(1100, 700)
        self.setDockOptions(QMainWindow.DockOption.AnimatedDocks | QMainWindow.DockOption.AllowTabbedDocks)
        self.project_dir: Path | None = None
        self.project_file: Path | None = None
        self.project_name = "Untitled"
        self.custom_methods_code = ""
        self.source_dirty = False
        self.modified = False
        self.auto_regenerate = True
        self.autosave_minutes = 0
        self.current_theme = "Professional Light"
        self._setting_source = False
        self._loading_events = False
        self.process_mode = "run"
        self.last_error_line = 0
        self.code_transforms: list = []
        self.build_settings: dict = {}
        self.installer_settings: dict = {}
        self._after_build = None
        self._installer_output = ""
        self._last_build = None
        self._previews: list = []
        self._orig_excepthook = sys.excepthook
        sys.excepthook = self._excepthook
        self.exporters: list = []
        self._plugin_menus: dict[str, QMenu] = {}
        self._plugin_toolbar: QToolBar | None = None
        self.events = EventBus(on_error=lambda msg: self.log(msg, "error"))
        self.user_dir = user_data_dir()
        self.plugins = PluginManager(APP_DIR / "plugins", self.user_dir / "plugins")
        self.plugin_host = None
        self.process = QProcess(self)
        self.process.readyReadStandardOutput.connect(self._stdout)
        self.process.readyReadStandardError.connect(self._stderr)
        self.process.finished.connect(self._finished)

        self._regen_timer = self._timer(220, self._debounced_refresh)
        self._commit_timer = self._timer(450, lambda: self.canvas.commit())
        self._event_timer = self._timer(500, self._store_event_code)
        self._methods_timer = self._timer(600, self._store_custom_methods)
        self.autosave_timer = QTimer(self)
        self.autosave_timer.timeout.connect(self._autosave)

        self._build_ui()
        self._build_menus()
        self.load_settings()
        REGISTRY.add_listener(self._registry_changed)
        self._new_project(silent=True)
        self._load_plugins(initial=True)
        self._load_user_templates()
        self.statusBar().showMessage(f"WaterPyDesktop {__version__} ready — drag components onto the form, or ask the AI to design one", 6000)

    def _timer(self, ms, slot):
        t = QTimer(self)
        t.setSingleShot(True)
        t.setInterval(ms)
        t.timeout.connect(slot)
        return t

    # ======================================================================= UI
    def _build_ui(self):
        st = self.style()
        self.toolbar = QToolBar("Main toolbar")
        self.toolbar.setObjectName("mainToolbar")
        self.toolbar.setMovable(False)
        self.toolbar.setIconSize(QSize(18, 18))
        self.toolbar.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.addToolBar(self.toolbar)

        def act(text, slot, icon=None, shortcut=None, tip=None, checkable=False):
            a = QAction(text, self)
            if icon is not None:
                a.setIcon(icon if isinstance(icon, QIcon) else st.standardIcon(icon))
            if shortcut:
                a.setShortcut(QKeySequence(shortcut))
            a.setToolTip(f"{tip or text}" + (f"  ({QKeySequence(shortcut).toString()})" if shortcut else ""))
            a.setStatusTip(tip or text)
            a.setCheckable(checkable)
            a.triggered.connect(slot)
            return a

        SP = QStyle.StandardPixmap
        self.a_new = act("New", self.new_project, SP.SP_FileIcon, "Ctrl+N")
        self.a_open = act("Open", self.open_project, SP.SP_DialogOpenButton, "Ctrl+O")
        self.a_save = act("Save", self.save_project, SP.SP_DialogSaveButton, "Ctrl+S")
        self.a_save_as = act("Save As…", self.save_project_as, None, "Ctrl+Shift+S")
        self.a_undo = act("Undo", lambda: self.canvas.undo(), SP.SP_ArrowBack, "Ctrl+Z", "Undo designer change")
        self.a_redo = act("Redo", lambda: self.canvas.redo(), SP.SP_ArrowForward, "Ctrl+Y", "Redo designer change")
        self.a_cut = act("Cut", lambda: self.canvas.cut_selection(), None, "Ctrl+X")
        self.a_copy = act("Copy", lambda: self.canvas.copy_selection(), None, "Ctrl+C")
        self.a_paste = act("Paste", lambda: self.canvas.paste(), None, "Ctrl+V")
        self.a_dup = act("Duplicate", lambda: self.canvas.duplicate_selection(), glyph_icon("⧉", "#475569"), "Ctrl+D")
        self.a_delete = act("Delete", self._delete_selected, SP.SP_TrashIcon, None, "Delete selected controls")
        self.a_select_all = act("Select All", lambda: self.canvas.select_all(), None, "Ctrl+A")
        self.a_front = act("Bring to Front", lambda: self.canvas.bring_to_front(), glyph_icon("⬒", "#475569"))
        self.a_back = act("Send to Back", lambda: self.canvas.send_to_back(), glyph_icon("⬓", "#475569"))
        self.a_generate = act("Generate", lambda: self.regenerate_from_designer(), SP.SP_FileDialogDetailedView, "F7", "Generate Python from the designer")
        self.a_run = act("Run", self.run_code, SP.SP_MediaPlay, "F5", "Run the application")
        self.a_stop = act("Stop", self.stop_process, SP.SP_MediaStop, "Shift+F5", "Stop the running application or build")
        self.a_build = act("Build EXE", self.build_exe, SP.SP_ComputerIcon, "Ctrl+B", "Build a Windows executable with PyInstaller")
        self.a_ai = act("AI Design", lambda: self.focus_ai("design_form"), glyph_icon("✦", "#7c3aed"), "Ctrl+Shift+A",
                        "Describe a screen and let the AI lay it out")
        self.a_stop.setEnabled(False)
        self.a_preview = act("Preview", self.live_preview, glyph_icon("◉", "#0891b2"), "F6", "Live preview of the form inside the IDE")
        self.a_installer = act("Setup.exe", self.create_installer, glyph_icon("⬇", "#16a34a"), "Ctrl+Shift+B",
                               "Create a Windows installer (setup.exe) for this application")
        for a in (self.a_new, self.a_open, self.a_save):
            self.toolbar.addAction(a)
        self.toolbar.addSeparator()
        for a in (self.a_undo, self.a_redo):
            self.toolbar.addAction(a)
        self.toolbar.addSeparator()
        self.toolbar.addAction(self.a_dup)
        self.toolbar.addAction(self.a_delete)
        align_btn = QToolButton()
        align_btn.setText("Align")
        align_btn.setIcon(glyph_icon("⫷", "#475569"))
        align_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        align_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.align_menu = QMenu("Align && Size", self)
        for label, mode in ALIGN_ACTIONS:
            if label == "-":
                self.align_menu.addSeparator()
            else:
                self.align_menu.addAction(label, lambda m=mode: self.canvas.align(m))
        align_btn.setMenu(self.align_menu)
        self.toolbar.addWidget(align_btn)
        self.toolbar.addAction(self.a_front)
        self.toolbar.addAction(self.a_back)
        self.toolbar.addSeparator()
        for a in (self.a_generate, self.a_preview, self.a_run, self.a_stop, self.a_build, self.a_installer):
            self.toolbar.addAction(a)
        self.toolbar.addSeparator()
        self.toolbar.addAction(self.a_ai)
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.toolbar.addWidget(spacer)
        for a in (self.a_undo, self.a_redo, self.a_dup, self.a_delete, self.a_front, self.a_back):
            btn = self.toolbar.widgetForAction(a)
            if btn is not None:
                btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonIconOnly)   # keep the toolbar compact
        self.snap_check = QCheckBox("Snap")
        self.snap_check.setChecked(True)
        self.snap_check.toggled.connect(self._set_snap)
        self.grid_check = QCheckBox("Grid")
        self.grid_check.setChecked(True)
        self.grid_check.toggled.connect(self._set_grid)
        self.toolbar.addWidget(self.snap_check)
        self.toolbar.addWidget(self.grid_check)

        # ---- centre: designer + source
        self.canvas = DesignCanvas()
        self.canvas.changed.connect(self._canvas_changed)
        self.canvas.selectionChanged.connect(self._selection_changed)
        self.canvas.historyChanged.connect(self._history_changed)
        self.canvas.formChanged.connect(self._form_changed)
        self.canvas.editEventsRequested.connect(self._edit_events_for)
        self.canvas.controlAdded.connect(lambda c: self.events.emit("control.added", c.to_dict()))
        self.form_frame = FormFrame(self.canvas)
        self.form_frame.setObjectName("formFrame")
        self.design_scroll = QScrollArea()
        self.design_scroll.setObjectName("designScroll")
        self.design_scroll.setWidget(self.form_frame)
        self.design_scroll.setAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
        self.design_scroll.viewport().setObjectName("designViewport")

        source_page = QWidget()
        sv = QVBoxLayout(source_page)
        sv.setContentsMargins(0, 0, 0, 0)
        sv.setSpacing(0)
        self.source_banner = QFrame()
        self.source_banner.setObjectName("sourceBanner")
        bl = QHBoxLayout(self.source_banner)
        bl.setContentsMargins(10, 6, 10, 6)
        self.source_banner_label = QLabel("✎ The source has manual edits, so designer changes no longer overwrite it.")
        regen = QPushButton("Regenerate from designer")
        regen.clicked.connect(lambda: self.regenerate_from_designer())
        bl.addWidget(self.source_banner_label, 1)
        bl.addWidget(regen)
        self.source_banner.setVisible(False)
        tools_row = QHBoxLayout()
        tools_row.setContentsMargins(6, 3, 6, 3)
        self._source_tools_host = QWidget()
        self._source_tools_host.setLayout(tools_row)
        self.editor = CodeEditor()
        self.editor.textChanged.connect(self._editor_changed)
        self.outline = OutlineCombo(self.editor)
        self.find_bar = FindBar(self.editor)
        tools_row.addWidget(self.outline)
        tools_row.addStretch(1)
        for text, slot in (("Find / Replace", lambda: self.open_find(False)), ("Insert snippet ▾", None),
                           ("Check syntax", self.check_syntax)):
            b = QToolButton()
            b.setText(text)
            b.setAutoRaise(True)
            if slot is None:
                b.setMenu(self._snippet_menu(lambda: self.editor))
                b.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
            else:
                b.clicked.connect(slot)
            tools_row.addWidget(b)
        sv.addWidget(self._source_tools_host)
        sv.addWidget(self.find_bar)
        sv.addWidget(self.source_banner)
        sv.addWidget(self.editor, 1)

        self.tabs = QTabWidget()
        self.tabs.setObjectName("centerTabs")
        self.tabs.setDocumentMode(True)
        self.tabs.addTab(self.design_scroll, make_icon(REGISTRY.get("Container"), 16), "Form Design")
        self.tabs.addTab(source_page, glyph_icon("{}", "#0f766e"), "Python Source")
        self.setCentralWidget(self.tabs)

        # ---- left dock: toolbox, templates, hierarchy, assets, plugins
        self.left_tabs = QTabWidget()
        self.left_tabs.setDocumentMode(True)
        self.left_tabs.setUsesScrollButtons(True)
        self.left_tabs.setElideMode(Qt.TextElideMode.ElideNone)
        comp = QWidget()
        cl = QVBoxLayout(comp)
        cl.setContentsMargins(4, 6, 4, 4)
        self.palette_search = QLineEdit()
        self.palette_search.setPlaceholderText("Search components…")
        self.palette_search.setClearButtonEnabled(True)
        self.palette = ComponentPalette()
        self.palette.insertRequested.connect(lambda kind: self.canvas.add_control(kind))
        self.palette_search.textChanged.connect(self.palette.apply_filter)
        cl.addWidget(self.palette_search)
        cl.addWidget(self.palette, 1)
        hint = QLabel(f"{len(REGISTRY.kinds())} components · drag or double-click")
        hint.setStyleSheet("color:#64748b;")
        self.palette_hint = hint
        cl.addWidget(hint)
        self.left_tabs.addTab(comp, "Toolbox")
        self.left_tabs.setTabToolTip(0, "Components")

        tpl = QWidget()
        tl = QVBoxLayout(tpl)
        tl.setContentsMargins(4, 6, 4, 4)
        self.template_list = QListWidget()
        self.template_list.setWordWrap(True)
        self.template_list.itemDoubleClicked.connect(lambda item: self.use_template(item.data(Qt.ItemDataRole.UserRole)))
        use = QPushButton("Use selected template")
        use.clicked.connect(lambda: self.use_template(self.template_list.currentItem().data(Qt.ItemDataRole.UserRole)
                                                        if self.template_list.currentItem() else None))
        tl.addWidget(self.template_list, 1)
        tl.addWidget(use)
        self.left_tabs.addTab(tpl, "Templates")

        hier = QWidget()
        hv = QVBoxLayout(hier)
        hv.setContentsMargins(4, 6, 4, 4)
        self.hierarchy = QTreeWidget()
        self.hierarchy.setHeaderLabels(["Control", "Type"])
        self.hierarchy.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.hierarchy.itemSelectionChanged.connect(self._hierarchy_selected)
        hv.addWidget(self.hierarchy, 1)
        hr = QHBoxLayout()
        for text, slot in (("Rename…", self._rename_selected), ("Delete", self._delete_selected)):
            b = QPushButton(text)
            b.clicked.connect(slot)
            hr.addWidget(b)
        hv.addLayout(hr)
        self.left_tabs.addTab(hier, "Outline")

        assets = QWidget()
        av = QVBoxLayout(assets)
        av.setContentsMargins(4, 6, 4, 4)
        self.asset_list = QListWidget()
        self.asset_list.setToolTip("Files in the project's assets folder. Double-click to use on the selected Image/Media control.")
        self.asset_list.itemDoubleClicked.connect(self._asset_activated)
        av.addWidget(self.asset_list, 1)
        ar = QHBoxLayout()
        for text, slot in (("Import…", self.import_asset), ("Open folder", self.open_assets_folder)):
            b = QPushButton(text)
            b.clicked.connect(slot)
            ar.addWidget(b)
        av.addLayout(ar)
        self.left_tabs.addTab(assets, "Assets")

        plug = QWidget()
        pv = QVBoxLayout(plug)
        pv.setContentsMargins(4, 6, 4, 4)
        self.plugin_list = QListWidget()
        self.plugin_list.itemDoubleClicked.connect(lambda _: self.show_plugin_manager())
        pv.addWidget(self.plugin_list, 1)
        pr = QHBoxLayout()
        for text, slot in (("Manage…", self.show_plugin_manager), ("New…", self.new_plugin)):
            b = QPushButton(text)
            b.clicked.connect(slot)
            pr.addWidget(b)
        pv.addLayout(pr)
        self.left_tabs.addTab(plug, "Plugins")

        self.left_dock = self._dock("Project", "leftDock", self.left_tabs, Qt.DockWidgetArea.LeftDockWidgetArea)
        self.left_dock.setMinimumWidth(250)

        # ---- right dock: properties, events, AI + overview
        self.right_tabs = QTabWidget()
        self.right_tabs.setDocumentMode(True)
        self.props_grid = PropertyGrid()
        self.props_grid.propertyEdited.connect(self._property_edited)
        self.props_grid.formEdited.connect(self._form_property_edited)
        self.props_grid.fontEdited.connect(lambda values: [self._property_edited(k, v) for k, v in values.items()])
        self.props_grid.asset_picker = self._pick_asset
        self.right_tabs.addTab(self.props_grid, "Properties")
        self.right_tabs.addTab(self._build_events_panel(), "Events")
        self.ai_panel = AIPanel(self)
        self.right_tabs.addTab(self.ai_panel, glyph_icon("✦", "#7c3aed"), "AI Assistant")
        right = QSplitter(Qt.Orientation.Vertical)
        right.addWidget(self.right_tabs)
        self.minimap = MiniMap(self)
        right.addWidget(self.minimap)
        right.setSizes([700, 130])
        right.setCollapsible(0, False)
        self.right_dock = self._dock("Inspector", "rightDock", right, Qt.DockWidgetArea.RightDockWidgetArea)
        self.right_dock.setMinimumWidth(320)

        # ---- bottom dock: console
        console_host = QWidget()
        cv = QVBoxLayout(console_host)
        cv.setContentsMargins(4, 2, 4, 4)
        cv.setSpacing(3)
        crow = QHBoxLayout()
        self.console_status = QLabel("Idle")
        self.goto_error_btn = QPushButton("Go to error")
        self.goto_error_btn.setVisible(False)
        self.goto_error_btn.clicked.connect(lambda: (self.tabs.setCurrentIndex(1), self.editor.go_to_line(self.last_error_line)))
        self.fix_ai_btn = QPushButton("✦ Fix with AI")
        self.fix_ai_btn.setVisible(False)
        self.fix_ai_btn.setObjectName("accentButton")
        self.fix_ai_btn.clicked.connect(lambda: self.focus_ai("fix_error", "Fix the error shown in the console output.", send=True))
        clear = QPushButton("Clear")
        clear.clicked.connect(lambda: self.console.clear())
        crow.addWidget(self.console_status, 1)
        for b in (self.goto_error_btn, self.fix_ai_btn, clear):
            crow.addWidget(b)
        cv.addLayout(crow)
        self.console = QPlainTextEdit()
        self.console.setReadOnly(True)
        self.console.setMaximumBlockCount(10000)
        self.console.setFont(QFont("Consolas", 9))
        self.console.setPlaceholderText("Run output, build diagnostics, plugin messages…")
        cv.addWidget(self.console, 1)
        self.console_dock = self._dock("Console", "consoleDock", console_host, Qt.DockWidgetArea.BottomDockWidgetArea)
        self.resizeDocks([self.console_dock], [170], Qt.Orientation.Vertical)
        self.resizeDocks([self.left_dock, self.right_dock], [320, 360], Qt.Orientation.Horizontal)

        self.setStatusBar(QStatusBar())
        self.sel_label = QLabel("")
        self.project_label = QLabel("")
        self.statusBar().addPermanentWidget(self.sel_label)
        self.statusBar().addPermanentWidget(self.project_label)
        self._refresh_templates()

    def _dock(self, title, name, widget, area):
        dock = QDockWidget(title, self)
        dock.setObjectName(name)
        dock.setWidget(widget)
        dock.setFeatures(QDockWidget.DockWidgetFeature.DockWidgetMovable | QDockWidget.DockWidgetFeature.DockWidgetFloatable
                         | QDockWidget.DockWidgetFeature.DockWidgetClosable)
        self.addDockWidget(area, dock)
        return dock

    def _build_events_panel(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(6, 6, 6, 6)
        v.setSpacing(5)
        self.ev_title = QLabel("<b>Select a control to edit its events</b>")
        self.ev_title.setWordWrap(True)
        v.addWidget(self.ev_title)
        self.ev_signals = QListWidget()
        self.ev_signals.setMaximumHeight(118)
        self.ev_signals.currentRowChanged.connect(self._signal_selected)
        v.addWidget(self.ev_signals)
        self.ev_sig_info = QLabel("")
        self.ev_sig_info.setStyleSheet("color:#64748b;")
        self.ev_sig_info.setWordWrap(True)
        v.addWidget(self.ev_sig_info)
        self.ev_code = CodeEditor()
        self.ev_code.setPlaceholderText('Handler statements, e.g.\nQMessageBox.information(self, "Hello", "Clicked!")')
        self.ev_code.textChanged.connect(lambda: None if self._loading_events else self._event_timer.start())
        v.addWidget(self.ev_code, 2)
        row = QHBoxLayout()
        ai = QPushButton("✦ Write with AI")
        ai.setObjectName("accentButton")
        ai.clicked.connect(self._ai_write_handler)
        rm = QPushButton("Remove handler")
        rm.clicked.connect(self._remove_handler)
        src = QPushButton("Show in source")
        src.clicked.connect(self._show_handler_in_source)
        row.addWidget(ai)
        row.addWidget(rm)
        row.addWidget(src)
        snip = QPushButton("Snippet ▾")
        snip.setMenu(self._snippet_menu(lambda: self.ev_code))
        row.addWidget(snip)
        v.addLayout(row)
        lbl = QLabel("<b>Helper methods</b> (class level — callable from any handler as self.method())")
        lbl.setWordWrap(True)
        v.addWidget(lbl)
        self.custom_methods = CodeEditor()
        self.custom_methods.setPlaceholderText("def reset_form(self):\n    self.txt_name.clear()")
        self.custom_methods.textChanged.connect(lambda: None if self._loading_events else self._methods_timer.start())
        v.addWidget(self.custom_methods, 2)
        self._event_control = None
        self._event_signal = ""
        return w

    def _build_menus(self):
        mb = self.menuBar()
        f = mb.addMenu("&File")
        f.addAction(self.a_new)
        self.template_menu = f.addMenu("New from Template")
        f.addAction(self.a_open)
        self.recent_menu = f.addMenu("Open Recent")
        f.addSeparator()
        f.addAction(self.a_save)
        f.addAction(self.a_save_as)
        imp = f.addMenu("Import")
        imp.addAction("Qt Designer Form (.ui)…", self.import_ui_file)
        imp.addAction("WaterPy Layout / Template (.json)…", self.import_layout_file)
        imp.addAction("Project from ZIP…", self.import_project_zip)
        imp.addSeparator()
        imp.addAction("CSV into Selected Grid…", self.import_csv_grid)
        imp.addAction("Items into Selected List / Combo…", self.import_items)
        imp.addAction("Assets…", self.import_asset)
        self.export_menu = f.addMenu("Export")
        f.addSeparator()
        f.addAction("Open Project Folder", lambda: open_folder(self.project_dir) if self.project_dir else
                    QMessageBox.information(self, "Project", "Save the project first."))
        f.addSeparator()
        f.addAction("Exit", self.close, QKeySequence("Alt+F4"))

        e = mb.addMenu("&Edit")
        for a in (self.a_undo, self.a_redo):
            e.addAction(a)
        e.addSeparator()
        for a in (self.a_cut, self.a_copy, self.a_paste, self.a_dup, self.a_delete, self.a_select_all):
            e.addAction(a)
        e.addSeparator()
        e.addAction("Rename Selected…", self._rename_selected, QKeySequence("F2"))
        e.addSeparator()
        e.addAction("Find…", lambda: self.open_find(False), QKeySequence("Ctrl+F"))
        e.addAction("Replace…", lambda: self.open_find(True), QKeySequence("Ctrl+H"))
        e.addAction("Find Next", lambda: self.find_bar.find_next(), QKeySequence("F3"))
        e.addAction("Find Previous", lambda: self.find_bar.find_next(backward=True), QKeySequence("Shift+F3"))
        e.addAction("Go to Line…", self.go_to_line, QKeySequence("Ctrl+G"))
        e.addAction("Go to Symbol…", lambda: (self.tabs.setCurrentIndex(1), self.outline.showPopup()), QKeySequence("Ctrl+Shift+O"))
        e.addMenu(self._snippet_menu(lambda: self._focused_code_editor(), "Insert Snippet"))
        e.addSeparator()
        e.addAction("Preferences…", self.show_preferences, QKeySequence("Ctrl+,"))

        self.view_menu = mb.addMenu("&View")
        self.view_menu.addAction("Form Design", lambda: self.tabs.setCurrentIndex(0), QKeySequence("Ctrl+1"))
        self.view_menu.addAction("Python Source", lambda: self.tabs.setCurrentIndex(1), QKeySequence("Ctrl+2"))
        self.view_menu.addAction("Toggle Design / Source", lambda: self.tabs.setCurrentIndex(1 - self.tabs.currentIndex()), QKeySequence("F12"))
        self.view_menu.addSeparator()
        a_grid = self.view_menu.addAction("Show Grid")
        a_grid.setCheckable(True)
        a_grid.setChecked(True)
        a_grid.toggled.connect(self.grid_check.setChecked)
        self.grid_check.toggled.connect(a_grid.setChecked)
        a_snap = self.view_menu.addAction("Snap to Grid")
        a_snap.setCheckable(True)
        a_snap.setChecked(True)
        a_snap.toggled.connect(self.snap_check.setChecked)
        self.snap_check.toggled.connect(a_snap.setChecked)
        self.view_menu.addSeparator()
        for dock in (self.left_dock, self.right_dock, self.console_dock):
            self.view_menu.addAction(dock.toggleViewAction())
        self.view_menu.addAction("Reset Layout", self.reset_layout)
        self.view_menu.addSeparator()

        fm = mb.addMenu("F&ormat")
        for label, mode in ALIGN_ACTIONS:
            if label == "-":
                fm.addSeparator()
            else:
                fm.addAction(label, lambda m=mode: self.canvas.align(m))
        fm.addSeparator()
        fm.addAction(self.a_front)
        fm.addAction(self.a_back)
        fm.addSeparator()
        fm.addAction("Form Settings…", lambda: (self.canvas.set_selection([]), self.right_tabs.setCurrentIndex(0)))

        p = mb.addMenu("&Project")
        p.addAction("Build Settings…", self.show_build_settings)
        p.addAction("Tab Order…", self.edit_tab_order)
        p.addAction("Save Form as Template…", self.save_as_template)
        p.addSeparator()
        p.addAction("Import Assets…", self.import_asset)
        p.addAction("Open Assets Folder", self.open_assets_folder)
        p.addSeparator()
        p.addAction("Python Package Manager…", self.show_package_manager)

        r = mb.addMenu("&Run")
        r.addAction(self.a_generate)
        r.addAction("Check Syntax", self.check_syntax, QKeySequence("Ctrl+F7"))
        r.addSeparator()
        r.addAction(self.a_preview)
        r.addAction(self.a_run)
        r.addAction(self.a_stop)
        r.addSeparator()
        r.addAction(self.a_build)
        r.addAction(self.a_installer)
        r.addAction("Open Build Output Folder", self.open_build_folder)

        ai = mb.addMenu("&AI")
        ai.addAction("AI Assistant Panel", lambda: self.focus_ai(None))
        ai.addSeparator()
        ai.addAction(self.a_ai)
        ai.addAction("Generate App from Description…", lambda: self.focus_ai("generate_app"))
        ai.addAction("Modify Source…", lambda: self.focus_ai("modify_source"))
        ai.addAction("Write Handler for Selected Control", self._ai_write_handler)
        ai.addSeparator()
        ai.addAction("Explain Code (teaching)", lambda: self.focus_ai("explain", "Explain how the current application works.", send=True))
        ai.addAction("Review Code", lambda: self.focus_ai("review", "Review the current source.", send=True))
        ai.addAction("Fix Last Error", lambda: self.focus_ai("fix_error", "Fix the error shown in the console output.", send=True))
        ai.addSeparator()
        ai.addAction("AI Settings…", lambda: self.ai_panel.open_settings())

        pl = mb.addMenu("Plu&gins")
        pl.addAction("Plugin Manager…", self.show_plugin_manager)
        pl.addAction("New Plugin…", self.new_plugin)
        pl.addAction("Reload All Plugins", lambda: self._load_plugins(reload=True), QKeySequence("Ctrl+Shift+R"))
        pl.addAction("Open User Plugins Folder", lambda: open_folder(self.plugins.user_folder))
        pl.addSeparator()
        pl.addAction("Plugin SDK Guide", self.show_sdk_guide)

        ap = mb.addMenu("Appea&rance")
        group = QActionGroup(self)
        self.theme_actions = {}
        for theme in THEMES:
            a = ap.addAction(theme, lambda t=theme: self.apply_theme(t))
            a.setCheckable(True)
            group.addAction(a)
            self.theme_actions[theme] = a

        self.help_menu = mb.addMenu("&Help")
        self.help_menu.addAction("Getting Started", lambda: MarkdownViewer("WaterPyDesktop — Read me", APP_DIR / "README.md", self).exec())
        self.help_menu.addAction("Plugin SDK Guide", self.show_sdk_guide)
        self.help_menu.addAction("Keyboard Shortcuts", self.show_shortcuts)
        self.help_menu.addSeparator()
        self.help_menu.addAction("About WaterPyDesktop", self.show_about)
        self.rebuild_export_menu()
        self._refresh_recent()

    # ================================================================= helpers
    def log(self, message: str, level: str = "info"):
        colours = {"error": "#dc2626", "warning": "#d97706", "success": "#16a34a", "info": "#64748b"}
        self.console.appendHtml(f"<span style='color:{colours.get(level, '#64748b')}'>{html.escape(str(message)).replace(chr(10), '<br>')}</span>")
        if level == "error":
            self.console_dock.show()

    def plugin_menu(self, title: str) -> QMenu:
        for action in self.menuBar().actions():
            if action.menu() and action.text().replace("&", "") == title:
                return action.menu()
        menu = QMenu(title, self)
        self.menuBar().insertMenu(self.help_menu.menuAction(), menu)
        self._plugin_menus[title] = menu
        return menu

    def prune_plugin_menu(self, menu: QMenu):
        if menu in self._plugin_menus.values() and not menu.actions():
            self.menuBar().removeAction(menu.menuAction())
            self._plugin_menus = {k: m for k, m in self._plugin_menus.items() if m is not menu}

    def plugin_toolbar(self) -> QToolBar:
        if self._plugin_toolbar is None:
            self._plugin_toolbar = QToolBar("Plugins")
            self._plugin_toolbar.setObjectName("pluginToolbar")
            self.addToolBar(self._plugin_toolbar)
            self._plugin_toolbar.setVisible(False)
            self.view_menu.addAction(self._plugin_toolbar.toggleViewAction())
        return self._plugin_toolbar

    def rebuild_export_menu(self):
        if not hasattr(self, "export_menu"):
            return
        self.export_menu.clear()
        self.export_menu.addAction("Python Source (.py)…", self.save_python_as)
        self.export_menu.addAction("Project as ZIP…", self.export_zip)
        self.export_menu.addAction("PyQt6 Source (.py)…", self.export_pyqt6)
        self.export_menu.addSeparator()
        self.export_menu.addAction("WaterPy Layout (.json)…", self.export_layout_file)
        self.export_menu.addAction("HTML Mockup (.html)…", self.export_html_mockup)
        self.export_menu.addAction("Form Image (PNG)…", lambda: self.export_form_image("png"))
        self.export_menu.addAction("Form Image (PDF)…", lambda: self.export_form_image("pdf"))
        self.export_menu.addAction("Documentation (Markdown / HTML)…", self.export_docs)
        if self.exporters:
            self.export_menu.addSeparator()
        for owner, name, file_filter, fn in self.exporters:
            self.export_menu.addAction(name + "…", lambda f=fn, flt=file_filter, n=name: self._run_exporter(n, flt, f))

    def _run_exporter(self, name, file_filter, fn):
        path, _ = QFileDialog.getSaveFileName(self, f"Export — {name}", str(self.project_dir or Path.home()), file_filter)
        if not path:
            return
        try:
            fn(self.project_data(), Path(path))
            self.statusBar().showMessage(f"Exported {path}", 5000)
            self.log(f"Exported {name}: {path}", "success")
        except Exception as exc:
            QMessageBox.critical(self, "Export failed", str(exc))

    # ================================================================ theming
    def apply_theme(self, theme: str = "Professional Light"):
        if theme not in THEMES:
            theme = "Professional Light"
        self.current_theme = theme
        win, panel, text, border, accent, hover, dark = THEMES[theme]
        app = QApplication.instance()
        pal = QPalette()
        pal.setColor(QPalette.ColorRole.Window, QColor(win))
        pal.setColor(QPalette.ColorRole.WindowText, QColor(text))
        pal.setColor(QPalette.ColorRole.Base, QColor(panel))
        pal.setColor(QPalette.ColorRole.AlternateBase, QColor(hover))
        pal.setColor(QPalette.ColorRole.Text, QColor(text))
        pal.setColor(QPalette.ColorRole.Button, QColor(panel))
        pal.setColor(QPalette.ColorRole.ButtonText, QColor(text))
        pal.setColor(QPalette.ColorRole.Highlight, QColor(accent))
        pal.setColor(QPalette.ColorRole.HighlightedText, QColor("#ffffff"))
        pal.setColor(QPalette.ColorRole.ToolTipBase, QColor(panel))
        pal.setColor(QPalette.ColorRole.ToolTipText, QColor(text))
        pal.setColor(QPalette.ColorRole.PlaceholderText, QColor("#8b95a5" if dark else "#94a3b8"))
        pal.setColor(QPalette.ColorRole.Link, QColor(accent))
        app.setPalette(pal)
        chrome = f"""
        QToolBar {{ background:{panel}; border:0; border-bottom:1px solid {border}; spacing:3px; padding:4px; }}
        QToolBar QToolButton {{ padding:4px 7px; border-radius:5px; }}
        QToolBar QToolButton:hover {{ background:{hover}; }}
        QMenuBar {{ background:{panel}; border-bottom:1px solid {border}; }}
        QMenuBar::item {{ padding:5px 10px; border-radius:4px; }} QMenuBar::item:selected {{ background:{hover}; }}
        QDockWidget::title {{ background:{win}; padding:6px; font-weight:600; }}
        QTabBar::tab {{ padding:6px 9px; border:0; border-bottom:2px solid transparent; }}
        QTabBar::tab:selected {{ color:{accent}; border-bottom:2px solid {accent}; }}
        QTabBar::tab:hover {{ background:{hover}; }}
        QPushButton {{ background:{panel}; border:1px solid {border}; border-radius:5px; padding:5px 10px; }}
        QPushButton:hover {{ background:{hover}; border-color:{accent}; }}
        QPushButton:disabled {{ color:#8b95a5; }}
        QPushButton#primaryButton {{ background:{accent}; color:white; border-color:{accent}; font-weight:600; }}
        QPushButton#accentButton {{ color:{'#c4b5fd' if dark else '#6d28d9'}; border-color:{'#6d28d9' if dark else '#c4b5fd'}; }}
        QToolButton#chip {{ border:1px solid {border}; border-radius:10px; padding:2px 8px; background:{panel}; }}
        QToolButton#chip:hover {{ border-color:{accent}; background:{hover}; }}
        QLineEdit, QPlainTextEdit, QTextBrowser, QListWidget, QTreeWidget, QTableWidget, QSpinBox, QDoubleSpinBox, QComboBox {{
            border:1px solid {border}; border-radius:4px; background:{panel}; selection-background-color:{accent}; }}
        QTreeWidget#componentPalette::item {{ padding:3px 2px; }}
        QFrame#sourceBanner {{ background:{'#3b2f12' if dark else '#fff7e0'}; border-bottom:1px solid {'#7a5b12' if dark else '#f2d48a'}; }}
        QStatusBar {{ background:{panel}; border-top:1px solid {border}; }}
        """
        for w in (self.menuBar(), self.toolbar, self.left_dock, self.right_dock, self.console_dock, self.statusBar(),
                  self.tabs.tabBar(), self.source_banner, self._plugin_toolbar):
            if w is not None:
                w.setStyleSheet(chrome)
        for dock in self.findChildren(QDockWidget):
            dock.setStyleSheet(chrome)
        vp = self.design_scroll.viewport()
        vpal = vp.palette()
        for role in (QPalette.ColorRole.Window, QPalette.ColorRole.Base):
            vpal.setColor(role, QColor("#2a2f38" if dark else "#d8dee7"))
        vp.setPalette(vpal)
        vp.setAutoFillBackground(True)
        self.design_scroll.setFrameShape(QFrame.Shape.NoFrame)
        # Keep the design surface WYSIWYG: generated apps use the default light palette.
        std = QApplication.style().standardPalette()
        light = QPalette()
        for group in (QPalette.ColorGroup.Active, QPalette.ColorGroup.Inactive, QPalette.ColorGroup.Disabled):
            for role in range(QPalette.ColorRole.NColorRoles.value):
                r = QPalette.ColorRole(role)
                light.setColor(group, r, std.color(group, r))   # explicit roles => not inherited from the app
        self.canvas.set_base_palette(light)
        self.editor.set_dark(dark)
        self.ev_code.set_dark(dark)
        self.custom_methods.set_dark(dark)
        if theme in getattr(self, "theme_actions", {}):
            self.theme_actions[theme].setChecked(True)
        self.events.emit("theme.changed", theme)
        self.statusBar().showMessage(f"Theme: {theme}", 2500)

    # ============================================================== settings
    def _settings(self):
        return QSettings("WaterPyDesktop", "WaterPyDesktop")

    def load_settings(self):
        s = self._settings()
        geo = s.value("window/geometry")
        if isinstance(geo, QByteArray):
            self.restoreGeometry(geo)
        state = s.value("window/state")
        if isinstance(state, QByteArray):
            self.restoreState(state)
        self.apply_theme(str(s.value("ui/theme", "Professional Light")))
        self.editor.set_font_size(int(s.value("ui/editor_font", 10)))
        self.canvas.grid_size = int(s.value("ui/grid", 10))
        self.auto_regenerate = str(s.value("ui/auto_regen", "true")).lower() == "true"
        self.set_autosave(int(s.value("ui/autosave", 0)))

    def save_settings(self):
        s = self._settings()
        s.setValue("window/geometry", self.saveGeometry())
        s.setValue("window/state", self.saveState())
        s.setValue("ui/theme", self.current_theme)
        s.setValue("ui/editor_font", self.editor.font().pointSize())
        s.setValue("ui/grid", self.canvas.grid_size)
        s.setValue("ui/auto_regen", "true" if self.auto_regenerate else "false")
        s.setValue("ui/autosave", self.autosave_minutes)

    def set_autosave(self, minutes: int):
        self.autosave_minutes = max(0, int(minutes))
        self.autosave_timer.stop()
        if self.autosave_minutes:
            self.autosave_timer.start(self.autosave_minutes * 60_000)

    def _autosave(self):
        if self.modified and self.project_file:
            self.save_project()
            self.statusBar().showMessage("Auto-saved", 2500)

    def reset_layout(self):
        for dock, area in ((self.left_dock, Qt.DockWidgetArea.LeftDockWidgetArea), (self.right_dock, Qt.DockWidgetArea.RightDockWidgetArea),
                           (self.console_dock, Qt.DockWidgetArea.BottomDockWidgetArea)):
            dock.setFloating(False)
            self.addDockWidget(area, dock)
            dock.show()
        self.resizeDocks([self.left_dock, self.right_dock], [320, 360], Qt.Orientation.Horizontal)
        self.resizeDocks([self.console_dock], [170], Qt.Orientation.Vertical)

    def show_preferences(self):
        dlg = PreferencesDialog(self)
        if dlg.exec():
            dlg.apply()

    # ================================================================ designer
    def _set_snap(self, on):
        self.canvas.snap_to_grid = bool(on)

    def _set_grid(self, on):
        self.canvas.show_grid = bool(on)
        self.canvas.update()

    def _set_modified(self, flag=True):
        self.modified = flag
        name = self.project_name + (" •" if flag else "")
        self.setWindowTitle(f"{name} — WaterPyDesktop {__edition__}")
        self.project_label.setText(f"  {self.project_dir or 'not saved yet'}  ")

    def _canvas_changed(self):
        if self.canvas._restoring:
            return
        self._set_modified(True)
        self._regen_timer.start()
        self.minimap.update()
        c = self.canvas.selected
        if c is not None and self.props_grid.control is c:
            self.props_grid.refresh_values(c.props)
            self._update_sel_label()

    def _debounced_refresh(self):
        self._refresh_hierarchy()
        self.minimap.update()
        if self.auto_regenerate:
            self.refresh_code()

    def _history_changed(self):
        self.a_undo.setEnabled(self.canvas.history.can_undo())
        self.a_redo.setEnabled(self.canvas.history.can_redo())

    def _form_changed(self):
        if self.canvas.selected is None:
            self.props_grid.show_form(self.canvas.form_settings)
        self.minimap.update()

    def _selection_changed(self, primary):
        self._flush_event_code()
        sel = self.canvas.selection
        if primary is None:
            self.props_grid.show_form(self.canvas.form_settings)
        else:
            self.props_grid.show_control(primary, len(sel))
        self._load_events(primary)
        self._sync_hierarchy_selection()
        self._update_sel_label()
        self.minimap.update()
        has = bool(sel)
        for a in (self.a_cut, self.a_copy, self.a_dup, self.a_delete, self.a_front, self.a_back):
            a.setEnabled(has)
        self.events.emit("selection.changed", [c.objectName() for c in sel])

    def _update_sel_label(self):
        c = self.canvas.selected
        n = len(self.canvas.selection)
        if not c:
            self.sel_label.setText(f"  Form {self.canvas.width()}×{self.canvas.height()}  ")
        else:
            extra = f" (+{n - 1})" if n > 1 else ""
            self.sel_label.setText(f"  {c.objectName()}{extra} · {c.kind} · {c.x()},{c.y()}  {c.width()}×{c.height()}  ")

    def _property_edited(self, key, value):
        targets = [self.canvas.selected] if key == "name" else list(self.canvas.selection)
        for c in targets:
            if c is None:
                continue
            if key == "name":
                new = self.canvas.unique_name(str(value).strip() or c.kind, exclude=c)
                c.props["name"] = new
                c.setObjectName(new)
                if new != value:
                    self.props_grid.refresh_values({"name": new})
            elif c.spec.property(key) is not None:
                c.props[key] = c.spec.property(key).coerce(value)
            else:
                continue
            c.apply_properties()
        self.canvas.changed.emit()
        self._commit_timer.start()
        if key == "name":
            self._refresh_hierarchy()
            self._load_events(self.canvas.selected)

    def _form_property_edited(self, key, value):
        self.canvas.apply_form_settings(**{key: value})
        self.form_frame.refresh()
        self._commit_timer.start()

    def _refresh_hierarchy(self):
        self.hierarchy.blockSignals(True)
        self.hierarchy.clear()
        for c in self.canvas.controls_widgets():
            it = QTreeWidgetItem([c.objectName(), c.kind])
            it.setIcon(0, make_icon(c.spec, 16))
            it.setData(0, Qt.ItemDataRole.UserRole, c.objectName())
            if c.props.get("events"):
                it.setToolTip(0, "Handles: " + ", ".join(c.props["events"]))
                it.setText(1, c.kind + "  ⚡")
            self.hierarchy.addTopLevelItem(it)
            it.setSelected(c in self.canvas.selection)
        self.hierarchy.resizeColumnToContents(0)
        self.hierarchy.blockSignals(False)

    def _sync_hierarchy_selection(self):
        names = {c.objectName() for c in self.canvas.selection}
        self.hierarchy.blockSignals(True)
        for i in range(self.hierarchy.topLevelItemCount()):
            it = self.hierarchy.topLevelItem(i)
            it.setSelected(it.data(0, Qt.ItemDataRole.UserRole) in names)
        self.hierarchy.blockSignals(False)

    def _hierarchy_selected(self):
        names = {it.data(0, Qt.ItemDataRole.UserRole) for it in self.hierarchy.selectedItems()}
        self.canvas.set_selection([c for c in self.canvas.controls_widgets() if c.objectName() in names])

    def _rename_selected(self):
        c = self.canvas.selected
        if not c:
            return
        value, ok = QInputDialog.getText(self, "Rename control", "Object name (Python identifier):", text=c.objectName())
        if ok and value.strip():
            self._property_edited("name", value)
            self.props_grid.show_control(c, len(self.canvas.selection))

    def _delete_selected(self):
        self.canvas.delete_selection()

    def _registry_changed(self):
        self._refresh_templates()
        self.palette_hint.setText(f"{len(REGISTRY.kinds())} components · drag or double-click")

    # ================================================================== events
    def _load_events(self, control):
        self._loading_events = True
        try:
            self._event_control = control
            self.ev_signals.clear()
            self.ev_code.clear()
            if control is None or not control.spec.signals:
                self.ev_title.setText("<b>Select a control to edit its events</b>" if control is None
                                      else f"<b>{control.objectName()}</b> ({control.kind}) has no events")
                self.ev_code.setEnabled(False)
                self.ev_sig_info.clear()
                self._event_signal = ""
                return
            self.ev_code.setEnabled(True)
            self.ev_title.setText(f"<b>{control.objectName()}</b> · {control.kind} — choose a signal, then write its handler")
            events = control.props.get("events") or {}
            target = next((s for s in control.spec.signals if s in events), control.spec.default_signal)
            for sig in control.spec.signals:
                item = QListWidgetItem(("● " if sig in events else "○ ") + sig)
                item.setData(Qt.ItemDataRole.UserRole, sig)
                self.ev_signals.addItem(item)
            rows = list(control.spec.signals)
            self.ev_signals.setCurrentRow(rows.index(target) if target in rows else 0)
        finally:
            self._loading_events = False
        self._signal_selected(self.ev_signals.currentRow())

    def _signal_selected(self, row):
        if self._loading_events:
            return
        self._flush_event_code()
        c = self._event_control
        item = self.ev_signals.item(row) if row >= 0 else None
        if c is None or item is None:
            return
        sig = item.data(Qt.ItemDataRole.UserRole)
        self._event_signal = sig
        args = c.spec.signals.get(sig, "")
        from .registry import snake
        self.ev_sig_info.setText(f"Handler: <code>on_{c.objectName()}_{snake(sig)}(self, *args)</code>"
                                 + (f" — args: {args}" if args else ""))
        self._loading_events = True
        self.ev_code.setPlainText((c.props.get("events") or {}).get(sig, ""))
        self._loading_events = False

    def _flush_event_code(self):
        if self._event_timer.isActive():
            self._event_timer.stop()
            self._store_event_code()

    def _store_event_code(self):
        c, sig = self._event_control, self._event_signal
        if c is None or not sig or c.parent() is None:
            return
        code = self.ev_code.toPlainText()
        events = dict(c.props.get("events") or {})
        if code.strip():
            events[sig] = code
        else:
            events.pop(sig, None)
        if events == (c.props.get("events") or {}):
            return
        c.props["events"] = events
        for i in range(self.ev_signals.count()):
            it = self.ev_signals.item(i)
            s = it.data(Qt.ItemDataRole.UserRole)
            it.setText(("● " if s in events else "○ ") + s)
        self.canvas.changed.emit()
        self.canvas.commit()

    def _remove_handler(self):
        self.ev_code.clear()
        self._flush_event_code()
        self._store_event_code()

    def _edit_events_for(self, control):
        self.canvas.set_selection([control])
        self.right_tabs.setCurrentIndex(1)
        self.ev_code.setFocus()

    def _show_handler_in_source(self):
        c, sig = self._event_control, self._event_signal
        if not c or not sig:
            return
        from .registry import snake
        self._flush_event_code()
        self.refresh_code()
        name = f"def on_{c.objectName()}_{snake(sig)}("
        for i, line in enumerate(self.editor.toPlainText().splitlines(), 1):
            if name in line:
                self.tabs.setCurrentIndex(1)
                self.editor.go_to_line(i)
                return
        self.statusBar().showMessage("No handler code yet for this signal", 3000)

    def _store_custom_methods(self):
        code = self.custom_methods.toPlainText()
        if code != self.custom_methods_code:
            self.custom_methods_code = code
            self._set_modified(True)
            self._regen_timer.start()

    def set_custom_methods(self, code: str):
        self._loading_events = True
        self.custom_methods.setPlainText(code or "")
        self._loading_events = False
        self.custom_methods_code = code or ""
        self._set_modified(True)
        self._regen_timer.start()

    def apply_event_code(self, code: str):
        c = self.canvas.selected
        if c is None or not c.spec.signals:
            QMessageBox.information(self, "Event handler", "Select a control with events on the form first.")
            return
        if self._event_control is not c:
            self._load_events(c)
        self.right_tabs.setCurrentIndex(1)
        self.ev_code.setPlainText(code)
        self._event_timer.stop()
        self._store_event_code()
        self.statusBar().showMessage(f"Handler applied to {c.objectName()}.{self._event_signal}", 4000)

    def _ai_write_handler(self):
        c = self.canvas.selected
        if c is None or not c.spec.signals:
            QMessageBox.information(self, "AI", "Select a control with events first.")
            return
        sig = self._event_signal or c.spec.default_signal
        current = self.ev_code.toPlainText().strip()
        prompt, ok = QInputDialog.getMultiLineText(self, "Write handler with AI",
                                                   f"What should happen when {c.objectName()}.{sig} fires?",
                                                   current and f"Improve this handler:\n{current}" or "")
        if ok and prompt.strip():
            self.focus_ai("event_handler", prompt, send=True)

    # ================================================================== source
    def _editor_changed(self):
        if self._setting_source:
            return
        self._set_modified(True)
        if not self.source_dirty:
            self.source_dirty = True
            self.source_banner.setVisible(True)

    def set_source(self, text: str, user_edit: bool = False):
        """Replace the editor text through a cursor so the editor's own Undo still works."""
        self._setting_source = True
        try:
            bar = self.editor.verticalScrollBar().value()
            cursor = QTextCursor(self.editor.document())
            cursor.beginEditBlock()
            cursor.select(QTextCursor.SelectionType.Document)
            cursor.insertText(text)
            cursor.endEditBlock()
            self.editor.verticalScrollBar().setValue(bar)
        finally:
            self._setting_source = False
        self.source_dirty = bool(user_edit)
        self.source_banner.setVisible(self.source_dirty)
        if user_edit:
            self._set_modified(True)

    def generate_source(self) -> str:
        return generate_python(self.project_name, self.canvas.form_settings.get("title", ""), self.canvas.controls(),
                               self.custom_methods_code, form=self.canvas.form_settings,
                               transforms=[fn for _, fn in self.code_transforms])

    def refresh_code(self, *args, force: bool = False) -> str:
        """Regenerate the source from the visual designer (unless the source was edited by hand)."""
        if self.source_dirty and not force:
            return self.editor.toPlainText()
        try:
            source = self.generate_source()
        except Exception as exc:
            self.log(f"Code generation failed: {exc}", "error")
            return ""
        if source != self.editor.toPlainText():
            self.set_source(source, user_edit=False)
        else:
            self.source_dirty = False
            self.source_banner.setVisible(False)
        self.events.emit("code.generated", source, self.project_data(include_source=False))
        return source

    def regenerate_from_designer(self):
        if self.source_dirty:
            ans = QMessageBox.question(self, "Regenerate source",
                                       "The Python source has manual edits that are not in the designer.\n\n"
                                       "Regenerate and replace them? (You can undo in the editor with Ctrl+Z.)")
            if ans != QMessageBox.StandardButton.Yes:
                return
        self._flush_event_code()
        self._store_custom_methods()
        self.refresh_code(force=True)
        self.tabs.setCurrentIndex(1)
        self.statusBar().showMessage("Python source regenerated from the designer", 3000)

    # ================================================================== project
    def project_data(self, include_source: bool = True) -> dict:
        form = dict(self.canvas.form_settings)
        data = {"format": "waterpy-project", "version": 5, "generator": f"WaterPyDesktop {__version__}",
                "name": self.project_name, "title": form.get("title", ""), "form": form,
                "controls": self.canvas.controls(), "custom_methods": self.custom_methods_code,
                "assets_directory": "assets", "build": dict(self.build_settings),
                "installer": dict(self.installer_settings)}
        if include_source:
            data["source"] = self.editor.toPlainText()
            data["source_dirty"] = self.source_dirty
        return data

    def _new_project(self, silent=False):
        self.project_name, self.project_dir, self.project_file = "Untitled", None, None
        self.build_settings, self.installer_settings = {}, {}
        self.canvas.load_controls([], form=dict(DEFAULT_FORM))
        self.set_custom_methods("")
        self.source_dirty = False
        self.refresh_code(force=True)
        self._refresh_assets()
        self._refresh_hierarchy()
        self.tabs.setCurrentIndex(0)
        self._set_modified(False)
        self.events.emit("project.new", self.project_data(include_source=False))
        if not silent:
            self.statusBar().showMessage("New project created", 3000)

    def new_project(self):
        if self._confirm_discard():
            self._new_project()

    def use_template(self, name):
        tpl = REGISTRY.template(name) if name else None
        if not tpl:
            return
        self.apply_layout({"form": tpl.form, "controls": tpl.controls, "custom_methods": tpl.custom_methods}, confirm=True)

    def new_from_template(self, name):
        if self._confirm_discard():
            self._new_project(silent=True)
            tpl = REGISTRY.template(name)
            if tpl:
                self.apply_layout({"form": tpl.form, "controls": tpl.controls, "custom_methods": tpl.custom_methods}, confirm=False)
                self.statusBar().showMessage(f"New project from template: {name}", 3000)

    def _refresh_templates(self):
        if not hasattr(self, "template_list"):
            return
        self.template_list.clear()
        menu = getattr(self, "template_menu", None)
        if menu is not None:
            menu.clear()
        for tpl in REGISTRY.templates():
            item = QListWidgetItem(f"{tpl.name}\n{tpl.description}")
            item.setData(Qt.ItemDataRole.UserRole, tpl.name)
            item.setToolTip(f"{tpl.name} — {len(tpl.controls)} controls ({tpl.category})")
            self.template_list.addItem(item)
            if menu is not None:
                menu.addAction(tpl.name, lambda n=tpl.name: self.new_from_template(n))

    def apply_layout(self, layout: dict, confirm: bool = True):
        controls = layout.get("controls") or []
        mode = "replace"
        if confirm and self.canvas.controls_widgets():
            box = QMessageBox(self)
            box.setWindowTitle("Apply layout")
            box.setText(f"Apply {len(controls)} controls to the designer?")
            box.setInformativeText("Replace the current form, or add the new controls to it? (Undo is available.)")
            rep = box.addButton("Replace form", QMessageBox.ButtonRole.AcceptRole)
            add = box.addButton("Add to form", QMessageBox.ButtonRole.ActionRole)
            box.addButton(QMessageBox.StandardButton.Cancel)
            box.exec()
            if box.clickedButton() not in (rep, add):
                return
            mode = "replace" if box.clickedButton() is rep else "add"
        form = layout.get("form") or {}
        self.canvas._restoring = True
        try:
            if mode == "replace":
                self.canvas.clear_controls(record=False)
                self.canvas.form_settings = {**DEFAULT_FORM, **form}
                self.canvas.apply_form_settings()
            for d in controls:
                self.canvas.add_control(d.get("type", "Label"), data=dict(d), select=False, record=False)
        finally:
            self.canvas._restoring = False
        methods = layout.get("custom_methods") or ""
        if methods:
            if mode == "add" and self.custom_methods_code.strip():
                methods = self.custom_methods_code.rstrip() + "\n\n" + methods
            self.set_custom_methods(methods)
        elif mode == "replace":
            self.set_custom_methods("")
        self.canvas.formChanged.emit()
        self.canvas.changed.emit()
        self.canvas.commit()
        self.canvas.set_selection([])
        self.source_dirty = False
        self.refresh_code(force=True)
        self._refresh_hierarchy()
        self.tabs.setCurrentIndex(0)
        self.statusBar().showMessage(f"Layout applied: {len(controls)} controls", 4000)

    def open_project(self, path=None):
        if not self._confirm_discard():
            return
        if not path:
            path, _ = QFileDialog.getOpenFileName(self, "Open WaterPy project", str(self.project_dir or Path.home()),
                                                  "WaterPy Project (*.waterpy.json);;JSON (*.json)")
        if not path:
            return
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            if data.get("format") not in (None, "waterpy-project"):
                raise ValueError("Not a WaterPy project file")
            self.project_file = Path(path)
            self.project_dir = self.project_file.parent
            name = self.project_file.name
            self.project_name = data.get("name") or (name[:-len(".waterpy.json")] if name.endswith(".waterpy.json") else self.project_file.stem)
            form = {**DEFAULT_FORM, **(data.get("form") or {})}
            if not (data.get("form") or {}).get("title") and data.get("title"):
                form["title"] = data["title"]
            self.canvas.load_controls(data.get("controls", []), form=form)
            self.set_custom_methods(data.get("custom_methods", ""))
            self.build_settings = dict(data.get("build") or {})
            self.installer_settings = dict(data.get("installer") or {})
            version = int(data.get("version", 3))
            saved_source = data.get("source") or ""
            if version >= 5 and not data.get("source_dirty"):
                self.source_dirty = False
                self.refresh_code(force=True)
            elif saved_source.strip():
                self.set_source(saved_source, user_edit=True)
                if version < 5:
                    self.source_banner_label.setText("✎ Source loaded from an older WaterPyDesktop project. "
                                                     "Regenerate to use the new code generator (multi-event handlers, auto-imports).")
            else:
                self.refresh_code(force=True)
            self._refresh_assets()
            self._refresh_hierarchy()
            self._set_modified(False)
            self._add_recent(path)
            self.canvas.preview_context["project_dir"] = self.project_dir
            for c in self.canvas.controls_widgets():
                c.apply_properties()
            self.events.emit("project.opened", self.project_data(include_source=False))
            self.statusBar().showMessage(f"Opened {path}", 4000)
        except Exception as exc:
            QMessageBox.critical(self, "Open failed", str(exc))

    def _confirm_discard(self) -> bool:
        if not self.modified:
            return True
        ans = QMessageBox.question(self, "Unsaved changes", f"Save changes to {self.project_name}?",
                                   QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel)
        if ans == QMessageBox.StandardButton.Save:
            return self.save_project()
        return ans == QMessageBox.StandardButton.Discard

    def save_project_as(self):
        old = self.project_file
        self.project_file = None
        if not self.save_project():
            self.project_file = old
            return False
        return True

    def save_project(self) -> bool:
        """Save a complete, runnable project folder (project JSON, main.py, requirements, README, assets/)."""
        self._flush_event_code()
        self._store_custom_methods()
        if not self.project_file:
            suggested = f"{self.project_name if self.project_name != 'Untitled' else 'WaterPyProject'}.waterpy.json"
            path, _ = QFileDialog.getSaveFileName(self, "Save WaterPy project", str(Path.home() / suggested),
                                                  "WaterPy Project (*.waterpy.json);;JSON (*.json)")
            if not path:
                return False
            pf = Path(path)
            if not pf.name.lower().endswith(".waterpy.json"):
                pf = pf.with_name((pf.stem if pf.suffix.lower() == ".json" else pf.name) + ".waterpy.json")
            self.project_file, self.project_dir = pf, pf.parent
            self.project_name = pf.name[:-len(".waterpy.json")]
            self.canvas.preview_context["project_dir"] = self.project_dir
        try:
            self.project_dir.mkdir(parents=True, exist_ok=True)
            (self.project_dir / "assets").mkdir(exist_ok=True)
            if not self.source_dirty:
                self.refresh_code(force=True)
            data = self.project_data()
            data["project_file"] = self.project_file.name
            self.project_file.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
            (self.project_dir / "main.py").write_text(data["source"], encoding="utf-8")
            reqs = ["PySide6>=6.7,<7"]
            req_file = self.project_dir / "requirements.txt"
            if req_file.exists():
                existing = [l.strip() for l in req_file.read_text(encoding="utf-8").splitlines() if l.strip()]
                reqs += [l for l in existing if not l.lower().startswith("pyside6")]
            req_file.write_text("\n".join(reqs) + "\n", encoding="utf-8")
            readme = self.project_dir / "README.md"
            if not readme.exists():
                readme.write_text(f"# {self.project_name}\n\nCreated with WaterPyDesktop {__version__}.\n\n"
                                  "- `main.py` — runnable PySide6 application source\n"
                                  f"- `{self.project_file.name}` — editable WaterPy visual project\n"
                                  "- `assets/` — images, icons, audio and other files used by the app\n"
                                  "- `requirements.txt` — Python dependencies\n\nRun with `python main.py`.\n", encoding="utf-8")
            self._refresh_assets()
            self._set_modified(False)
            self._add_recent(str(self.project_file))
            self.events.emit("project.saved", self.project_data(include_source=False), self.project_dir)
            self.statusBar().showMessage(f"Project saved: {self.project_dir}", 4000)
            return True
        except Exception as exc:
            QMessageBox.critical(self, "Save failed", f"Could not save the project folder.\n\n{exc}")
            return False

    def save_python_as(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save Python source", str((self.project_dir or Path.home()) / "main.py"), "Python files (*.py)")
        if path:
            Path(path).write_text(self.editor.toPlainText(), encoding="utf-8")
            self.statusBar().showMessage(f"Saved {path}", 4000)

    def export_zip(self):
        if not self.project_dir and not self.save_project():
            return
        self.save_project()
        path, _ = QFileDialog.getSaveFileName(self, "Export project as ZIP", str(self.project_dir.parent / f"{self.project_name}.zip"), "ZIP (*.zip)")
        if not path:
            return
        skip = {"build_output", ".venv", "__pycache__", "dist", "build"}
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in self.project_dir.rglob("*"):
                if f.is_file() and not (skip & set(f.relative_to(self.project_dir).parts)):
                    zf.write(f, Path(self.project_name) / f.relative_to(self.project_dir))
        self.statusBar().showMessage(f"Exported {path}", 4000)

    def _add_recent(self, path):
        s = self._settings()
        recent = [p for p in (s.value("recent", []) or []) if p != str(path)]
        if isinstance(recent, str):
            recent = [recent]
        recent.insert(0, str(path))
        s.setValue("recent", recent[:10])
        self._refresh_recent()

    def _refresh_recent(self):
        self.recent_menu.clear()
        recent = self._settings().value("recent", []) or []
        if isinstance(recent, str):
            recent = [recent]
        for p in recent:
            self.recent_menu.addAction(p, lambda path=p: self.open_project(path))
        self.recent_menu.setEnabled(bool(recent))
        if recent:
            self.recent_menu.addSeparator()
            self.recent_menu.addAction("Clear list", lambda: (self._settings().setValue("recent", []), self._refresh_recent()))

    # ================================================================== assets
    def _assets_dir(self) -> Path:
        base = self.project_dir or Path(tempfile.gettempdir()) / "WaterPyDesktopProjects" / self.project_name
        folder = base / "assets"
        folder.mkdir(parents=True, exist_ok=True)
        self.canvas.preview_context["project_dir"] = base
        return folder

    def import_asset(self) -> list[str]:
        files, _ = QFileDialog.getOpenFileNames(self, "Import project assets", "",
                                                "Images and media (*.png *.jpg *.jpeg *.gif *.bmp *.svg *.ico *.webp *.mp3 *.wav *.mp4 *.avi *.mkv);;All files (*.*)")
        imported = []
        folder = self._assets_dir()
        for file in files:
            src, dst = Path(file), folder / Path(file).name
            if src.resolve() != dst.resolve():
                if dst.exists():
                    dst = folder / f"{src.stem}_copy{src.suffix}"
                shutil.copy2(src, dst)
            imported.append(f"assets/{dst.name}")
        if files:
            self._refresh_assets()
            self.statusBar().showMessage(f"Imported {len(files)} asset(s)", 4000)
        return imported

    def _pick_asset(self, parent) -> str:
        folder = self._assets_dir()
        path, _ = QFileDialog.getOpenFileName(parent, "Choose asset", str(folder), "All files (*.*)")
        if not path:
            return ""
        src = Path(path)
        try:
            src.relative_to(folder)
            return f"assets/{src.relative_to(folder).as_posix()}"
        except ValueError:
            dst = folder / src.name
            if not dst.exists():
                shutil.copy2(src, dst)
            self._refresh_assets()
            return f"assets/{dst.name}"

    def _refresh_assets(self):
        self.asset_list.clear()
        folder = self._assets_dir()
        for path in sorted(folder.iterdir()):
            if path.is_file():
                self.asset_list.addItem(path.name)

    def _asset_activated(self, item):
        c = self.canvas.selected
        if c is None:
            return
        key = "image_path" if c.spec.property("image_path") else "source" if c.spec.property("source") else None
        if key:
            self._property_edited(key, f"assets/{item.text()}")
            self.props_grid.show_control(c, len(self.canvas.selection))

    def open_assets_folder(self):
        open_folder(self._assets_dir())

    # ============================================================ run & build
    def _source_path(self) -> Path:
        return (self.project_dir / "main.py") if self.project_dir else (Path(tempfile.gettempdir()) / "waterpy_desktop_main.py")

    def _python_launcher(self):
        """Return a real Python interpreter, even when this IDE is frozen as an EXE."""
        candidates = []
        if self.project_dir:
            candidates += [self.project_dir / ".venv" / "Scripts" / "python.exe", self.project_dir / ".venv" / "bin" / "python"]
        if not getattr(sys, "frozen", False):
            return sys.executable, []
        candidates.append(APP_DIR / ".venv" / "Scripts" / "python.exe")
        for c in candidates:
            if c.is_file():
                return str(c), []
        if shutil.which("python"):
            return shutil.which("python"), []
        if shutil.which("py"):
            return shutil.which("py"), ["-3.12"]
        raise RuntimeError("A Python interpreter was not found. Install 64-bit Python 3.12, or create a .venv in the project folder.")

    def _prepare_script(self) -> Path:
        self._flush_event_code()
        self._store_custom_methods()
        if not self.source_dirty:
            self.refresh_code(force=True)
        path = self._source_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self.editor.toPlainText(), encoding="utf-8")
        if self.project_dir is None:
            # make relative asset paths work for unsaved projects
            tmp_assets = path.parent / "assets"
            src_assets = self._assets_dir()
            if src_assets.resolve() != tmp_assets.resolve():
                shutil.copytree(src_assets, tmp_assets, dirs_exist_ok=True)
        return path

    def run_code(self):
        try:
            path = self._prepare_script()
            interpreter, prefix = self._python_launcher()
        except Exception as exc:
            QMessageBox.critical(self, "Run failed", str(exc))
            return
        try:
            compile(self.editor.toPlainText(), str(path), "exec")
        except SyntaxError as exc:
            self.console.clear()
            self.log(f"SyntaxError: {exc.msg} (line {exc.lineno})", "error")
            self._show_error_tools(exc.lineno or 0)
            return
        self.stop_process()
        self.events.emit("run.before", path)
        self.process_mode = "run"
        self.console.clear()
        self._show_error_tools(0)
        self.log(f"> {interpreter} {' '.join(prefix + ['-u', str(path)])}")
        self.process.setWorkingDirectory(str(path.parent))
        self.process.start(interpreter, prefix + ["-u", str(path)])
        self._process_started("Running…")

    def build_exe(self, then=None):
        """Build the app with PyInstaller using Project → Build Settings. ``then(exe_name, dist)`` runs on success."""
        try:
            path = self._prepare_script()
            interpreter, prefix = self._python_launcher()
        except Exception as exc:
            QMessageBox.critical(self, "Build failed", str(exc))
            return
        if self.process.state() != QProcess.ProcessState.NotRunning:
            QMessageBox.warning(self, "Busy", "Stop the running application or build first.")
            return
        base = self.project_dir or path.parent
        args, name, dist = inst.pyinstaller_args(self.build_settings, base, path, self.project_name)
        self.events.emit("build.before", args)
        args.append(str(path))
        self._last_build = (name, dist, base)
        self._after_build = then
        self.process_mode = "build"
        self.console.clear()
        self._show_error_tools(0)
        self.log("WaterPyDesktop EXE build", "success")
        mode = "single file" if self.build_settings.get("onefile") else "folder"
        self.log(f"Python: {interpreter}\nSource: {path}\nOutput ({mode}): {dist}\n")
        self.process.setWorkingDirectory(str(base))
        self.process.start(interpreter, prefix + args)
        self._process_started("Building EXE with PyInstaller…")

    def _process_started(self, text):
        self.a_stop.setEnabled(True)
        self.console_status.setText(text)
        self.console_dock.show()
        self.statusBar().showMessage(text)

    def stop_process(self):
        if self.process.state() != QProcess.ProcessState.NotRunning:
            self.process.kill()
            self.process.waitForFinished(1500)

    def _stdout(self):
        self.console.moveCursor(QTextCursor.MoveOperation.End)
        self.console.insertPlainText(bytes(self.process.readAllStandardOutput()).decode(errors="replace"))

    def _stderr(self):
        self.console.moveCursor(QTextCursor.MoveOperation.End)
        self.console.insertPlainText(bytes(self.process.readAllStandardError()).decode(errors="replace"))

    def _finished(self, code, status):
        self.a_stop.setEnabled(False)
        ok = code == 0
        label = {"run": "Application exited", "build": "Build finished", "installer": "Installer finished"}[self.process_mode]
        self.log(f"\n[{label}: exit code {code}]", "success" if ok else "error")
        self.console_status.setText(f"{label} — exit {code}")
        self.statusBar().showMessage(f"{label} (exit {code})", 5000)
        line = 0
        if not ok:
            script = self._source_path().name
            for m in re.finditer(r'File "([^"]+)", line (\d+)', self.console.toPlainText()):
                if Path(m.group(1)).name == script:
                    line = int(m.group(2))
        self._show_error_tools(line, show_ai=not ok and self.process_mode == "run")
        self.events.emit("process.finished", code, self.process_mode)
        if self.process_mode == "build":
            then, self._after_build = self._after_build, None
            if ok:
                name, dist, base = self._last_build
                self.log(f"EXE ready in {dist}", "success")
                if then:
                    QTimer.singleShot(0, lambda: then(name, dist))
        elif self.process_mode == "installer" and ok:
            self.log(f"Installer ready: {self._installer_output}", "success")
            if QMessageBox.question(self, "Installer created", f"setup.exe created:\n{self._installer_output}\n\nOpen the folder?") \
                    == QMessageBox.StandardButton.Yes:
                open_folder(Path(self._installer_output).parent)

    def _show_error_tools(self, line, show_ai=None):
        self.last_error_line = line
        self.goto_error_btn.setVisible(line > 0)
        self.goto_error_btn.setText(f"Go to line {line}")
        self.fix_ai_btn.setVisible(bool(line) if show_ai is None else show_ai)

    # ======================================================================== AI
    def ai_context(self) -> dict:
        self._flush_event_code()
        sel = self.canvas.selected
        return {"project": self.project_data(include_source=False), "source": self.editor.toPlainText(),
                "selected": sel.to_dict() if sel else None, "signal": self._event_signal if sel else "",
                "console": self.console.toPlainText()[-8000:]}

    def focus_ai(self, mode=None, prompt: str = "", send: bool = False):
        self.right_dock.show()
        self.right_tabs.setCurrentWidget(self.ai_panel)
        if mode:
            idx = self.ai_panel.mode.findData(mode)
            if idx >= 0:
                self.ai_panel.mode.setCurrentIndex(idx)
        if prompt:
            self.ai_panel.input.setPlainText(prompt)
        if send and prompt:
            self.ai_panel.send()
        else:
            self.ai_panel._quick_clicked("", mode or "chat")

    def apply_ai_source(self, code: str):
        if DiffDialog(self.editor.toPlainText(), code, parent=self).exec():
            self.set_source(code, user_edit=True)
            self.tabs.setCurrentIndex(1)
            self.statusBar().showMessage("AI changes applied to the source (designer regeneration paused)", 5000)

    # ================================================================= plugins
    def _load_plugins(self, initial=False, reload=False):
        loaded, errors = (self.plugins.reload_all(self) if reload else self.plugins.load_all(self))
        self.after_plugins_changed()
        if errors:
            for e in errors:
                self.log(f"Plugin problem — {e}", "error")
        if not initial or loaded:
            self.log(f"Plugins loaded: {', '.join(loaded) if loaded else 'none'}", "info")
        self.events.emit("plugins.loaded", [p.id for p in self.plugins.plugins.values() if p.status == "loaded"])

    def after_plugins_changed(self):
        self.plugin_list.clear()
        icons = {"loaded": "🟢", "disabled": "⚪", "error": "🔴", "incompatible": "🟠", "restart required": "🟠", "not loaded": "⚪"}
        for p in sorted(self.plugins.plugins.values(), key=lambda p: p.name.lower()):
            item = QListWidgetItem(f"{icons.get(p.status, '⚪')} {p.name}  {p.version}")
            item.setToolTip(f"{p.description}\n{p.status}{' — ' + p.error.splitlines()[0] if p.error else ''}")
            self.plugin_list.addItem(item)
        self.rebuild_export_menu()
        if self.canvas.controls_widgets():
            missing = [c.objectName() for c in self.canvas.controls_widgets() if REGISTRY.get(c.kind) is None]
            if missing:
                self.log(f"Controls using components from disabled plugins are skipped in code generation: {', '.join(missing)}", "warning")
        self._regen_timer.start()

    def show_plugin_manager(self):
        PluginManagerDialog(self).exec()

    def new_plugin(self):
        dlg = PluginManagerDialog(self)
        QTimer.singleShot(0, dlg.new_plugin)
        dlg.exec()

    def show_sdk_guide(self):
        MarkdownViewer("Plugin SDK Guide", APP_DIR / "PLUGIN_SDK.md", self).exec()

    def show_package_manager(self):
        try:
            interpreter, prefix = self._python_launcher()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Package manager", str(exc))
            return
        PackageManagerDialog(interpreter, prefix, self).exec()

    # ==================================================================== help
    def show_shortcuts(self):
        rows = [("New / Open / Save", "Ctrl+N / Ctrl+O / Ctrl+S"), ("Undo / Redo (designer)", "Ctrl+Z / Ctrl+Y"),
                ("Cut / Copy / Paste / Duplicate", "Ctrl+X / C / V / D"), ("Delete selection", "Del"),
                ("Select all", "Ctrl+A"), ("Multi-select", "Ctrl/Shift-click or drag a rectangle"),
                ("Nudge / nudge by grid / resize", "Arrows / Shift+Arrows / Alt+Arrows"), ("Rename", "F2"),
                ("Generate / Run / Stop / Build", "F7 / F5 / Shift+F5 / Ctrl+B"), ("Design ↔ Source", "F12"),
                ("AI form design", "Ctrl+Shift+A"), ("Send AI message", "Ctrl+Enter"),
                ("Comment line(s) in editor", "Ctrl+/"), ("Reload plugins", "Ctrl+Shift+R"), ("Preferences", "Ctrl+,")]
        QMessageBox.information(self, "Keyboard shortcuts", "<table>" + "".join(
            f"<tr><td style='padding-right:18px'>{a}</td><td><b>{b}</b></td></tr>" for a, b in rows) + "</table>")

    def show_about(self):
        QMessageBox.about(self, "About WaterPyDesktop",
                          f"<h3>WaterPyDesktop {__version__} — {__edition__}</h3>"
                          "<p>Visual PySide6 GUI builder, native Python code generator and PyInstaller front-end, "
                          "with an extensible plugin SDK and multi-provider AI assistant.</p>"
                          f"<p>{len(REGISTRY.kinds())} components · plugin API 2.0 · Python {sys.version.split()[0]}</p>")

    # ============================================================ tools (0.6)
    def _excepthook(self, etype, value, tb):
        """Show uncaught exceptions (e.g. from a live preview's handlers) in the Console instead of crashing."""
        import traceback
        self.log("".join(traceback.format_exception(etype, value, tb)).rstrip(), "error")
        self.console_status.setText(f"Unhandled {etype.__name__} — see Console")

    def _focused_code_editor(self):
        w = QApplication.focusWidget()
        return w if isinstance(w, CodeEditor) else (self.editor if self.tabs.currentIndex() == 1 else self.ev_code)

    def _snippet_menu(self, target, title="Insert snippet"):
        menu = QMenu(title, self)
        for category, items in SNIPPETS.items():
            sub = menu.addMenu(category)
            for label, code in items:
                sub.addAction(label, lambda c=code: self._insert_snippet(target(), c))
        return menu

    def _insert_snippet(self, editor, code):
        c = self.canvas.selected
        text = render_snippet(code, c.objectName() if c else None)
        cursor = editor.textCursor()
        line = cursor.block().text()
        indent = line[:len(line) - len(line.lstrip())] if not line.strip() else ""
        if editor is self.custom_methods and not line.strip():
            indent = "        "
        if editor is self.editor and not indent:
            indent = "        "
        lines = text.splitlines()
        text = "\n".join([lines[0]] + [indent + l if l else l for l in lines[1:]])
        if cursor.positionInBlock() == 0 and indent:
            text = indent + text
        cursor.insertText(text + ("\n" if not text.endswith("\n") else ""))
        editor.setFocus()
        if editor is self.ev_code and c is None:
            self.statusBar().showMessage("Tip: select a control first — '{control}' becomes self.<its name>", 5000)

    def open_find(self, replace=False):
        self.tabs.setCurrentIndex(1)
        self.find_bar.open(replace)

    def go_to_line(self):
        n, ok = QInputDialog.getInt(self, "Go to line", "Line number:", self.editor.textCursor().blockNumber() + 1,
                                    1, max(1, self.editor.blockCount()))
        if ok:
            self.tabs.setCurrentIndex(1)
            self.editor.go_to_line(n)

    def check_syntax(self) -> bool:
        src = self.editor.toPlainText()
        try:
            compile(src, "main.py", "exec")
        except SyntaxError as exc:
            self.log(f"SyntaxError: {exc.msg} (line {exc.lineno})", "error")
            self._show_error_tools(exc.lineno or 0, show_ai=True)
            self.statusBar().showMessage(f"Syntax error on line {exc.lineno}: {exc.msg}", 6000)
            return False
        self.statusBar().showMessage("✔ No syntax errors", 3000)
        return True

    def live_preview(self):
        """Instantiate the generated MainWindow inside the IDE (fast; no separate process)."""
        try:
            path = self._prepare_script()
        except Exception as exc:
            QMessageBox.critical(self, "Preview", str(exc))
            return
        if not self.check_syntax():
            return
        ns = {"__name__": "waterpy_preview", "__file__": str(path)}
        try:
            exec(compile(self.editor.toPlainText(), str(path), "exec"), ns)
            cls = ns.get("MainWindow")
            if cls is None:
                raise RuntimeError("The source does not define class MainWindow")
            win = cls()
        except Exception:
            import traceback
            self.log(traceback.format_exc().rstrip(), "error")
            self.console_dock.show()
            self.statusBar().showMessage("Preview failed — see Console", 5000)
            return
        win.setWindowTitle(win.windowTitle() + "   [Preview]")
        win.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        win.destroyed.connect(lambda *_, w=win: self._previews.remove(w) if w in self._previews else None)
        self._previews.append(win)
        win.show()
        win.raise_()
        self.statusBar().showMessage("Preview running inside the IDE — event handlers are live (F5 runs it as a separate program)", 6000)

    def edit_tab_order(self):
        dlg = TabOrderDialog(self.canvas.controls(), self.canvas.form_settings.get("tab_order") or [], self)
        if dlg.exec():
            self.canvas.apply_form_settings(tab_order=dlg.order())
            self.canvas.commit()
            self.statusBar().showMessage("Tab order updated", 3000)

    def show_build_settings(self):
        dlg = BuildSettingsDialog(self.build_settings, self._pick_asset, self)
        if dlg.exec():
            self.build_settings = dlg.values()
            self._set_modified(True)

    def open_build_folder(self):
        open_folder((self.project_dir or self._source_path().parent) / "build_output")

    def create_installer(self):
        compilers = {"Inno Setup": inst.find_inno(), "NSIS": inst.find_nsis()}
        dlg = InstallerDialog(self.installer_settings, compilers, self)
        if not dlg.exec():
            return
        self.installer_settings = dlg.values()
        self._set_modified(True)
        if dlg.rebuild.isChecked():
            self.build_exe(then=self._make_installer)
        else:
            base = self.project_dir or self._source_path().parent
            name = inst.safe_exe_name(self.build_settings.get("app_name") or self.project_name)
            self._make_installer(name, base / "build_output" / "dist")

    def _make_installer(self, exe_name: str, dist: Path):
        onefile, folder = dist / f"{exe_name}.exe", dist / exe_name
        if not onefile.is_file() and not (folder / f"{exe_name}.exe").is_file():
            QMessageBox.warning(self, "Installer", f"No built application found in {dist}.\nBuild the EXE first (Ctrl+B).")
            return
        base = dist.parent.parent
        out = dist.parent / "installer"
        out.mkdir(parents=True, exist_ok=True)
        build = dict(self.build_settings)
        build.setdefault("app_name", self.project_name)
        icon = base / build["icon"] if build.get("icon") else base / "app.ico"
        if icon.is_file() and icon.suffix.lower() == ".ico":
            build["icon_abs"] = str(icon)
        lic = self.installer_settings.get("license_file")
        if lic and not Path(lic).is_absolute():
            self.installer_settings["license_file"] = str(base / lic)
        choice = self.installer_settings.get("compiler", "auto")
        inno, nsis = inst.find_inno(), inst.find_nsis()
        use = "inno" if (choice in ("auto", "inno") and inno) else "nsis" if (choice in ("auto", "nsis") and nsis) else None
        iss = out / f"{exe_name}.iss"
        nsi = out / f"{exe_name}.nsi"
        iss.write_text(inst.inno_script(build, self.installer_settings, dist, exe_name, out), encoding="utf-8")
        nsi.write_text(inst.nsis_script(build, self.installer_settings, dist, exe_name, out), encoding="utf-8")
        version = build.get("version") or "1.0.0"
        self._installer_output = str(out / f"{exe_name}-{version}-setup.exe")
        if use is None:
            self.log(f"Installer scripts written:\n  {iss}\n  {nsi}", "warning")
            QMessageBox.information(self, "Installer scripts ready",
                                    "No installer compiler was found on this PC.\n\nInstall Inno Setup 6 (jrsoftware.org/isinfo.php) "
                                    f"or NSIS 3, then run Create Installer again — or compile this script yourself:\n\n{iss}")
            open_folder(out)
            return
        program, args = (inno, [str(iss)]) if use == "inno" else (nsis, [str(nsi)])
        self.process_mode = "installer"
        self.log(f"\nCreating setup.exe with {'Inno Setup' if use == 'inno' else 'NSIS'}…", "success")
        self.process.setWorkingDirectory(str(out))
        self.process.start(program, args)
        self._process_started("Creating installer…")

    # ---- import ------------------------------------------------------------------
    def import_ui_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import Qt Designer form", "", "Qt Designer (*.ui)")
        if not path:
            return
        try:
            layout, warnings = io_formats.import_ui(path)
        except Exception as exc:
            QMessageBox.critical(self, "Import failed", f"Could not read the .ui file.\n\n{exc}")
            return
        for w in warnings:
            self.log(f"Import: {w}", "warning")
        self.apply_layout(layout, confirm=True)
        self.log(f"Imported {len(layout['controls'])} controls from {Path(path).name}", "success")

    def import_layout_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import WaterPy layout", "", "WaterPy layout / project (*.json)")
        if not path:
            return
        try:
            self.apply_layout(io_formats.import_layout(path), confirm=True)
        except Exception as exc:
            QMessageBox.critical(self, "Import failed", str(exc))

    def import_project_zip(self):
        if not self._confirm_discard():
            return
        path, _ = QFileDialog.getOpenFileName(self, "Import project ZIP", "", "ZIP (*.zip)")
        if not path:
            return
        dest = QFileDialog.getExistingDirectory(self, "Extract the project into…", str(Path(path).parent))
        if not dest:
            return
        try:
            with zipfile.ZipFile(path) as zf:
                for n in zf.namelist():
                    if Path(n).is_absolute() or ".." in Path(n).parts:
                        raise ValueError(f"Unsafe path in archive: {n}")
                zf.extractall(dest)
                projects = [n for n in zf.namelist() if n.endswith(".waterpy.json")]
        except Exception as exc:
            QMessageBox.critical(self, "Import failed", str(exc))
            return
        if not projects:
            QMessageBox.warning(self, "Import", "The ZIP was extracted but contains no .waterpy.json project.")
            return
        self.modified = False
        self.open_project(str(Path(dest) / sorted(projects, key=len)[0]))

    def _selected_with(self, key, label):
        c = self.canvas.selected
        if c is None or c.spec.property(key) is None:
            QMessageBox.information(self, "Import", f"Select a {label} on the form first.")
            return None
        return c

    def import_csv_grid(self):
        c = self._selected_with("data", "Grid")
        if not c:
            return
        path, _ = QFileDialog.getOpenFileName(self, "Import CSV into grid", "", "CSV / text (*.csv *.tsv *.txt)")
        if not path:
            return
        try:
            rows = io_formats.read_csv(path)
        except Exception as exc:
            QMessageBox.critical(self, "Import failed", str(exc))
            return
        if not rows:
            QMessageBox.warning(self, "Import", "The file contains no rows.")
            return
        header = QMessageBox.question(self, "CSV header", "Use the first row as column headers?") == QMessageBox.StandardButton.Yes
        headers, data = (rows[0], rows[1:]) if header else ([f"Column {i + 1}" for i in range(len(rows[0]))], rows)
        c.set_props(headers=headers, columns=max(len(r) for r in rows), rows=len(data), data=io_formats.rows_to_csv_text(data))
        self.props_grid.show_control(c, len(self.canvas.selection))
        self.canvas.changed.emit()
        self.canvas.commit()
        self.log(f"Imported {len(data)} rows × {len(headers)} columns into {c.objectName()}", "success")

    def import_items(self):
        c = self._selected_with("items", "List Box or Combo Box")
        if not c:
            return
        path, _ = QFileDialog.getOpenFileName(self, "Import items", "", "Text / CSV (*.txt *.csv)")
        if not path:
            return
        rows = io_formats.read_csv(path) if path.lower().endswith(".csv") else \
            [[l] for l in Path(path).read_text(encoding="utf-8", errors="replace").splitlines() if l.strip()]
        c.set_props(items=[r[0] for r in rows if r])
        self.props_grid.show_control(c, len(self.canvas.selection))
        self.canvas.changed.emit()
        self.canvas.commit()
        self.log(f"Imported {len(rows)} items into {c.objectName()}", "success")

    # ---- export ------------------------------------------------------------------
    def _export_path(self, title, default_name, file_filter):
        path, _ = QFileDialog.getSaveFileName(self, title, str((self.project_dir or Path.home()) / default_name), file_filter)
        return Path(path) if path else None

    def export_layout_file(self):
        path = self._export_path("Export layout", f"{self.project_name}.wplayout.json", "WaterPy layout (*.json)")
        if path:
            io_formats.export_layout(self.project_data(include_source=False), path)
            self.statusBar().showMessage(f"Layout exported: {path}", 4000)

    def export_html_mockup(self):
        path = self._export_path("Export HTML mockup", f"{self.project_name}-mockup.html", "HTML (*.html)")
        if path:
            io_formats.export_html(self.project_data(include_source=False), path)
            self.statusBar().showMessage(f"HTML mockup exported: {path}", 4000)

    def export_docs(self):
        path = self._export_path("Export documentation", f"{self.project_name}-form.md", "Markdown (*.md);;HTML (*.html)")
        if path:
            io_formats.export_documentation(self.project_data(), path)
            self.statusBar().showMessage(f"Documentation exported: {path}", 4000)

    def export_pyqt6(self):
        path = self._export_path("Export PyQt6 source", "main_pyqt6.py", "Python (*.py)")
        if path:
            path.write_text(io_formats.to_pyqt6(self.editor.toPlainText()), encoding="utf-8")
            self.log(f"PyQt6 source exported to {path} (pip install PyQt6 to run it)", "success")

    def render_form_pixmap(self):
        sel, grid = list(self.canvas.selection), self.canvas.show_grid
        self.canvas.set_selection([])
        self.canvas.show_grid = False
        self.canvas.repaint()
        pixmap = self.canvas.grab()
        self.canvas.show_grid = grid
        self.canvas.set_selection(sel)
        self.canvas.update()
        return pixmap

    def export_form_image(self, kind="png"):
        path = self._export_path("Export form image", f"{self.project_name}.{kind}", "PNG image (*.png)" if kind == "png" else "PDF (*.pdf)")
        if not path:
            return
        pixmap = self.render_form_pixmap()
        if kind == "png":
            pixmap.save(str(path), "PNG")
        else:
            from PySide6.QtCore import QMarginsF, QSizeF
            from PySide6.QtGui import QPageLayout, QPageSize, QPdfWriter
            writer = QPdfWriter(str(path))
            writer.setResolution(96)
            writer.setPageSize(QPageSize(QSizeF(pixmap.width() * 0.75, pixmap.height() * 0.75), QPageSize.Unit.Point))
            writer.setPageMargins(QMarginsF(0, 0, 0, 0), QPageLayout.Unit.Point)
            writer.setTitle(self.canvas.form_settings.get("title") or self.project_name)
            painter = QPainter(writer)
            painter.drawPixmap(0, 0, pixmap)
            painter.end()
        self.statusBar().showMessage(f"Form image exported: {path}", 4000)

    def save_as_template(self):
        if not self.canvas.controls_widgets():
            QMessageBox.information(self, "Template", "The form is empty.")
            return
        name, ok = QInputDialog.getText(self, "Save as template", "Template name:", text=self.canvas.form_settings.get("title") or self.project_name)
        if not ok or not name.strip():
            return
        desc, _ = QInputDialog.getText(self, "Save as template", "Short description:")
        folder = self.user_dir / "templates"
        folder.mkdir(parents=True, exist_ok=True)
        data = self.project_data(include_source=False)
        payload = {"format": io_formats.LAYOUT_FORMAT, "name": name.strip(), "description": desc.strip(),
                   "form": data["form"], "controls": data["controls"], "custom_methods": data["custom_methods"]}
        safe = re.sub(r"[^\w-]+", "_", name.strip())
        (folder / f"{safe}.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        self._load_user_templates()
        self.statusBar().showMessage(f"Template saved: {name}", 4000)

    def _load_user_templates(self):
        from .registry import FormTemplate
        folder = self.user_dir / "templates"
        if not folder.is_dir():
            return
        for f in sorted(folder.glob("*.json")):
            try:
                d = json.loads(f.read_text(encoding="utf-8"))
                REGISTRY.register_template(FormTemplate(d.get("name") or f.stem, d.get("description", ""), d.get("controls", []),
                                                        d.get("custom_methods", ""), d.get("form", {}), "My templates"), source="user")
            except Exception as exc:
                self.log(f"Template {f.name} could not be loaded: {exc}", "warning")

    def closeEvent(self, event):
        if not self._confirm_discard():
            event.ignore()
            return
        self.save_settings()
        sys.excepthook = self._orig_excepthook
        for w in list(self._previews):
            w.close()
        self.ai_panel.shutdown()
        self.stop_process()
        event.accept()
