"""WaterPyDesktop: a visual IDE for Python and PySide6."""
__version__ = "0.6.0"
__edition__ = "Professional"
