"""Visual form designer: component palette, design canvas, selection and history."""
from __future__ import annotations

import copy
import importlib
import json
from collections.abc import Mapping

from PySide6.QtCore import QMimeData, QPoint, QRect, QSize, Qt, Signal
from PySide6.QtGui import QAction, QColor, QDrag, QFont, QIcon, QKeySequence, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (QApplication, QLabel, QListWidget, QListWidgetItem, QMenu, QRubberBand,
                               QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from .codegen import DEFAULT_FORM, safe_name
from .registry import CATEGORY_COLORS, REGISTRY, SPECIAL_KEYS, ComponentSpec, eval_expr, snake, valid_color

MIME_KIND = "application/x-waterpy-widget"
MIME_CONTROLS = "application/x-waterpy-controls"


class _WidgetsView(Mapping):
    """Backward-compatible ``WIDGETS`` mapping (kind -> Qt class name) backed by the registry."""
    def __getitem__(self, kind):
        spec = REGISTRY.get(kind)
        if spec is None:
            raise KeyError(kind)
        return spec.qt_class

    def __iter__(self):
        return iter(REGISTRY.kinds())

    def __len__(self):
        return len(REGISTRY.kinds())

    def __contains__(self, kind):
        return kind in REGISTRY


WIDGETS = _WidgetsView()
_ICON_CACHE: dict[tuple, QIcon] = {}


def make_icon(spec: ComponentSpec, size: int = 28) -> QIcon:
    """Category-coloured glyph tile used throughout the palette."""
    if spec.icon:
        return spec.icon if isinstance(spec.icon, QIcon) else QIcon(str(spec.icon))
    key = (spec.glyph, spec.category, size)
    if key in _ICON_CACHE:
        return _ICON_CACHE[key]
    pm = QPixmap(size * 2, size * 2)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
    color = QColor(CATEGORY_COLORS.get(spec.category, CATEGORY_COLORS["Plugins"]))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(color)
    p.drawRoundedRect(QRect(2, 2, size * 2 - 4, size * 2 - 4), 12, 12)
    font = QFont("Segoe UI", 1)
    font.setPixelSize(int(size * (0.92 if len(spec.glyph) <= 2 else 0.66)))
    font.setBold(True)
    p.setFont(font)
    p.setPen(QColor("white"))
    p.drawText(QRect(0, 0, size * 2, size * 2), Qt.AlignmentFlag.AlignCenter, spec.glyph)
    p.end()
    icon = QIcon(pm)
    _ICON_CACHE[key] = icon
    return icon


# ---------------------------------------------------------------------------
# Palette
# ---------------------------------------------------------------------------
class ComponentPalette(QTreeWidget):
    """Categorised, searchable toolbox.  Drag a tool onto the form or double-click it."""
    insertRequested = Signal(str)

    def __init__(self, registry=REGISTRY, parent=None):
        super().__init__(parent)
        self.registry = registry
        self.setHeaderHidden(True)
        self.setIndentation(10)
        self.setIconSize(QSize(22, 22))
        self.setDragEnabled(True)
        self.setDragDropMode(QTreeWidget.DragDropMode.DragOnly)
        self.setRootIsDecorated(True)
        self.setAnimated(True)
        self.setUniformRowHeights(True)
        self.setObjectName("componentPalette")
        self.itemDoubleClicked.connect(self._double_clicked)
        self._filter = ""
        registry.add_listener(self.rebuild)
        self.rebuild()

    def rebuild(self):
        expanded = {self.topLevelItem(i).text(0): self.topLevelItem(i).isExpanded() for i in range(self.topLevelItemCount())}
        self.clear()
        bold = QFont()
        bold.setBold(True)
        for category, specs in self.registry.by_category():
            top = QTreeWidgetItem([f"{category}  ({len(specs)})"])
            top.setData(0, Qt.ItemDataRole.UserRole + 1, category)
            top.setFont(0, bold)
            top.setFlags(Qt.ItemFlag.ItemIsEnabled)
            self.addTopLevelItem(top)
            for spec in specs:
                item = QTreeWidgetItem([spec.kind])
                item.setIcon(0, make_icon(spec))
                item.setData(0, Qt.ItemDataRole.UserRole, spec.kind)
                origin = "" if spec.source == "builtin" else f"\nProvided by plugin: {spec.source}"
                item.setToolTip(0, f"<b>{spec.kind}</b> — {spec.qt_class}<br>{spec.description}{origin}<br><i>Drag onto the form or double-click</i>")
                top.addChild(item)
            top.setExpanded(expanded.get(top.text(0), True))
        self.apply_filter(self._filter)

    def apply_filter(self, text: str):
        self._filter = needle = (text or "").strip().lower()
        for i in range(self.topLevelItemCount()):
            top = self.topLevelItem(i)
            visible = 0
            for j in range(top.childCount()):
                child = top.child(j)
                spec = self.registry.get(child.data(0, Qt.ItemDataRole.UserRole))
                hay = f"{spec.kind} {spec.qt_class} {spec.description} {spec.category}".lower() if spec else ""
                hide = bool(needle) and needle not in hay
                child.setHidden(hide)
                visible += not hide
            top.setHidden(visible == 0)
            if needle:
                top.setExpanded(True)

    def _double_clicked(self, item, column):
        kind = item.data(0, Qt.ItemDataRole.UserRole)
        if kind:
            self.insertRequested.emit(kind)

    def startDrag(self, actions):
        item = self.currentItem()
        kind = item.data(0, Qt.ItemDataRole.UserRole) if item else None
        if not kind:
            return
        mime = QMimeData()
        mime.setText(kind)
        mime.setData(MIME_KIND, kind.encode("utf-8"))
        drag = QDrag(self)
        drag.setMimeData(mime)
        spec = self.registry.get(kind)
        if spec:
            drag.setPixmap(make_icon(spec).pixmap(32, 32))
        drag.setHotSpot(QPoint(12, 12))
        drag.exec(Qt.DropAction.CopyAction)


class ToolboxList(QListWidget):
    """Legacy flat palette (kept for plugins written against v0.4)."""
    def add_widget_kind(self, kind):
        spec = REGISTRY.get(kind)
        item = QListWidgetItem(make_icon(spec) if spec else QIcon(), kind)
        item.setData(Qt.ItemDataRole.UserRole, kind)
        self.addItem(item)

    def kind_for_item(self, item):
        return item.data(Qt.ItemDataRole.UserRole) if item else None


# ---------------------------------------------------------------------------
# Controls on the canvas
# ---------------------------------------------------------------------------
def _transparent(widget: QWidget):
    widget.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
    widget.setFocusPolicy(Qt.FocusPolicy.NoFocus)
    for child in widget.findChildren(QWidget):
        child.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        child.setFocusPolicy(Qt.FocusPolicy.NoFocus)


class DesignerControl(QWidget):
    """A design-time wrapper around a real Qt widget preview."""
    HANDLE = 8

    def __init__(self, kind, data, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.spec: ComponentSpec = REGISTRY.get(kind)
        self.kind = self.spec.kind
        raw = dict(data or {})
        raw["type"] = self.kind
        self.props = REGISTRY.normalize(raw)
        self.setObjectName(self.props["name"] or "control")
        self.inner = self._make_inner()
        self.apply_properties()
        self.show()

    # -- preview ---------------------------------------------------------
    def _make_inner(self) -> QWidget:
        spec = self.spec
        try:
            if spec.preview_factory:
                widget = spec.preview_factory(self)
            else:
                cls = getattr(importlib.import_module(spec.module), spec.qt_class)
                widget = cls(self)
        except Exception:
            widget = QLabel(f"{spec.glyph} {spec.kind}", self)
            widget.setAlignment(Qt.AlignmentFlag.AlignCenter)
        if spec.non_visual and isinstance(widget, QLabel):
            widget.setText(f"{spec.glyph} {self.props.get('name') or spec.kind}")
        return widget

    def apply_properties(self):
        p, spec = self.props, self.spec
        self.setObjectName(str(p.get("name") or "control"))
        if spec.non_visual:
            w, h = spec.default_size
        else:
            w = max(spec.min_size[0], int(p.get("width", spec.default_size[0])))
            h = max(spec.min_size[1], int(p.get("height", spec.default_size[1])))
        self.setGeometry(int(p.get("x", 0)), int(p.get("y", 0)), w, h)
        self.inner.setGeometry(0, 0, w, h)
        if not spec.preview_factory:
            for prop in spec.all_properties():
                if not prop.setter or not prop.preview or prop.key in SPECIAL_KEYS:
                    continue
                value = p.get(prop.key, prop.default)
                try:
                    if prop.setter == "addItems":
                        self.inner.clear()
                    getattr(self.inner, prop.setter)(eval_expr(prop.expr(value)))
                except Exception:
                    pass
        if spec.preview_update:
            try:
                spec.preview_update(self.inner, p, self.canvas.preview_context)
            except Exception:
                pass
        if spec.non_visual and isinstance(self.inner, QLabel):
            self.inner.setText(f"{spec.glyph} {p.get('name') or spec.kind}")
        else:
            font = QFont(self.inner.font())
            if p.get("font_family"):
                font.setFamily(str(p["font_family"]))
            if int(p.get("font_size") or 0) > 0:
                font.setPointSize(int(p["font_size"]))
            font.setBold(bool(p.get("bold")))
            font.setItalic(bool(p.get("italic")))
            self.inner.setFont(font)
            css = spec.css(p, design=True)
            if css or not spec.preview_factory:
                self.inner.setStyleSheet(css)
        _transparent(self.inner)
        self.setToolTip(f"{p.get('name')} · {spec.kind}")
        self.update()

    def set_props(self, **values):
        for key, value in values.items():
            prop = self.spec.property(key)
            self.props[key] = prop.coerce(value) if prop else value
        self.apply_properties()

    # -- geometry helpers ------------------------------------------------------
    def sync_geometry(self):
        self.props.update(x=self.x(), y=self.y())
        if not self.spec.non_visual:
            self.props.update(width=self.width(), height=self.height())
        self.inner.setGeometry(0, 0, self.width(), self.height())

    def in_resize_handle(self, pos: QPoint) -> bool:
        return (not self.spec.non_visual and pos.x() >= self.width() - self.HANDLE - 2
                and pos.y() >= self.height() - self.HANDLE - 2)

    # -- events (inner widget is transparent, so all mouse input lands here)
    def mousePressEvent(self, event):
        self.canvas._control_pressed(self, event)

    def mouseMoveEvent(self, event):
        if not event.buttons():
            self.setCursor(Qt.CursorShape.SizeFDiagCursor if self.in_resize_handle(event.position().toPoint())
                           and self in self.canvas.selection else Qt.CursorShape.ArrowCursor)
        self.canvas._control_moved(self, event)

    def mouseReleaseEvent(self, event):
        self.canvas._control_released(self, event)

    def mouseDoubleClickEvent(self, event):
        self.canvas.editEventsRequested.emit(self)

    def contextMenuEvent(self, event):
        self.canvas._show_context_menu(event.globalPos(), self)

    def dragEnterEvent(self, event):
        self.canvas.dragEnterEvent(event)

    def dragMoveEvent(self, event):
        self.canvas.dragMoveEvent(event)

    def dropEvent(self, event):
        self.canvas._drop_at(event, self.mapToParent(event.position().toPoint()))

    def paintEvent(self, event):
        super().paintEvent(event)
        if self not in self.canvas.selection:
            return
        p = QPainter(self)
        primary = self.canvas.selected is self
        color = QColor("#1677ff" if primary else "#60a5fa")
        p.setPen(QPen(color, 2 if primary else 1, Qt.PenStyle.DashLine))
        p.drawRect(self.rect().adjusted(1, 1, -2, -2))
        if primary and not self.spec.non_visual:
            p.fillRect(self.width() - self.HANDLE, self.height() - self.HANDLE, self.HANDLE, self.HANDLE, color)
        p.end()

    def to_dict(self) -> dict:
        self.sync_geometry()
        d = copy.deepcopy(self.props)
        d.update(type=self.kind, name=self.objectName())
        return d


# ---------------------------------------------------------------------------
# Undo / redo
# ---------------------------------------------------------------------------
class History:
    def __init__(self, limit: int = 200):
        self.limit, self.states, self.index = limit, [], -1

    def reset(self, state: str):
        self.states, self.index = [state], 0

    def push(self, state: str) -> bool:
        if self.index >= 0 and self.states[self.index] == state:
            return False
        del self.states[self.index + 1:]
        self.states.append(state)
        if len(self.states) > self.limit:
            self.states.pop(0)
        self.index = len(self.states) - 1
        return True

    def can_undo(self):
        return self.index > 0

    def can_redo(self):
        return 0 <= self.index < len(self.states) - 1

    def undo(self):
        if self.can_undo():
            self.index -= 1
            return self.states[self.index]

    def redo(self):
        if self.can_redo():
            self.index += 1
            return self.states[self.index]


# ---------------------------------------------------------------------------
# Canvas
# ---------------------------------------------------------------------------
class DesignCanvas(QWidget):
    changed = Signal()                 # any edit (also fired continuously while dragging)
    selectionChanged = Signal(object)  # primary selected control or None
    historyChanged = Signal()
    controlAdded = Signal(object)
    editEventsRequested = Signal(object)
    formChanged = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setObjectName("designCanvas")
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setAutoFillBackground(True)
        self.grid_size, self.snap_to_grid, self.show_grid = 10, True, True
        self.selection: list[DesignerControl] = []
        self._primary: DesignerControl | None = None
        self._count = 0
        self._drag = None
        self._band = QRubberBand(QRubberBand.Shape.Rectangle, self)
        self._band_origin = None
        self.preview_context: dict = {}
        self.form_settings = dict(DEFAULT_FORM)
        self.history = History()
        self._restoring = False
        self.context_actions: list[QAction] = []   # extra actions added by the host / plugins
        self.apply_form_settings()
        self.reset_history()

    # -- compatibility --------------------------------------------------------
    @property
    def selected(self):
        return self._primary

    @selected.setter
    def selected(self, control):
        self.select_control(control)

    # -- form ------------------------------------------------------------------
    def apply_form_settings(self, **values):
        self.form_settings.update(values)
        f = self.form_settings
        self.setFixedSize(max(200, int(f.get("width", 900))), max(150, int(f.get("height", 600))))
        self._apply_palette()
        self.update()
        if values:
            self.formChanged.emit()
            self.changed.emit()

    def set_base_palette(self, palette):
        """Palette used for previews (kept light so the canvas is WYSIWYG whatever the IDE theme).

        Note: no style sheet may be set on the canvas or its ancestors, otherwise Qt stops
        propagating this palette to the preview widgets."""
        self._base_palette = palette
        self._apply_palette()

    def _apply_palette(self):
        from PySide6.QtGui import QPalette
        base = getattr(self, "_base_palette", None)
        pal = QPalette(base) if base is not None else QPalette(self.palette())
        pal.setColor(QPalette.ColorRole.Window, QColor(valid_color(self.form_settings.get("background")) or "#ffffff"))
        self.setPalette(pal)

    # -- painting -------------------------------------------------------------
    def paintEvent(self, event):
        super().paintEvent(event)
        if not self.show_grid:
            return
        painter = QPainter(self)
        step = max(4, int(self.grid_size))
        painter.setPen(QPen(QColor(0, 0, 0, 18), 1))
        for x in range(0, self.width(), step):
            painter.drawLine(x, 0, x, self.height())
        for y in range(0, self.height(), step):
            painter.drawLine(0, y, self.width(), y)
        painter.setPen(QPen(QColor(0, 0, 0, 34), 1))
        for x in range(0, self.width(), step * 5):
            painter.drawLine(x, 0, x, self.height())
        for y in range(0, self.height(), step * 5):
            painter.drawLine(0, y, self.width(), y)
        painter.end()

    def snap(self, value):
        if not self.snap_to_grid:
            return int(value)
        step = max(1, int(self.grid_size))
        return max(0, round(int(value) / step) * step)

    # -- drag & drop from the palette --------------------------------------
    @staticmethod
    def _kind_from_mime(mime):
        if mime.hasFormat(MIME_KIND):
            return bytes(mime.data(MIME_KIND)).decode("utf-8")
        if mime.hasText() and mime.text() in REGISTRY:
            return mime.text()
        return None

    def dragEnterEvent(self, event):
        if self._kind_from_mime(event.mimeData()):
            event.acceptProposedAction()

    def dragMoveEvent(self, event):
        if self._kind_from_mime(event.mimeData()):
            event.acceptProposedAction()

    def dropEvent(self, event):
        self._drop_at(event, event.position().toPoint())

    def _drop_at(self, event, pos):
        kind = self._kind_from_mime(event.mimeData())
        if kind:
            self.add_control(kind, QPoint(self.snap(pos.x()), self.snap(pos.y())))
            event.acceptProposedAction()
            self.setFocus()

    # -- control management ---------------------------------------------------
    def unique_name(self, base: str, exclude=None) -> str:
        base = safe_name(base, "control")
        names = {c.objectName() for c in self.controls_widgets() if c is not exclude}
        if base not in names:
            return base
        stem = base.rstrip("0123456789").rstrip("_") or base
        i = 1
        while f"{stem}_{i}" in names:
            i += 1
        return f"{stem}_{i}"

    def add_control(self, kind, pos=None, data=None, select=True, record=True):
        kind = REGISTRY.resolve_kind(kind)
        spec = REGISTRY.get(kind)
        if spec is None:
            return None
        self._count += 1
        data = dict(data or {})
        if not data.get("name"):
            data["name"] = self.unique_name(snake(kind.replace(" ", "")))
        else:
            data["name"] = self.unique_name(data["name"])
        data.setdefault("x", max(0, pos.x()) if pos is not None else self.snap(20 + (self._count - 1) % 12 * 16))
        data.setdefault("y", max(0, pos.y()) if pos is not None else self.snap(20 + (self._count - 1) % 12 * 16))
        control = DesignerControl(kind, data, self)
        if select:
            self.set_selection([control])
        self.controlAdded.emit(control)
        self.changed.emit()
        if record:
            self.commit()
        return control

    def delete_control(self, control):
        self.delete_controls([control] if control else [])

    def delete_controls(self, controls):
        controls = [c for c in controls if c is not None]
        if not controls:
            return
        for c in controls:
            if c in self.selection:
                self.selection.remove(c)
            c.setParent(None)
            c.deleteLater()
        self._primary = self.selection[-1] if self.selection else None
        self.selectionChanged.emit(self._primary)
        self.changed.emit()
        self.commit()
        self.update()

    def delete_selection(self):
        self.delete_controls(list(self.selection))

    def controls_widgets(self) -> list[DesignerControl]:
        return [c for c in self.children() if isinstance(c, DesignerControl)]

    def controls(self) -> list[dict]:
        return [c.to_dict() for c in self.controls_widgets()]

    def find(self, name: str) -> DesignerControl | None:
        return next((c for c in self.controls_widgets() if c.objectName() == name), None)

    def clear_controls(self, record=True):
        for c in self.controls_widgets():
            c.setParent(None)
            c.deleteLater()
        self.selection, self._primary, self._count = [], None, 0
        self.selectionChanged.emit(None)
        self.changed.emit()
        if record:
            self.commit()

    def load_controls(self, controls, form=None, reset_history=True):
        self._restoring = True
        try:
            self.clear_controls(record=False)
            if form is not None:
                self.form_settings = {**DEFAULT_FORM, **form}
                self.apply_form_settings()
            for d in controls or []:
                kind = REGISTRY.resolve_kind(d.get("type", "Label"))
                if kind in REGISTRY:
                    self.add_control(kind, data=dict(d), select=False, record=False)
        finally:
            self._restoring = False
        self.selectionChanged.emit(None)
        self.changed.emit()
        if reset_history:
            self.reset_history()
        else:
            self.commit()

    # -- selection ----------------------------------------------------------
    def select_control(self, control):
        self.set_selection([control] if control else [])

    def set_selection(self, controls, primary=None):
        old = list(self.selection)
        self.selection = [c for c in controls if c is not None]
        self._primary = primary if primary in self.selection else (self.selection[-1] if self.selection else None)
        for c in set(old) | set(self.selection):
            c.update()
        self.selectionChanged.emit(self._primary)

    def select_all(self):
        self.set_selection(self.controls_widgets())

    def _control_pressed(self, control, event):
        self.setFocus()
        mods = event.modifiers()
        if event.button() == Qt.MouseButton.RightButton:
            if control not in self.selection:
                self.set_selection([control])
            return
        if mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier):
            sel = list(self.selection)
            if control in sel:
                sel.remove(control)
            else:
                sel.append(control)
            self.set_selection(sel, control if control in sel else None)
            return
        if control not in self.selection:
            self.set_selection([control])
        elif self._primary is not control:
            self.set_selection(self.selection, control)
        local = event.position().toPoint()
        self._drag = {
            "start": event.globalPosition().toPoint(),
            "resize": control.in_resize_handle(local),
            "control": control,
            "origins": {c: c.pos() for c in self.selection},
            "size": control.size(),
            "moved": False,
        }

    def _control_moved(self, control, event):
        d = self._drag
        if not d or not (event.buttons() & Qt.MouseButton.LeftButton):
            return
        delta = event.globalPosition().toPoint() - d["start"]
        if not d["moved"] and delta.manhattanLength() < 3:
            return
        d["moved"] = True
        main = d["control"]
        if d["resize"]:
            mw, mh = main.spec.min_size
            main.resize(max(mw, self.snap(d["size"].width() + delta.x())), max(mh, self.snap(d["size"].height() + delta.y())))
            main.sync_geometry()
        else:
            origin = d["origins"][main]
            nx, ny = self.snap(origin.x() + delta.x()), self.snap(origin.y() + delta.y())
            dx, dy = nx - origin.x(), ny - origin.y()
            for c, o in d["origins"].items():
                c.move(max(0, o.x() + dx), max(0, o.y() + dy))
                c.sync_geometry()
        self.changed.emit()

    def _control_released(self, control, event):
        if self._drag and self._drag["moved"]:
            self.commit()
            self.selectionChanged.emit(self._primary)
        self._drag = None

    def mousePressEvent(self, event):
        self.setFocus()
        if event.button() == Qt.MouseButton.LeftButton:
            if not (event.modifiers() & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier)):
                self.set_selection([])
            self._band_origin = event.position().toPoint()
            self._band.setGeometry(QRect(self._band_origin, QSize()))
            self._band.show()

    def mouseMoveEvent(self, event):
        if self._band_origin is not None:
            self._band.setGeometry(QRect(self._band_origin, event.position().toPoint()).normalized())

    def mouseReleaseEvent(self, event):
        if self._band_origin is not None:
            rect = self._band.geometry()
            self._band.hide()
            self._band_origin = None
            if rect.width() > 3 or rect.height() > 3:
                hits = [c for c in self.controls_widgets() if rect.intersects(c.geometry())]
                keep = self.selection if event.modifiers() & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier) else []
                self.set_selection(keep + [h for h in hits if h not in keep])

    def contextMenuEvent(self, event):
        self._show_context_menu(event.globalPos(), None)

    def _show_context_menu(self, global_pos, control):
        menu = QMenu(self)
        has = bool(self.selection)
        def add(text, slot, enabled=True, shortcut=None):
            a = menu.addAction(text)
            a.setEnabled(enabled)
            if shortcut:
                a.setShortcut(QKeySequence(shortcut))
            a.triggered.connect(slot)
            return a
        if control is not None:
            add("Edit events…", lambda: self.editEventsRequested.emit(control))
            menu.addSeparator()
        add("Cut", self.cut_selection, has, "Ctrl+X")
        add("Copy", self.copy_selection, has, "Ctrl+C")
        add("Paste", self.paste, self.can_paste(), "Ctrl+V")
        add("Duplicate", self.duplicate_selection, has, "Ctrl+D")
        add("Delete", self.delete_selection, has, "Del")
        menu.addSeparator()
        add("Bring to front", self.bring_to_front, has)
        add("Send to back", self.send_to_back, has)
        align = menu.addMenu("Align && size")
        for label, mode in ALIGN_ACTIONS:
            if label == "-":
                align.addSeparator()
                continue
            a = align.addAction(label)
            a.setEnabled(len(self.selection) >= (3 if mode.startswith("distribute") else 1 if mode.startswith("center_form") else 2))
            a.triggered.connect(lambda checked=False, m=mode: self.align(m))
        menu.addSeparator()
        add("Select all", self.select_all, bool(self.controls_widgets()), "Ctrl+A")
        if self.context_actions:
            menu.addSeparator()
            for action in self.context_actions:
                menu.addAction(action)
        menu.exec(global_pos)

    def keyPressEvent(self, event):
        key, mods = event.key(), event.modifiers()
        arrows = {Qt.Key.Key_Left: (-1, 0), Qt.Key.Key_Right: (1, 0), Qt.Key.Key_Up: (0, -1), Qt.Key.Key_Down: (0, 1)}
        if key in arrows and self.selection:
            dx, dy = arrows[key]
            step = self.grid_size if mods & Qt.KeyboardModifier.ShiftModifier else 1
            for c in self.selection:
                if mods & Qt.KeyboardModifier.AltModifier and not c.spec.non_visual:
                    c.resize(max(c.spec.min_size[0], c.width() + dx * step), max(c.spec.min_size[1], c.height() + dy * step))
                else:
                    c.move(max(0, c.x() + dx * step), max(0, c.y() + dy * step))
                c.sync_geometry()
            self.changed.emit()
            self.commit()
            self.selectionChanged.emit(self._primary)
            return
        if key in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace) and self.selection:
            self.delete_selection()
            return
        if key == Qt.Key.Key_Escape:
            self.set_selection([])
            return
        super().keyPressEvent(event)

    # -- clipboard ------------------------------------------------------------
    def copy_selection(self):
        if not self.selection:
            return
        payload = json.dumps([c.to_dict() for c in self.selection])
        mime = QMimeData()
        mime.setData(MIME_CONTROLS, payload.encode("utf-8"))
        mime.setText(payload)
        QApplication.clipboard().setMimeData(mime)

    def cut_selection(self):
        self.copy_selection()
        self.delete_selection()

    def can_paste(self) -> bool:
        mime = QApplication.clipboard().mimeData()
        return bool(mime and mime.hasFormat(MIME_CONTROLS))

    def paste(self, offset: int = 16):
        mime = QApplication.clipboard().mimeData()
        if not mime or not mime.hasFormat(MIME_CONTROLS):
            return []
        try:
            items = json.loads(bytes(mime.data(MIME_CONTROLS)).decode("utf-8"))
        except ValueError:
            return []
        return self._insert_copies(items, offset)

    def duplicate_selection(self):
        if self.selection:
            self._insert_copies([c.to_dict() for c in self.selection], 16)

    def _insert_copies(self, items, offset):
        created = []
        for d in items:
            d = dict(d)
            d["x"] = int(d.get("x", 0)) + offset
            d["y"] = int(d.get("y", 0)) + offset
            c = self.add_control(d.get("type", "Label"), data=d, select=False, record=False)
            if c:
                created.append(c)
        if created:
            self.set_selection(created)
            self.changed.emit()
            self.commit()
        return created

    # -- z-order & alignment ---------------------------------------------------
    def bring_to_front(self):
        for c in self.selection:
            c.raise_()
        self.changed.emit()
        self.commit()

    def send_to_back(self):
        for c in reversed(self.selection):
            c.lower()
        self.changed.emit()
        self.commit()

    def align(self, mode: str):
        sel = [c for c in self.selection]
        if not sel:
            return
        ref = self._primary or sel[0]
        if mode == "left":
            for c in sel: c.move(ref.x(), c.y())
        elif mode == "right":
            for c in sel: c.move(ref.x() + ref.width() - c.width(), c.y())
        elif mode == "top":
            for c in sel: c.move(c.x(), ref.y())
        elif mode == "bottom":
            for c in sel: c.move(c.x(), ref.y() + ref.height() - c.height())
        elif mode == "hcenter":
            cx = ref.x() + ref.width() // 2
            for c in sel: c.move(cx - c.width() // 2, c.y())
        elif mode == "vcenter":
            cy = ref.y() + ref.height() // 2
            for c in sel: c.move(c.x(), cy - c.height() // 2)
        elif mode == "same_width":
            for c in sel: c.resize(ref.width(), c.height())
        elif mode == "same_height":
            for c in sel: c.resize(c.width(), ref.height())
        elif mode == "same_size":
            for c in sel: c.resize(ref.size())
        elif mode in ("distribute_h", "distribute_v") and len(sel) >= 3:
            horiz = mode == "distribute_h"
            sel.sort(key=lambda c: c.x() if horiz else c.y())
            first, last = sel[0], sel[-1]
            span = (last.x() + last.width() - first.x()) if horiz else (last.y() + last.height() - first.y())
            total = sum(c.width() if horiz else c.height() for c in sel)
            gap = (span - total) / (len(sel) - 1)
            pos = first.x() if horiz else first.y()
            for c in sel:
                c.move(int(pos), c.y()) if horiz else c.move(c.x(), int(pos))
                pos += (c.width() if horiz else c.height()) + gap
        elif mode == "center_form_h":
            for c in sel: c.move((self.width() - c.width()) // 2, c.y())
        elif mode == "center_form_v":
            for c in sel: c.move(c.x(), (self.height() - c.height()) // 2)
        for c in sel:
            if c.spec.non_visual:
                c.resize(*c.spec.default_size)
            c.move(max(0, c.x()), max(0, c.y()))
            c.sync_geometry()
        self.changed.emit()
        self.commit()
        self.selectionChanged.emit(self._primary)

    # -- history ---------------------------------------------------------------
    def snapshot(self) -> str:
        return json.dumps({"controls": self.controls(), "form": self.form_settings,
                           "selection": [c.objectName() for c in self.selection]}, sort_keys=True)

    def _state_key(self, state: str) -> str:
        data = json.loads(state)
        data.pop("selection", None)
        return json.dumps(data, sort_keys=True)

    def reset_history(self):
        self.history.reset(self.snapshot())
        self.historyChanged.emit()

    def commit(self):
        if self._restoring:
            return
        state = self.snapshot()
        current = self.history.states[self.history.index] if self.history.index >= 0 else None
        if current is not None and self._state_key(current) == self._state_key(state):
            self.history.states[self.history.index] = state  # refresh selection only
            return
        self.history.push(state)
        self.historyChanged.emit()

    def _restore(self, state):
        if state is None:
            return
        data = json.loads(state)
        self._restoring = True
        try:
            self.clear_controls(record=False)
            self.form_settings = {**DEFAULT_FORM, **data.get("form", {})}
            self.apply_form_settings()
            for d in data.get("controls", []):
                self.add_control(d.get("type", "Label"), data=d, select=False, record=False)
        finally:
            self._restoring = False
        names = set(data.get("selection", []))
        self.set_selection([c for c in self.controls_widgets() if c.objectName() in names])
        self.formChanged.emit()
        self.changed.emit()
        self.historyChanged.emit()

    def undo(self):
        self._restore(self.history.undo())

    def redo(self):
        self._restore(self.history.redo())


ALIGN_ACTIONS = [
    ("Align lefts", "left"), ("Align rights", "right"), ("Align tops", "top"), ("Align bottoms", "bottom"),
    ("Align horizontal centres", "hcenter"), ("Align vertical centres", "vcenter"), ("-", ""),
    ("Make same width", "same_width"), ("Make same height", "same_height"), ("Make same size", "same_size"), ("-", ""),
    ("Distribute horizontally", "distribute_h"), ("Distribute vertically", "distribute_v"), ("-", ""),
    ("Centre horizontally in form", "center_form_h"), ("Centre vertically in form", "center_form_v"),
]


class FormFrame(QWidget):
    """Draws a window-like chrome (title bar) around the design canvas."""
    def __init__(self, canvas: DesignCanvas, parent=None):
        super().__init__(parent)
        self.canvas = canvas
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(0)
        self.title = QLabel()
        self.title.setObjectName("formTitleBar")
        self.title.setFixedHeight(30)
        self.title.setStyleSheet("QLabel#formTitleBar { background:#1f2937; color:#f9fafb; padding-left:10px;"
                                 " border-top-left-radius:6px; border-top-right-radius:6px; font-weight:600; }")
        layout.addWidget(self.title)
        layout.addWidget(canvas)
        layout.addStretch(1)
        canvas.formChanged.connect(self.refresh)
        self.refresh()

    def refresh(self):
        f = self.canvas.form_settings
        self.title.setText(f"  {f.get('title') or 'Form'}        {f.get('width')} × {f.get('height')}")
        self.title.setFixedWidth(self.canvas.width())
