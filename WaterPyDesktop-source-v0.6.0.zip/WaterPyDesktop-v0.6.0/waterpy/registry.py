"""Component registry — the single source of truth for every palette tool.

Each palette entry is described by a :class:`ComponentSpec`.  The same spec drives

* the toolbox palette (category, glyph, description),
* the design-time preview on the canvas,
* the schema-driven property grid,
* the Events panel (available Qt signals), and
* native PySide6 code generation.

Because a :class:`PropertySpec` names the Qt *setter* it maps to, the designer
preview and the generated code use exactly the same call, so what you see on the
canvas is what the generated application does.

Plugins add components through ``api.register_component(ComponentSpec(...))``.
"""
from __future__ import annotations

import copy
import importlib
import re
import textwrap
from dataclasses import dataclass, field
from typing import Any, Callable

MISSING = object()

CATEGORY_ORDER = ["Common", "Input", "Containers", "Display", "Data", "Shapes", "System", "Plugins"]
CATEGORY_COLORS = {
    "Common": "#2563eb", "Input": "#0891b2", "Containers": "#7c3aed", "Display": "#059669",
    "Data": "#d97706", "Shapes": "#64748b", "System": "#dc2626", "Plugins": "#db2777",
}

_COLOR_RE = re.compile(r"^(#[0-9a-fA-F]{3,8}|[a-zA-Z]{3,20}|rgba?\([\d\s.,%]+\))$")


def snake(name: str) -> str:
    """``currentIndexChanged`` -> ``current_index_changed``."""
    return re.sub(r"(?<!^)(?=[A-Z])", "_", str(name)).lower()


def valid_color(value: str) -> str:
    value = str(value or "").strip()
    return value if value and _COLOR_RE.match(value) else ""


# ---------------------------------------------------------------------------
# Specs
# ---------------------------------------------------------------------------
@dataclass
class PropertySpec:
    """One editable property of a component.

    ``type`` is one of: ``str``, ``text`` (multi-line), ``int``, ``float``, ``bool``,
    ``color``, ``choice``, ``list`` (one entry per line), ``file``, ``font``.

    If ``setter`` is given, the designer preview calls ``widget.<setter>(value)`` and
    code generation emits ``self.<name>.<setter>(<expr>)``.  ``choice`` properties
    translate through ``code_map`` (value -> Python expression) or ``enum``
    (``"QLineEdit.EchoMode"`` + member name).  ``to_code`` can build any expression.
    """
    key: str
    label: str = ""
    type: str = "str"
    default: Any = ""
    setter: str | None = None
    group: str = ""
    tooltip: str = ""
    choices: tuple = ()
    code_map: dict | None = None
    enum: str | None = None
    to_code: Callable[[Any], str] | None = None
    minimum: float = -1_000_000
    maximum: float = 1_000_000
    qt_default: Any = MISSING      # skip emitting the setter when value equals this
    keep_empty: bool = False       # emit setter even for empty strings / lists
    preview: bool = True           # apply setter on the design canvas

    def __post_init__(self):
        if not self.label:
            self.label = self.key.replace("_", " ").capitalize()
        if self.type == "choice" and not self.choices and self.code_map:
            self.choices = tuple(self.code_map)

    # -- value handling -------------------------------------------------
    def coerce(self, value: Any) -> Any:
        try:
            if self.type == "int":
                return int(max(self.minimum, min(self.maximum, int(float(value)))))
            if self.type == "float":
                return float(max(self.minimum, min(self.maximum, float(value))))
            if self.type == "bool":
                if isinstance(value, str):
                    return value.strip().lower() in ("1", "true", "yes", "on")
                return bool(value)
            if self.type == "list":
                if isinstance(value, str):
                    return [v for v in value.splitlines() if v.strip()]
                return [str(v) for v in (value or [])]
            if self.type == "choice":
                value = str(value)
                return value if value in self.choices else self.default
            if self.type == "color":
                return valid_color(value)
            return "" if value is None else str(value)
        except (TypeError, ValueError):
            return copy.deepcopy(self.default)

    def expr(self, value: Any) -> str:
        """Python source expression for ``value`` (used by codegen *and* preview)."""
        value = self.coerce(value)
        if self.to_code:
            return self.to_code(value)
        if self.code_map:
            return self.code_map.get(value, self.code_map.get(self.default, "None"))
        if self.enum:
            return f"{self.enum}.{value}"
        if self.type == "int":
            return str(int(value))
        if self.type == "float":
            return repr(float(value))
        if self.type == "bool":
            return "True" if value else "False"
        if self.type == "list":
            return repr(list(value))
        return repr(str(value))

    def should_emit(self, value: Any) -> bool:
        if not self.setter:
            return False
        value = self.coerce(value)
        if self.qt_default is not MISSING and value == self.qt_default:
            return False
        if not self.keep_empty and self.type in ("str", "text", "file", "list", "color") and not value:
            return False
        return True


@dataclass
class ComponentSpec:
    """Describes a palette tool.  See ``PLUGIN_SDK.md`` for a full field reference."""
    kind: str
    qt_class: str
    module: str | None = "PySide6.QtWidgets"
    category: str = "Common"
    glyph: str = "?"
    description: str = ""
    default_size: tuple = (160, 32)
    min_size: tuple = (16, 16)
    properties: list = field(default_factory=list)
    signals: dict = field(default_factory=dict)          # signal -> argument description
    default_signal: str = ""
    constructor: str = "{cls}({parent})"
    extra_imports: dict = field(default_factory=dict)    # module -> iterable of names
    snippets: tuple = ()                                 # ids of shared module-level helpers
    support_code: str = ""                               # module-level code (custom classes)
    config: Callable[[str, dict], list] | None = None    # extra codegen lines for self.<name>
    preview_factory: Callable[[Any], Any] | None = None  # parent -> QWidget
    preview_update: Callable[[Any, dict, dict], None] | None = None
    style: Callable[[dict, bool], str] | None = None     # props, design_time -> CSS
    non_visual: bool = False
    icon: Any = None                                     # optional QIcon or image path
    source: str = "builtin"
    help_url: str = ""

    def __post_init__(self):
        for prop in self.properties:
            if not prop.group:
                prop.group = self.kind
        if not self.default_signal and self.signals:
            self.default_signal = next(iter(self.signals))

    def all_properties(self) -> list[PropertySpec]:
        base = NON_VISUAL_COMMON if self.non_visual else COMMON_PROPERTIES
        return list(base) + list(self.properties)

    def property(self, key: str) -> PropertySpec | None:
        for prop in self.all_properties():
            if prop.key == key:
                return prop
        return None

    def defaults(self) -> dict:
        data = {p.key: copy.deepcopy(p.default) for p in self.all_properties()}
        data["width"], data["height"] = self.default_size
        data["events"] = {}
        return data

    def css(self, props: dict, design: bool = False) -> str:
        if self.style:
            return self.style(props, design) or ""
        return default_css(props)


@dataclass
class FormTemplate:
    """A ready-made form layout offered in the Templates palette."""
    name: str
    description: str = ""
    controls: list = field(default_factory=list)
    custom_methods: str = ""
    form: dict = field(default_factory=dict)
    category: str = "Built-in"
    source: str = "builtin"


def default_css(p: dict) -> str:
    parts = []
    fg, bg = valid_color(p.get("foreground")), valid_color(p.get("background"))
    if fg:
        parts.append(f"color: {fg};")
    if bg:
        parts.append(f"background-color: {bg};")
    extra = str(p.get("stylesheet") or "").strip()
    if extra:
        parts.append(extra if extra.endswith(";") or extra.endswith("}") else extra + ";")
    return " ".join(parts)


P = PropertySpec

COMMON_PROPERTIES = [
    P("name", "Object name", "str", "", group="Identity", tooltip="Python attribute name: self.<name>"),
    P("x", "X", "int", 20, group="Layout", minimum=0, maximum=20000),
    P("y", "Y", "int", 20, group="Layout", minimum=0, maximum=20000),
    P("width", "Width", "int", 160, group="Layout", minimum=2, maximum=20000),
    P("height", "Height", "int", 32, group="Layout", minimum=2, maximum=20000),
    P("font_family", "Font family", "font", "", group="Appearance", tooltip="Empty = system default"),
    P("font_size", "Font size (pt)", "int", 0, group="Appearance", minimum=0, maximum=300, tooltip="0 = default"),
    P("bold", "Bold", "bool", False, group="Appearance"),
    P("italic", "Italic", "bool", False, group="Appearance"),
    P("foreground", "Text colour", "color", "", group="Appearance"),
    P("background", "Background", "color", "", group="Appearance"),
    P("stylesheet", "Extra style sheet", "text", "", group="Appearance",
      tooltip="Qt style sheet declarations, e.g. border-radius: 6px; padding: 4px;"),
    P("tooltip", "Tool tip", "str", "", setter="setToolTip", group="Behaviour"),
    P("enabled", "Enabled", "bool", True, setter="setEnabled", qt_default=True, group="Behaviour"),
    P("visible", "Visible", "bool", True, setter="setVisible", qt_default=True, group="Behaviour", preview=False),
]
NON_VISUAL_COMMON = [
    P("name", "Object name", "str", "", group="Identity"),
    P("x", "Designer X", "int", 20, group="Layout", minimum=0, maximum=20000),
    P("y", "Designer Y", "int", 20, group="Layout", minimum=0, maximum=20000),
]
SPECIAL_KEYS = {"name", "x", "y", "width", "height", "font_family", "font_size", "bold", "italic",
                "foreground", "background", "stylesheet", "type", "events"}

# ---------------------------------------------------------------------------
# Shared module-level snippets used by generated code
# ---------------------------------------------------------------------------
SNIPPETS: dict[str, tuple[str, dict]] = {
    "resource_path": (textwrap.dedent('''
        def resource_path(relative: str) -> str:
            """Resolve a project asset both from source and from a PyInstaller build."""
            base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
            return os.path.join(base, relative)
        ''').strip(), {"os": None}),
    "webengine": (textwrap.dedent('''
        try:  # Qt WebEngine is an optional PySide6 add-on
            from PySide6.QtWebEngineWidgets import QWebEngineView
        except ImportError:  # pragma: no cover - fall back to a simple HTML viewer
            QWebEngineView = None
        ''').strip(), {}),
}


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------
class ComponentRegistry:
    def __init__(self):
        self._specs: dict[str, ComponentSpec] = {}
        self._templates: dict[str, FormTemplate] = {}
        self._listeners: list[Callable[[], None]] = []
        self.aliases = {"Text Edit": "Memo"}

    # components
    def register(self, spec: ComponentSpec, source: str | None = None, replace: bool = False) -> ComponentSpec:
        if not isinstance(spec, ComponentSpec):
            raise TypeError("register() expects a ComponentSpec")
        if not spec.kind or not spec.qt_class:
            raise ValueError("ComponentSpec needs kind and qt_class")
        if spec.kind in self._specs and not replace:
            raise ValueError(f"Component kind already registered: {spec.kind!r}")
        if source:
            spec.source = source
        self._specs[spec.kind] = spec
        self._notify()
        return spec

    def unregister(self, kind: str):
        if self._specs.pop(kind, None) is not None:
            self._notify()

    def unregister_source(self, source: str):
        kinds = [k for k, s in self._specs.items() if s.source == source]
        names = [n for n, t in self._templates.items() if t.source == source]
        for k in kinds:
            self._specs.pop(k, None)
        for n in names:
            self._templates.pop(n, None)
        if kinds or names:
            self._notify()

    def get(self, kind: str) -> ComponentSpec | None:
        return self._specs.get(self.aliases.get(kind, kind))

    def resolve_kind(self, kind: str) -> str:
        return self.aliases.get(kind, kind)

    def __contains__(self, kind) -> bool:
        return self.resolve_kind(kind) in self._specs

    def kinds(self) -> list[str]:
        return list(self._specs)

    def specs(self) -> list[ComponentSpec]:
        return list(self._specs.values())

    def by_category(self) -> list[tuple[str, list[ComponentSpec]]]:
        groups: dict[str, list[ComponentSpec]] = {}
        for spec in self._specs.values():
            groups.setdefault(spec.category or "Plugins", []).append(spec)
        order = {c: i for i, c in enumerate(CATEGORY_ORDER)}
        return sorted(groups.items(), key=lambda kv: (order.get(kv[0], 99), kv[0]))

    # templates
    def register_template(self, template: FormTemplate, source: str | None = None):
        if source:
            template.source = source
        self._templates[template.name] = template
        self._notify()
        return template

    def templates(self) -> list[FormTemplate]:
        return list(self._templates.values())

    def template(self, name: str) -> FormTemplate | None:
        return self._templates.get(name)

    # snippets
    def register_snippet(self, snippet_id: str, code: str, imports: dict | None = None):
        SNIPPETS[snippet_id] = (textwrap.dedent(code).strip(), dict(imports or {}))

    # change notification
    def add_listener(self, callback: Callable[[], None]):
        self._listeners.append(callback)

    def remove_listener(self, callback):
        if callback in self._listeners:
            self._listeners.remove(callback)

    def _notify(self):
        for cb in list(self._listeners):
            try:
                cb()
            except Exception:
                pass

    # project-data helpers
    def normalize(self, raw: dict) -> dict | None:
        """Return a complete, type-checked control dict (migrating older project formats)."""
        kind = self.resolve_kind(str(raw.get("type", "Label")))
        spec = self.get(kind)
        if spec is None:
            return None
        data = spec.defaults()
        legacy_defaults = {"font_family": "", "font_size": 0}
        for prop in spec.all_properties():
            if prop.key in raw:
                data[prop.key] = prop.coerce(raw[prop.key])
        for key, value in legacy_defaults.items():
            if key not in raw:
                data[key] = value
        # legacy migrations ------------------------------------------------
        if kind == "Tab" and "tabs" not in raw and raw.get("text"):
            data["tabs"] = [str(raw["text"])]
        if kind == "Grid" and "headers" not in raw:
            data["headers"] = [f"Column {i + 1}" for i in range(int(data.get("columns", 3)))]
        if kind == "Web Browser" and "html" not in raw and raw.get("text") not in (None, "", "Web Browser"):
            data["html"] = str(raw["text"])
        events = dict(raw.get("events") or {})
        legacy_code = str(raw.get("on_click") or "").strip("\n")
        if legacy_code.strip() and not events:
            signal = str(raw.get("event_signal") or "")
            if signal not in spec.signals:
                signal = spec.default_signal
            if signal:
                events[signal] = legacy_code
        data["events"] = {s: str(c) for s, c in events.items() if s in spec.signals and str(c).strip()}
        data["type"] = kind
        data["name"] = str(raw.get("name") or "")
        return data


REGISTRY = ComponentRegistry()


# ---------------------------------------------------------------------------
# Expression evaluation shared by preview (designer) and codegen
# ---------------------------------------------------------------------------
_NAMESPACE: dict | None = None
QT_MODULES = ("PySide6.QtCore", "PySide6.QtGui", "PySide6.QtWidgets")


def qt_namespace() -> dict:
    global _NAMESPACE
    if _NAMESPACE is None:
        ns = {}
        for mod_name in reversed(QT_MODULES):
            mod = importlib.import_module(mod_name)
            ns.update({k: getattr(mod, k) for k in dir(mod) if k.startswith("Q")})
        _NAMESPACE = ns
    return _NAMESPACE


def qt_module_for(name: str) -> str | None:
    for mod_name in QT_MODULES:
        try:
            if hasattr(importlib.import_module(mod_name), name):
                return mod_name
        except ImportError:
            continue
    return None


def eval_expr(expr: str):
    return eval(expr, {"__builtins__": {}}, qt_namespace())  # expressions come from trusted specs


# ---------------------------------------------------------------------------
# Built-in components
# ---------------------------------------------------------------------------
ALIGN = {
    "Left": "Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter",
    "Center": "Qt.AlignmentFlag.AlignCenter",
    "Right": "Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter",
    "Top left": "Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop",
}
ORIENT = {"Horizontal": "Qt.Orientation.Horizontal", "Vertical": "Qt.Orientation.Vertical"}


def _date_code(v):
    v = str(v).strip()
    return "QDate.currentDate()" if v.lower() in ("", "today") else f"QDate.fromString({v!r}, 'yyyy-MM-dd')"


def _time_code(v):
    v = str(v).strip()
    return "QTime.currentTime()" if v.lower() in ("", "now") else f"QTime.fromString({v!r}, 'HH:mm:ss')"


def _datetime_code(v):
    v = str(v).strip()
    return "QDateTime.currentDateTime()" if v.lower() in ("", "now") else f"QDateTime.fromString({v!r}, 'yyyy-MM-dd HH:mm:ss')"


def _placeholder_factory(text):
    def factory(parent):
        from PySide6.QtWidgets import QLabel
        from PySide6.QtCore import Qt
        w = QLabel(text, parent)
        w.setAlignment(Qt.AlignmentFlag.AlignCenter)
        w.setStyleSheet("background:#f1f5f9;border:1px dashed #94a3b8;color:#475569;")
        return w
    return factory


def _tabs_preview(widget, p, ctx):
    from PySide6.QtWidgets import QWidget
    while widget.count():
        widget.removeTab(0)
    for title in p.get("tabs") or ["Tab 1"]:
        widget.addTab(QWidget(), title)


def _tabs_config(w, p):
    return [f"{w}.addTab(QWidget(), {t!r})" for t in (p.get("tabs") or ["Tab 1"])]


def _image_preview(widget, p, ctx):
    from PySide6.QtGui import QPixmap
    path = str(p.get("image_path") or "")
    base = ctx.get("project_dir")
    if path and base:
        from pathlib import Path
        full = Path(base) / path
        if full.is_file():
            widget.setPixmap(QPixmap(str(full)))
            return
    widget.setText(p.get("text") or "Image")


def _image_config(w, p):
    path = str(p.get("image_path") or "").replace("\\", "/")
    return [f"{w}.setPixmap(QPixmap(resource_path({path!r})))"] if path else []


def _hyperlink_html(p):
    from html import escape
    return f'<a href="{escape(str(p.get("url") or ""), quote=True)}">{escape(str(p.get("text") or ""))}</a>'


def _tree_config(w, p):
    lines = []
    for item in p.get("items") or []:
        lines.append(f"QTreeWidgetItem({w}, [{str(item)!r}])")
    return lines


def _tree_preview(widget, p, ctx):
    from PySide6.QtWidgets import QTreeWidgetItem
    widget.clear()
    for item in p.get("items") or []:
        QTreeWidgetItem(widget, [str(item)])


def _rect_css(p, design=False):
    radius = int(p.get("radius", 0) or 0)
    bw = int(p.get("border_width", 2) or 0)
    border = valid_color(p.get("border_color")) or "#64748b"
    parts = [f"border: {bw}px solid {border};" if bw else "border: none;"]
    if radius:
        parts.append(f"border-radius: {radius}px;")
    css = default_css(p)
    return " ".join(parts + ([css] if css else []))


def _ellipse_css(p, design=False):
    radius = max(4, min(int(p.get("width", 80)), int(p.get("height", 80))) // 2)
    bw = int(p.get("border_width", 2) or 0)
    border = valid_color(p.get("border_color")) or "#64748b"
    css = default_css(p)
    return f"border: {bw}px solid {border}; border-radius: {radius}px;" + (" " + css if css else "")


def _container_css(p, design=False):
    css = default_css(p)
    if design and "border" not in css:
        css = ("border: 1px dashed #94a3b8; " + css).strip()
    return css


def _timer_config(w, p):
    return [f"{w}.start()"] if p.get("autostart", True) else []


def _media_config(w, p):
    name = w
    lines = [
        f"{name}_player = QMediaPlayer(self)",
        f"{name}_audio = QAudioOutput(self)",
        f"{name}_audio.setVolume({max(0, min(100, int(p.get('volume', 80)))) / 100!r})",
        f"{name}_player.setAudioOutput({name}_audio)",
        f"{name}_player.setVideoOutput({name})",
    ]
    if p.get("loop"):
        lines.append(f"{name}_player.setLoops(QMediaPlayer.Loops.Infinite)")
    src = str(p.get("source") or "").replace("\\", "/")
    if src:
        if src.startswith(("http://", "https://")):
            lines.append(f"{name}_player.setSource(QUrl({src!r}))")
        else:
            lines.append(f"{name}_player.setSource(QUrl.fromLocalFile(resource_path({src!r})))")
        if p.get("autoplay"):
            lines.append(f"{name}_player.play()")
    return lines


def _webview_config(w, p):
    url = str(p.get("url") or "about:blank")
    return [
        "if QWebEngineView is not None:",
        f"    {w}.setUrl(QUrl({url!r}))",
        "else:",
        f"    {w}.setHtml('<p>Install PySide6 Qt WebEngine to display: <a href=\"' + {url!r} + '\">' + {url!r} + '</a></p>')",
        f"    {w}.setOpenExternalLinks(True)",
    ]


def _line_config(w, p):
    shape = "VLine" if p.get("orientation") == "Vertical" else "HLine"
    return [f"{w}.setFrameShape(QFrame.Shape.{shape})", f"{w}.setFrameShadow(QFrame.Shadow.Plain)"]


def _line_preview(widget, p, ctx):
    from PySide6.QtWidgets import QFrame
    widget.setFrameShape(QFrame.Shape.VLine if p.get("orientation") == "Vertical" else QFrame.Shape.HLine)
    widget.setFrameShadow(QFrame.Shadow.Plain)


def _line_css(p, design=False):
    fg = valid_color(p.get("foreground")) or "#64748b"
    extra = str(p.get("stylesheet") or "").strip()
    return f"color: {fg};" + (" " + extra if extra else "")


def _hyperlink_config(w, p):
    return [f"{w}.setText({_hyperlink_html(p)!r})", f"{w}.setTextFormat(Qt.TextFormat.RichText)",
            f"{w}.setOpenExternalLinks(True)"]


def _hyperlink_preview(widget, p, ctx):
    widget.setText(_hyperlink_html(p))


def _grid_rows(p):
    import csv
    import io
    text = str(p.get("data") or "")
    return [r for r in csv.reader(io.StringIO(text)) if any(c.strip() for c in r)] if text.strip() else []


def _grid_config(w, p):
    lines = [f"{w}.horizontalHeader().setStretchLastSection(True)"] if p.get("stretch_last", True) else []
    rows = _grid_rows(p)
    if rows:
        lines += [f"_rows = {rows!r}",
                  f"{w}.setRowCount(max({w}.rowCount(), len(_rows)))",
                  f"{w}.setColumnCount(max({w}.columnCount(), max(len(r) for r in _rows)))",
                  "for _r, _values in enumerate(_rows):",
                  "    for _c, _value in enumerate(_values):",
                  f"        {w}.setItem(_r, _c, QTableWidgetItem(_value))"]
    return lines


def _grid_preview(widget, p, ctx):
    from PySide6.QtWidgets import QTableWidgetItem
    rows = _grid_rows(p)
    if rows:
        widget.setRowCount(max(widget.rowCount(), len(rows)))
        widget.setColumnCount(max(widget.columnCount(), max(len(r) for r in rows)))
        for r, values in enumerate(rows[:200]):
            for c, value in enumerate(values):
                widget.setItem(r, c, QTableWidgetItem(value))


def _line_edit_props(echo="Normal", placeholder="Enter text…"):
    return [
        P("text", "Text", "str", "", setter="setText"),
        P("placeholder", "Placeholder", "str", placeholder, setter="setPlaceholderText"),
        P("echo_mode", "Echo mode", "choice", echo, setter="setEchoMode", enum="QLineEdit.EchoMode",
          choices=("Normal", "Password", "PasswordEchoOnEdit", "NoEcho"), qt_default="Normal"),
        P("max_length", "Max length", "int", 32767, setter="setMaxLength", minimum=1, maximum=32767, qt_default=32767),
        P("read_only", "Read only", "bool", False, setter="setReadOnly", qt_default=False),
        P("clear_button", "Clear button", "bool", False, setter="setClearButtonEnabled", qt_default=False),
    ]


def _range_props(minimum=0, maximum=100, value=0, kind="int"):
    return [
        P("minimum", "Minimum", kind, minimum, setter="setMinimum"),
        P("maximum", "Maximum", kind, maximum, setter="setMaximum"),
        P("value", "Value", kind, value, setter="setValue"),
    ]


def _builtin_specs() -> list[ComponentSpec]:
    text_signals = {"textChanged": "text: str", "returnPressed": "", "editingFinished": ""}
    return [
        # ---------------- Common
        ComponentSpec("Label", "QLabel", category="Common", glyph="Aa", description="Static text or caption",
                      default_size=(140, 28), signals={"linkActivated": "link: str"},
                      properties=[P("text", "Text", "str", "Label", setter="setText", keep_empty=True),
                                  P("alignment", "Alignment", "choice", "Left", setter="setAlignment", code_map=ALIGN, qt_default="Left"),
                                  P("word_wrap", "Word wrap", "bool", False, setter="setWordWrap", qt_default=False)]),
        ComponentSpec("Button", "QPushButton", category="Common", glyph="OK", description="Push button that runs an action",
                      default_size=(140, 36), signals={"clicked": "checked: bool", "pressed": "", "released": "", "toggled": "checked: bool"},
                      properties=[P("text", "Text", "str", "Click Me", setter="setText", keep_empty=True),
                                  P("checkable", "Checkable", "bool", False, setter="setCheckable", qt_default=False),
                                  P("flat", "Flat", "bool", False, setter="setFlat", qt_default=False),
                                  P("default_button", "Default button", "bool", False, setter="setDefault", qt_default=False)]),
        ComponentSpec("Toggle Button", "QPushButton", category="Common", glyph="⏻", description="Button that stays pressed (on/off)",
                      default_size=(140, 36), signals={"toggled": "checked: bool", "clicked": "checked: bool"},
                      properties=[P("text", "Text", "str", "Toggle", setter="setText", keep_empty=True),
                                  P("checkable", "Checkable", "bool", True, setter="setCheckable"),
                                  P("checked", "Checked", "bool", False, setter="setChecked", qt_default=False)]),
        ComponentSpec("Command Link", "QCommandLinkButton", category="Common", glyph="➜", description="Windows-style command link with description",
                      default_size=(280, 60), signals={"clicked": "checked: bool"},
                      properties=[P("text", "Text", "str", "Continue", setter="setText", keep_empty=True),
                                  P("description", "Description", "str", "Proceed to the next step", setter="setDescription")]),
        ComponentSpec("Check Box", "QCheckBox", category="Common", glyph="☑", description="On/off option",
                      default_size=(160, 28), signals={"toggled": "checked: bool", "stateChanged": "state: int"},
                      properties=[P("text", "Text", "str", "Check me", setter="setText", keep_empty=True),
                                  P("checked", "Checked", "bool", False, setter="setChecked", qt_default=False),
                                  P("tristate", "Tri-state", "bool", False, setter="setTristate", qt_default=False)]),
        ComponentSpec("Radio Button", "QRadioButton", category="Common", glyph="◉", description="One choice within a group",
                      default_size=(160, 28), signals={"toggled": "checked: bool", "clicked": "checked: bool"},
                      properties=[P("text", "Text", "str", "Option", setter="setText", keep_empty=True),
                                  P("checked", "Checked", "bool", False, setter="setChecked", qt_default=False)]),
        ComponentSpec("Hyperlink", "QLabel", category="Common", glyph="🔗", description="Clickable link that opens a browser",
                      default_size=(160, 28), signals={"linkActivated": "link: str"},
                      properties=[P("text", "Link text", "str", "Visit website"),
                                  P("url", "URL", "str", "https://example.com")],
                      config=_hyperlink_config, preview_update=_hyperlink_preview),
        # ---------------- Input
        ComponentSpec("Line Edit", "QLineEdit", category="Input", glyph="ab|", description="Single-line text input",
                      default_size=(200, 32), signals=dict(text_signals), properties=_line_edit_props()),
        ComponentSpec("Password Box", "QLineEdit", category="Input", glyph="•••", description="Masked password input",
                      default_size=(200, 32), signals=dict(text_signals), properties=_line_edit_props("Password", "Password")),
        ComponentSpec("Memo", "QTextEdit", category="Input", glyph="≡", description="Multi-line rich text editor",
                      default_size=(260, 120), signals={"textChanged": ""},
                      properties=[P("text", "Text", "text", "", setter="setPlainText"),
                                  P("placeholder", "Placeholder", "str", "Enter text…", setter="setPlaceholderText"),
                                  P("read_only", "Read only", "bool", False, setter="setReadOnly", qt_default=False)]),
        ComponentSpec("Plain Text Edit", "QPlainTextEdit", category="Input", glyph="¶", description="Fast plain-text editor for logs or code",
                      default_size=(260, 120), signals={"textChanged": ""},
                      properties=[P("text", "Text", "text", "", setter="setPlainText"),
                                  P("placeholder", "Placeholder", "str", "", setter="setPlaceholderText"),
                                  P("read_only", "Read only", "bool", False, setter="setReadOnly", qt_default=False)]),
        ComponentSpec("Spin Box", "QSpinBox", category="Input", glyph="1⇕", description="Whole-number input with arrows",
                      default_size=(120, 32), signals={"valueChanged": "value: int"},
                      properties=_range_props() + [P("single_step", "Step", "int", 1, setter="setSingleStep", qt_default=1),
                                                   P("prefix", "Prefix", "str", "", setter="setPrefix"),
                                                   P("suffix", "Suffix", "str", "", setter="setSuffix")]),
        ComponentSpec("Double Spin Box", "QDoubleSpinBox", category="Input", glyph="1.5", description="Decimal number input",
                      default_size=(120, 32), signals={"valueChanged": "value: float"},
                      properties=[P("decimals", "Decimals", "int", 2, setter="setDecimals", minimum=0, maximum=10, qt_default=2)]
                      + _range_props(0.0, 100.0, 0.0, "float")
                      + [P("single_step", "Step", "float", 0.1, setter="setSingleStep"),
                         P("prefix", "Prefix", "str", "", setter="setPrefix"),
                         P("suffix", "Suffix", "str", "", setter="setSuffix")]),
        ComponentSpec("Slider", "QSlider", category="Input", glyph="─●", description="Drag to pick a value in a range",
                      default_size=(200, 28), signals={"valueChanged": "value: int", "sliderReleased": ""},
                      properties=[P("orientation", "Orientation", "choice", "Horizontal", setter="setOrientation", code_map=ORIENT)]
                      + _range_props(0, 100, 50)
                      + [P("ticks", "Tick marks", "choice", "NoTicks", setter="setTickPosition", enum="QSlider.TickPosition",
                           choices=("NoTicks", "TicksAbove", "TicksBelow", "TicksBothSides"), qt_default="NoTicks")]),
        ComponentSpec("Dial", "QDial", category="Input", glyph="◔", description="Rotary knob",
                      default_size=(90, 90), signals={"valueChanged": "value: int"},
                      properties=_range_props(0, 100, 0) + [
                          P("notches", "Show notches", "bool", True, setter="setNotchesVisible", qt_default=False),
                          P("wrapping", "Wrapping", "bool", False, setter="setWrapping", qt_default=False)]),
        ComponentSpec("Combo Box", "QComboBox", category="Input", glyph="▾", description="Drop-down list",
                      default_size=(180, 32), signals={"currentIndexChanged": "index: int", "currentTextChanged": "text: str"},
                      properties=[P("items", "Items", "list", ["Option 1", "Option 2", "Option 3"], setter="addItems"),
                                  P("editable", "Editable", "bool", False, setter="setEditable", qt_default=False),
                                  P("placeholder", "Placeholder", "str", "", setter="setPlaceholderText")]),
        ComponentSpec("Font Combo", "QFontComboBox", category="Input", glyph="Ff", description="Font family picker",
                      default_size=(200, 32), signals={"currentFontChanged": "font: QFont"}),
        ComponentSpec("Date Edit", "QDateEdit", category="Input", glyph="📅", description="Date input with calendar pop-up",
                      default_size=(150, 32), signals={"dateChanged": "date: QDate"},
                      properties=[P("date", "Date (yyyy-MM-dd or today)", "str", "today", setter="setDate", to_code=_date_code, keep_empty=True),
                                  P("display_format", "Display format", "str", "yyyy-MM-dd", setter="setDisplayFormat"),
                                  P("calendar_popup", "Calendar pop-up", "bool", True, setter="setCalendarPopup", qt_default=False)]),
        ComponentSpec("Time Edit", "QTimeEdit", category="Input", glyph="🕒", description="Time input",
                      default_size=(120, 32), signals={"timeChanged": "time: QTime"},
                      properties=[P("time", "Time (HH:mm:ss or now)", "str", "now", setter="setTime", to_code=_time_code, keep_empty=True),
                                  P("display_format", "Display format", "str", "HH:mm", setter="setDisplayFormat")]),
        ComponentSpec("Date Time Edit", "QDateTimeEdit", category="Input", glyph="📆", description="Combined date and time input",
                      default_size=(190, 32), signals={"dateTimeChanged": "value: QDateTime"},
                      properties=[P("datetime", "Value (yyyy-MM-dd HH:mm:ss or now)", "str", "now", setter="setDateTime", to_code=_datetime_code, keep_empty=True),
                                  P("display_format", "Display format", "str", "yyyy-MM-dd HH:mm", setter="setDisplayFormat"),
                                  P("calendar_popup", "Calendar pop-up", "bool", True, setter="setCalendarPopup", qt_default=False)]),
        ComponentSpec("Key Sequence", "QKeySequenceEdit", category="Input", glyph="⌘", description="Records a keyboard shortcut",
                      default_size=(170, 32), signals={"keySequenceChanged": "seq: QKeySequence", "editingFinished": ""}),
        # ---------------- Containers
        ComponentSpec("Container", "QFrame", category="Containers", glyph="▢", description="Visual panel / frame",
                      default_size=(260, 160), style=_container_css,
                      properties=[P("frame", "Frame shape", "choice", "StyledPanel", setter="setFrameShape", enum="QFrame.Shape",
                                    choices=("NoFrame", "Box", "Panel", "StyledPanel", "WinPanel"), qt_default="NoFrame")]),
        ComponentSpec("Group Box", "QGroupBox", category="Containers", glyph="⊡", description="Titled frame that groups controls",
                      default_size=(260, 160), signals={"toggled": "on: bool"},
                      properties=[P("title", "Title", "str", "Group", setter="setTitle"),
                                  P("checkable", "Checkable", "bool", False, setter="setCheckable", qt_default=False)]),
        ComponentSpec("Tab", "QTabWidget", category="Containers", glyph="⊓", description="Tabbed pages",
                      default_size=(320, 200), signals={"currentChanged": "index: int"},
                      properties=[P("tabs", "Tab titles", "list", ["Tab 1", "Tab 2"]),
                                  P("tab_position", "Tab position", "choice", "North", setter="setTabPosition", enum="QTabWidget.TabPosition",
                                    choices=("North", "South", "West", "East"), qt_default="North")],
                      config=_tabs_config, preview_update=_tabs_preview),
        # ---------------- Display
        ComponentSpec("Image", "QLabel", category="Display", glyph="🖼", description="Picture from the project assets folder",
                      default_size=(180, 140), snippets=("resource_path",),
                      properties=[P("text", "Placeholder text", "str", "Image", setter="setText"),
                                  P("image_path", "Image (assets/…)", "file", ""),
                                  P("scaled", "Scale to fit", "bool", True, setter="setScaledContents", qt_default=False),
                                  P("alignment", "Alignment", "choice", "Center", setter="setAlignment", code_map=ALIGN)],
                      config=_image_config, preview_update=_image_preview),
        ComponentSpec("Progress Bar", "QProgressBar", category="Display", glyph="▰▱", description="Progress indicator",
                      default_size=(220, 26), signals={"valueChanged": "value: int"},
                      properties=_range_props(0, 100, 0) + [
                          P("text_visible", "Show text", "bool", True, setter="setTextVisible", qt_default=True),
                          P("format", "Format", "str", "%p%", setter="setFormat")]),
        ComponentSpec("LCD Number", "QLCDNumber", category="Display", glyph="88", description="Seven-segment digital display",
                      default_size=(150, 56),
                      properties=[P("digits", "Digit count", "int", 6, setter="setDigitCount", minimum=1, maximum=30),
                                  P("number", "Value", "float", 0.0, setter="display"),
                                  P("segment_style", "Segment style", "choice", "Flat", setter="setSegmentStyle", enum="QLCDNumber.SegmentStyle",
                                    choices=("Flat", "Filled", "Outline"))]),
        ComponentSpec("Calendar", "QCalendarWidget", category="Display", glyph="▦", description="Month calendar",
                      default_size=(300, 210), signals={"selectionChanged": "", "clicked": "date: QDate"},
                      properties=[P("grid_visible", "Grid lines", "bool", True, setter="setGridVisible", qt_default=False)]),
        ComponentSpec("Web Browser", "QTextBrowser", category="Display", glyph="</>", description="Rich-text / HTML viewer",
                      default_size=(320, 200), signals={"anchorClicked": "url: QUrl"},
                      properties=[P("html", "HTML", "text", "<h3>Web content preview</h3>", setter="setHtml"),
                                  P("open_links", "Open links in browser", "bool", True, setter="setOpenExternalLinks", qt_default=False),
                                  P("url", "Reference URL", "str", "https://example.com")]),
        ComponentSpec("Web View", "QWebEngineView", module=None, category="Display", glyph="🌐",
                      description="Full web browser (Qt WebEngine, falls back to HTML viewer)",
                      default_size=(420, 280), snippets=("webengine",),
                      constructor="QWebEngineView({parent}) if QWebEngineView is not None else QTextBrowser({parent})",
                      properties=[P("url", "URL", "str", "https://www.python.org")], config=_webview_config,
                      preview_factory=_placeholder_factory("🌐 Web View")),
        # ---------------- Data
        ComponentSpec("List Box", "QListWidget", category="Data", glyph="☰", description="Scrollable list of items",
                      default_size=(200, 140),
                      signals={"currentRowChanged": "row: int", "itemDoubleClicked": "item: QListWidgetItem", "itemSelectionChanged": ""},
                      properties=[P("items", "Items", "list", ["Option 1", "Option 2", "Option 3"], setter="addItems"),
                                  P("alternating", "Alternating rows", "bool", False, setter="setAlternatingRowColors", qt_default=False)]),
        ComponentSpec("Grid", "QTableWidget", category="Data", glyph="▦", description="Editable table / spreadsheet grid",
                      default_size=(360, 180),
                      signals={"cellClicked": "row: int, column: int", "cellChanged": "row: int, column: int", "itemSelectionChanged": ""},
                      properties=[P("rows", "Rows", "int", 3, setter="setRowCount", minimum=0, maximum=100000),
                                  P("columns", "Columns", "int", 3, setter="setColumnCount", minimum=0, maximum=1000),
                                  P("headers", "Column headers", "list", ["Column 1", "Column 2", "Column 3"], setter="setHorizontalHeaderLabels"),
                                  P("alternating", "Alternating rows", "bool", False, setter="setAlternatingRowColors", qt_default=False),
                                  P("stretch_last", "Stretch last column", "bool", True),
                                  P("data", "Cell data (CSV)", "text", "", tooltip="Initial cells, one row per line, comma separated. "
                                    "Use Project → Import CSV into Grid to fill from a file.")],
                      config=_grid_config, preview_update=_grid_preview),
        ComponentSpec("Tree View", "QTreeWidget", category="Data", glyph="🌲", description="Hierarchical tree of items",
                      default_size=(260, 180),
                      signals={"itemClicked": "item: QTreeWidgetItem, column: int", "itemDoubleClicked": "item: QTreeWidgetItem, column: int",
                               "currentItemChanged": "current, previous"},
                      properties=[P("headers", "Column headers", "list", ["Name"], setter="setHeaderLabels"),
                                  P("items", "Top-level items", "list", ["Item 1", "Item 2"])],
                      config=_tree_config, preview_update=_tree_preview),
        # ---------------- Shapes
        ComponentSpec("Rectangle", "QFrame", category="Shapes", glyph="■", description="Box shape (optionally rounded)",
                      default_size=(160, 100), style=_rect_css,
                      properties=[P("border_color", "Border colour", "color", "#64748b"),
                                  P("border_width", "Border width", "int", 2, minimum=0, maximum=50),
                                  P("radius", "Corner radius", "int", 0, minimum=0, maximum=500)]),
        ComponentSpec("Ellipse", "QLabel", category="Shapes", glyph="●", description="Circle / ellipse shape with optional text",
                      default_size=(100, 100), style=_ellipse_css,
                      properties=[P("text", "Text", "str", "", setter="setText"),
                                  P("alignment", "Alignment", "choice", "Center", setter="setAlignment", code_map=ALIGN),
                                  P("border_color", "Border colour", "color", "#64748b"),
                                  P("border_width", "Border width", "int", 2, minimum=0, maximum=50)]),
        ComponentSpec("Line", "QFrame", category="Shapes", glyph="━", description="Horizontal or vertical separator",
                      default_size=(200, 12), min_size=(4, 4), style=_line_css,
                      properties=[P("orientation", "Orientation", "choice", "Horizontal", choices=("Horizontal", "Vertical")),
                                  P("line_width", "Line width", "int", 1, setter="setLineWidth", minimum=1, maximum=20, qt_default=1)],
                      config=_line_config, preview_update=_line_preview),
        # ---------------- System
        ComponentSpec("Timer", "QTimer", module="PySide6.QtCore", category="System", glyph="⏱", description="Runs code at an interval (non-visual)",
                      default_size=(110, 36), non_visual=True, constructor="QTimer(self)", signals={"timeout": ""},
                      properties=[P("interval", "Interval (ms)", "int", 1000, setter="setInterval", minimum=1, maximum=86_400_000),
                                  P("single_shot", "Single shot", "bool", False, setter="setSingleShot", qt_default=False),
                                  P("autostart", "Start automatically", "bool", True)],
                      config=_timer_config, preview_factory=_placeholder_factory("⏱ Timer")),
        ComponentSpec("Media", "QVideoWidget", module="PySide6.QtMultimediaWidgets", category="System", glyph="▶",
                      description="Audio / video player (Qt Multimedia)", default_size=(320, 200), snippets=("resource_path",),
                      extra_imports={"PySide6.QtMultimedia": ["QMediaPlayer", "QAudioOutput"], "PySide6.QtCore": ["QUrl"]},
                      properties=[P("source", "Source (assets/… or URL)", "file", ""),
                                  P("autoplay", "Auto-play", "bool", False),
                                  P("loop", "Loop", "bool", False),
                                  P("volume", "Volume %", "int", 80, minimum=0, maximum=100)],
                      config=_media_config, preview_factory=_placeholder_factory("▶ Media Player")),
    ]


def _builtin_templates() -> list[FormTemplate]:
    return [
        FormTemplate("Login Form", "Username/password sign-in with validation", form={"title": "Sign in", "width": 420, "height": 340}, controls=[
            {"type": "Label", "name": "lbl_title", "text": "Welcome back", "x": 40, "y": 30, "width": 340, "height": 40, "font_size": 18, "bold": True},
            {"type": "Label", "name": "lbl_user", "text": "Username", "x": 40, "y": 90, "width": 340, "height": 22},
            {"type": "Line Edit", "name": "txt_user", "placeholder": "you@example.com", "x": 40, "y": 114, "width": 340, "height": 34},
            {"type": "Label", "name": "lbl_pass", "text": "Password", "x": 40, "y": 158, "width": 340, "height": 22},
            {"type": "Password Box", "name": "txt_pass", "x": 40, "y": 182, "width": 340, "height": 34},
            {"type": "Check Box", "name": "chk_remember", "text": "Remember me", "x": 40, "y": 226, "width": 160, "height": 26},
            {"type": "Button", "name": "btn_login", "text": "Sign in", "x": 240, "y": 262, "width": 140, "height": 38, "default_button": True,
             "foreground": "#ffffff", "background": "#2563eb", "events": {"clicked": "self.login()"}},
        ], custom_methods='''    def login(self):
        user = self.txt_user.text().strip()
        if not user or not self.txt_pass.text():
            QMessageBox.warning(self, "Sign in", "Enter both username and password.")
            return
        QMessageBox.information(self, "Sign in", f"Welcome, {user}!")
'''),
        FormTemplate("Contact Form", "Name, email, subject and message with a send button", form={"title": "Contact us", "width": 520, "height": 470}, controls=[
            {"type": "Label", "name": "lbl_heading", "text": "Contact us", "x": 30, "y": 20, "width": 300, "height": 36, "font_size": 16, "bold": True},
            {"type": "Line Edit", "name": "txt_name", "placeholder": "Full name", "x": 30, "y": 70, "width": 460, "height": 34},
            {"type": "Line Edit", "name": "txt_email", "placeholder": "Email address", "x": 30, "y": 114, "width": 460, "height": 34},
            {"type": "Combo Box", "name": "cmb_subject", "items": ["General enquiry", "Support", "Feedback"], "x": 30, "y": 158, "width": 460, "height": 34},
            {"type": "Memo", "name": "txt_message", "placeholder": "Your message…", "x": 30, "y": 202, "width": 460, "height": 170},
            {"type": "Button", "name": "btn_send", "text": "Send message", "x": 340, "y": 390, "width": 150, "height": 38,
             "events": {"clicked": "self.send_message()"}},
        ], custom_methods='''    def send_message(self):
        if "@" not in self.txt_email.text():
            QMessageBox.warning(self, "Contact", "Please enter a valid email address.")
            return
        self.statusBar().showMessage("Message queued — thank you!", 4000)
'''),
        FormTemplate("Data Entry (CRUD)", "Record form with a table and Add / Delete actions", form={"title": "Records", "width": 760, "height": 480}, controls=[
            {"type": "Label", "name": "lbl_name", "text": "Name", "x": 24, "y": 24, "width": 80, "height": 28},
            {"type": "Line Edit", "name": "txt_name", "x": 110, "y": 24, "width": 220, "height": 30},
            {"type": "Label", "name": "lbl_qty", "text": "Quantity", "x": 350, "y": 24, "width": 80, "height": 28},
            {"type": "Spin Box", "name": "spn_qty", "x": 430, "y": 24, "width": 100, "height": 30, "maximum": 9999},
            {"type": "Button", "name": "btn_add", "text": "Add", "x": 550, "y": 22, "width": 90, "height": 34, "events": {"clicked": "self.add_record()"}},
            {"type": "Button", "name": "btn_delete", "text": "Delete", "x": 650, "y": 22, "width": 90, "height": 34, "events": {"clicked": "self.delete_record()"}},
            {"type": "Grid", "name": "tbl_records", "x": 24, "y": 74, "width": 716, "height": 360, "rows": 0, "columns": 2,
             "headers": ["Name", "Quantity"], "alternating": True},
        ], custom_methods='''    def add_record(self):
        name = self.txt_name.text().strip()
        if not name:
            return
        row = self.tbl_records.rowCount()
        self.tbl_records.insertRow(row)
        self.tbl_records.setItem(row, 0, QTableWidgetItem(name))
        self.tbl_records.setItem(row, 1, QTableWidgetItem(str(self.spn_qty.value())))
        self.txt_name.clear()

    def delete_record(self):
        row = self.tbl_records.currentRow()
        if row >= 0:
            self.tbl_records.removeRow(row)
'''),
        FormTemplate("Settings Panel", "Preferences with toggles, slider and theme choice", form={"title": "Settings", "width": 460, "height": 400}, controls=[
            {"type": "Group Box", "name": "grp_general", "title": "General", "x": 20, "y": 20, "width": 420, "height": 130},
            {"type": "Check Box", "name": "chk_startup", "text": "Launch at start-up", "x": 40, "y": 50, "width": 240, "height": 26},
            {"type": "Check Box", "name": "chk_updates", "text": "Check for updates", "x": 40, "y": 82, "width": 240, "height": 26, "checked": True},
            {"type": "Group Box", "name": "grp_look", "title": "Appearance", "x": 20, "y": 165, "width": 420, "height": 150},
            {"type": "Label", "name": "lbl_theme", "text": "Theme", "x": 40, "y": 198, "width": 100, "height": 26},
            {"type": "Combo Box", "name": "cmb_theme", "items": ["System", "Light", "Dark"], "x": 150, "y": 196, "width": 200, "height": 30},
            {"type": "Label", "name": "lbl_scale", "text": "Text size", "x": 40, "y": 246, "width": 100, "height": 26},
            {"type": "Slider", "name": "sld_scale", "x": 150, "y": 246, "width": 200, "height": 26, "minimum": 80, "maximum": 160, "value": 100},
            {"type": "Button", "name": "btn_save", "text": "Save", "x": 320, "y": 335, "width": 120, "height": 36,
             "events": {"clicked": "self.statusBar().showMessage('Settings saved', 3000)"}},
        ]),
        FormTemplate("Dashboard", "KPI tiles, progress and activity list", form={"title": "Dashboard", "width": 820, "height": 520}, controls=[
            {"type": "Label", "name": "lbl_head", "text": "Overview", "x": 24, "y": 16, "width": 300, "height": 40, "font_size": 18, "bold": True},
            {"type": "Rectangle", "name": "tile_users", "x": 24, "y": 70, "width": 240, "height": 110, "radius": 10, "background": "#eff6ff", "border_color": "#bfdbfe"},
            {"type": "LCD Number", "name": "lcd_users", "x": 40, "y": 100, "width": 200, "height": 60, "number": 1284},
            {"type": "Rectangle", "name": "tile_sales", "x": 288, "y": 70, "width": 240, "height": 110, "radius": 10, "background": "#ecfdf5", "border_color": "#a7f3d0"},
            {"type": "LCD Number", "name": "lcd_sales", "x": 304, "y": 100, "width": 200, "height": 60, "number": 342},
            {"type": "Rectangle", "name": "tile_goal", "x": 552, "y": 70, "width": 240, "height": 110, "radius": 10, "background": "#fff7ed", "border_color": "#fed7aa"},
            {"type": "Progress Bar", "name": "prg_goal", "x": 570, "y": 112, "width": 204, "height": 28, "value": 68},
            {"type": "List Box", "name": "lst_activity", "x": 24, "y": 200, "width": 504, "height": 290, "items": ["New signup: Asha", "Order #1042 shipped", "Report exported"]},
            {"type": "Calendar", "name": "cal_main", "x": 552, "y": 200, "width": 240, "height": 210},
        ]),
    ]


for _spec in _builtin_specs():
    REGISTRY.register(_spec)
for _tpl in _builtin_templates():
    REGISTRY.register_template(_tpl)
