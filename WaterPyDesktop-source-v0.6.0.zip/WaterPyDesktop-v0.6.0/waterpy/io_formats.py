"""Import and export formats (no main-window dependency, so they are unit-testable).

Imports
* Qt Designer ``.ui`` files            -> WaterPy layout
* WaterPy layout / template JSON        -> WaterPy layout
* CSV                                   -> grid headers + data, or list items

Exports
* WaterPy layout JSON (shareable form without source)
* static HTML/CSS mockup of the form
* project documentation (Markdown or HTML)
* PyQt6 source converted from the generated PySide6 source
"""
from __future__ import annotations

import csv
import html
import io
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

from . import __version__
from .registry import REGISTRY, valid_color

LAYOUT_FORMAT = "waterpy-layout"

# ---------------------------------------------------------------------------
# Qt Designer .ui import
# ---------------------------------------------------------------------------
UI_CLASS_MAP = {
    "QPushButton": "Button", "QToolButton": "Button", "QCommandLinkButton": "Command Link",
    "QLabel": "Label", "QLineEdit": "Line Edit", "QTextEdit": "Memo", "QPlainTextEdit": "Plain Text Edit",
    "QCheckBox": "Check Box", "QRadioButton": "Radio Button", "QComboBox": "Combo Box",
    "QFontComboBox": "Font Combo", "QListWidget": "List Box", "QListView": "List Box",
    "QTableWidget": "Grid", "QTableView": "Grid", "QTreeWidget": "Tree View", "QTreeView": "Tree View",
    "QSpinBox": "Spin Box", "QDoubleSpinBox": "Double Spin Box", "QSlider": "Slider", "QDial": "Dial",
    "QProgressBar": "Progress Bar", "QDateEdit": "Date Edit", "QTimeEdit": "Time Edit",
    "QDateTimeEdit": "Date Time Edit", "QCalendarWidget": "Calendar", "QGroupBox": "Group Box",
    "QTabWidget": "Tab", "QFrame": "Container", "QLCDNumber": "LCD Number", "QTextBrowser": "Web Browser",
    "QKeySequenceEdit": "Key Sequence", "QWebEngineView": "Web View", "QScrollBar": "Slider",
}
UI_PROP_MAP = {  # Designer property -> WaterPy key
    "text": "text", "placeholderText": "placeholder", "title": "title", "checked": "checked",
    "checkable": "checkable", "readOnly": "read_only", "minimum": "minimum", "maximum": "maximum",
    "value": "value", "toolTip": "tooltip", "wordWrap": "word_wrap", "description": "description",
    "rowCount": "rows", "columnCount": "columns", "decimals": "decimals", "singleStep": "single_step",
    "prefix": "prefix", "suffix": "suffix", "displayFormat": "display_format", "calendarPopup": "calendar_popup",
    "editable": "editable", "html": "html", "digitCount": "digits", "enabled": "enabled",
}
CONTAINER_CLASSES = {"QWidget", "QFrame", "QGroupBox", "QScrollArea", "QStackedWidget", "QSplitter", "QDockWidget"}


def _ui_value(prop: ET.Element):
    for child in prop:
        tag = child.tag
        if tag in ("string", "cstring"):
            return child.text or ""
        if tag == "bool":
            return (child.text or "").strip().lower() == "true"
        if tag == "number":
            return int(float(child.text or 0))
        if tag == "double":
            return float(child.text or 0)
        if tag == "enum":
            return (child.text or "").split("::")[-1]
        if tag == "set":
            return child.text or ""
        if tag == "rect":
            return tuple(int(float(child.findtext(k, "0"))) for k in ("x", "y", "width", "height"))
        if tag == "size":
            return (int(float(child.findtext("width", "0"))), int(float(child.findtext("height", "0"))))
        if tag == "font":
            return {"family": child.findtext("family", ""), "size": int(child.findtext("pointsize", "0") or 0),
                    "bold": child.findtext("bold", "false") == "true", "italic": child.findtext("italic", "false") == "true"}
    return None


def _props(elem: ET.Element) -> dict:
    return {p.get("name"): _ui_value(p) for p in elem.findall("property")}


def import_ui(path) -> tuple[dict, list[str]]:
    """Convert a Qt Designer .ui file into a WaterPy layout. Returns (layout, warnings).

    Widgets inside containers are flattened to absolute form coordinates.  Widgets managed
    by Qt layouts (no explicit geometry) are stacked vertically so nothing is lost.
    """
    root = ET.parse(str(path)).getroot()
    top = root.find("widget")
    if top is None:
        raise ValueError("Not a Qt Designer .ui file (no top-level widget)")
    warnings: list[str] = []
    tprops = _props(top)
    rect = tprops.get("geometry") or (0, 0, 900, 600)
    form = {"title": str(tprops.get("windowTitle") or root.findtext("class") or "Imported form"),
            "width": max(200, rect[2]), "height": max(150, rect[3])}
    controls: list[dict] = []
    auto_y = [16]
    used: set[str] = set()

    def unique(name):
        base = re.sub(r"\W+", "_", name or "widget").strip("_") or "widget"
        n, i = base, 1
        while n in used:
            i += 1
            n = f"{base}_{i}"
        used.add(n)
        return n

    def walk(elem, ox, oy, depth=0):
        for w in elem.findall("widget"):
            cls, name = w.get("class", ""), w.get("name", "")
            props = _props(w)
            geo = props.get("geometry")
            if geo:
                x, y, wd, ht = geo[0] + ox, geo[1] + oy, geo[2], geo[3]
            else:
                x, y, wd, ht = 16 + ox, auto_y[0], 220, 32
            if cls in ("QMenuBar", "QStatusBar", "QToolBar"):
                continue
            kind = UI_CLASS_MAP.get(cls)
            if cls == "QFrame" and props.get("frameShape") in ("HLine", "VLine"):
                kind = "Line"
            if cls == "QLineEdit" and props.get("echoMode") == "Password":
                kind = "Password Box"
            if kind and not (cls == "QWidget"):
                c = {"type": kind, "name": unique(name), "x": max(0, x), "y": max(0, y), "width": max(8, wd), "height": max(4, ht)}
                for ui_key, key in UI_PROP_MAP.items():
                    if ui_key in props and props[ui_key] is not None:
                        c[key] = props[ui_key]
                if kind == "Line":
                    c["orientation"] = "Vertical" if props.get("frameShape") == "VLine" else "Horizontal"
                if cls == "QSlider" and props.get("orientation") in ("Horizontal", "Vertical"):
                    c["orientation"] = props["orientation"]
                font = props.get("font")
                if isinstance(font, dict):
                    if font.get("family"):
                        c["font_family"] = font["family"]
                    if font.get("size"):
                        c["font_size"] = font["size"]
                    c["bold"], c["italic"] = font.get("bold", False), font.get("italic", False)
                css = props.get("styleSheet")
                if css:
                    c["stylesheet"] = str(css).replace("\n", " ")
                items = [_ui_value(p) for it in w.findall("item") for p in it.findall("property") if p.get("name") == "text"]
                if items and kind in ("Combo Box", "List Box"):
                    c["items"] = [str(i) for i in items]
                if kind == "Grid":
                    headers = [_ui_value(p) for col in w.findall("column") for p in col.findall("property") if p.get("name") == "text"]
                    if headers:
                        c["headers"], c["columns"] = [str(h) for h in headers], len(headers)
                if kind == "Tree View":
                    headers = [_ui_value(p) for col in w.findall("column") for p in col.findall("property") if p.get("name") == "text"]
                    if headers:
                        c["headers"] = [str(h) for h in headers]
                if kind == "Tab":
                    titles = []
                    for page in w.findall("widget"):
                        for attr in page.findall("attribute"):
                            if attr.get("name") == "title":
                                titles.append(attr.findtext("string") or "Tab")
                    c["tabs"] = titles or ["Tab 1"]
                controls.append(c)
                if not geo:
                    auto_y[0] += 40
            elif cls not in CONTAINER_CLASSES and cls not in ("QWidget",):
                warnings.append(f"{name}: unsupported widget class {cls} — skipped")
            # descend: tab pages sit below the tab bar; other containers keep their offset
            child_ox, child_oy = (x, y + (24 if cls == "QTabWidget" else 0)) if geo else (ox, oy)
            if cls == "QTabWidget":
                pages = w.findall("widget")
                if pages:
                    walk(pages[0], child_ox, child_oy, depth + 1)
                    if len(pages) > 1:
                        warnings.append(f"{name}: only the first tab page's widgets were imported")
            else:
                walk(w, child_ox, child_oy, depth + 1)
            for lay in w.findall("layout"):
                _walk_layout(lay, child_ox, child_oy, depth)

    def _walk_layout(lay, ox, oy, depth):
        for item in lay.findall("item"):
            holder = ET.Element("holder")
            for w in item.findall("widget"):
                holder.append(w)
            walk(holder, ox, oy, depth + 1)
            for sub in item.findall("layout"):
                _walk_layout(sub, ox, oy, depth)

    walk(top, 0, 0)
    for lay in top.findall("layout"):
        _walk_layout(lay, 0, 0, 0)
    if any(c["y"] + c["height"] > form["height"] for c in controls):
        form["height"] = max(form["height"], max(c["y"] + c["height"] for c in controls) + 16)
    if not controls:
        warnings.append("No supported widgets were found in the .ui file")
    return {"form": form, "controls": controls, "custom_methods": ""}, warnings


# ---------------------------------------------------------------------------
# WaterPy layout JSON
# ---------------------------------------------------------------------------
def export_layout(project: dict, path) -> None:
    data = {"format": LAYOUT_FORMAT, "version": 1, "generator": f"WaterPyDesktop {__version__}",
            "name": project.get("name", ""), "form": project.get("form", {}), "controls": project.get("controls", []),
            "custom_methods": project.get("custom_methods", "")}
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def import_layout(path) -> dict:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(data, list):
        data = {"controls": data}
    if data.get("format") not in (None, LAYOUT_FORMAT, "waterpy-project"):
        raise ValueError("Not a WaterPy layout or project file")
    return {"form": data.get("form") or {}, "controls": data.get("controls") or [],
            "custom_methods": data.get("custom_methods") or "", "name": data.get("name", "")}


# ---------------------------------------------------------------------------
# CSV
# ---------------------------------------------------------------------------
def read_csv(path, max_rows: int = 5000) -> list[list[str]]:
    raw = Path(path).read_bytes()
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    try:
        dialect = csv.Sniffer().sniff(text[:4096], delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
    rows = [r for r in csv.reader(io.StringIO(text), dialect)][:max_rows + 1]
    return [[c.strip() for c in r] for r in rows if any(c.strip() for c in r)]


def rows_to_csv_text(rows: list[list[str]]) -> str:
    buf = io.StringIO()
    csv.writer(buf, lineterminator="\n").writerows(rows)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# HTML mockup
# ---------------------------------------------------------------------------
def _e(v) -> str:
    return html.escape(str(v or ""))


def _mock_widget(c: dict) -> str:
    k = c["type"]
    text = _e(c.get("text"))
    ph = _e(c.get("placeholder"))
    if k in ("Button", "Toggle Button", "Command Link"):
        sub = f"<small>{_e(c.get('description'))}</small>" if k == "Command Link" else ""
        return f"<button>{text}{sub}</button>"
    if k in ("Line Edit", "Password Box"):
        t = "password" if k == "Password Box" or c.get("echo_mode") == "Password" else "text"
        return f'<input type="{t}" placeholder="{ph}" value="{text}">'
    if k in ("Memo", "Plain Text Edit"):
        return f'<textarea placeholder="{ph}">{text}</textarea>'
    if k in ("Check Box", "Toggle Switch"):
        return f'<label><input type="checkbox" {"checked" if c.get("checked") else ""}> {text}</label>'
    if k == "Radio Button":
        return f'<label><input type="radio" {"checked" if c.get("checked") else ""}> {text}</label>'
    if k in ("Combo Box", "Font Combo"):
        return "<select>" + "".join(f"<option>{_e(i)}</option>" for i in c.get("items") or ["Arial"]) + "</select>"
    if k == "List Box":
        return '<ul class="list">' + "".join(f"<li>{_e(i)}</li>" for i in c.get("items") or []) + "</ul>"
    if k in ("Spin Box", "Double Spin Box"):
        return f'<input type="number" value="{_e(c.get("value", 0))}">'
    if k in ("Slider", "Dial"):
        return f'<input type="range" min="{_e(c.get("minimum", 0))}" max="{_e(c.get("maximum", 100))}" value="{_e(c.get("value", 0))}">'
    if k == "Progress Bar":
        return f'<progress max="{_e(c.get("maximum", 100))}" value="{_e(c.get("value", 0))}"></progress>'
    if k == "Date Edit":
        return '<input type="date">'
    if k == "Time Edit":
        return '<input type="time">'
    if k == "Date Time Edit":
        return '<input type="datetime-local">'
    if k == "Grid":
        headers = c.get("headers") or []
        rows = []
        data = str(c.get("data") or "")
        if data.strip():
            rows = list(csv.reader(io.StringIO(data)))
        body = "".join("<tr>" + "".join(f"<td>{_e(v)}</td>" for v in r) + "</tr>" for r in rows[:50])
        return "<table><tr>" + "".join(f"<th>{_e(h)}</th>" for h in headers) + f"</tr>{body}</table>"
    if k == "Tree View":
        return '<ul class="list">' + "".join(f"<li>▸ {_e(i)}</li>" for i in c.get("items") or []) + "</ul>"
    if k == "Group Box":
        return f"<fieldset><legend>{_e(c.get('title'))}</legend></fieldset>"
    if k == "Tab":
        return '<div class="tabs">' + "".join(f"<span>{_e(t)}</span>" for t in c.get("tabs") or []) + "</div>"
    if k == "Hyperlink":
        return f'<a href="{_e(c.get("url"))}">{text}</a>'
    if k == "Web Browser":
        return f'<div class="html">{_e(c.get("html"))}</div>'
    if k == "LCD Number":
        return f'<div class="lcd">{_e(c.get("number"))}</div>'
    if k == "Star Rating":
        n, r = int(c.get("maximum", 5)), int(c.get("rating", 0))
        return '<div class="stars">' + "★" * r + "☆" * max(0, n - r) + "</div>"
    if k in ("Label", "Ellipse"):
        return f"<span>{text}</span>"
    if k == "Image":
        src = c.get("image_path")
        return f'<img src="{_e(src)}" alt="{text}">' if src else f'<div class="ph">{text or "Image"}</div>'
    return f'<div class="ph">{_e(k)}</div>'


def export_html(project: dict, path) -> None:
    form = project.get("form", {})
    w, h = int(form.get("width", 900)), int(form.get("height", 600))
    bg = valid_color(form.get("background")) or "#ffffff"
    parts = []
    for c in project.get("controls", []):
        spec = REGISTRY.get(c["type"])
        if spec is None or spec.non_visual:
            continue
        style = [f"left:{int(c.get('x', 0))}px", f"top:{int(c.get('y', 0))}px", f"width:{int(c.get('width', 100))}px",
                 f"height:{int(c.get('height', 30))}px"]
        if valid_color(c.get("foreground")):
            style.append(f"color:{c['foreground']}")
        if valid_color(c.get("background")):
            style.append(f"background:{c['background']}")
        if int(c.get("font_size") or 0):
            style.append(f"font-size:{int(c['font_size']) * 4 // 3}px")
        if c.get("bold"):
            style.append("font-weight:700")
        if c["type"] in ("Rectangle", "Card Panel", "Container"):
            radius = int(c.get("radius", 0) or 0)
            style.append(f"border:1px solid {valid_color(c.get('border_color')) or '#94a3b8'};border-radius:{radius}px")
        if c["type"] == "Ellipse":
            style.append("border:2px solid #64748b;border-radius:50%;display:flex;align-items:center;justify-content:center")
        if c["type"] == "Line":
            style.append("border-top:1px solid #64748b;height:0" if c.get("orientation") != "Vertical" else "border-left:1px solid #64748b;width:0")
        parts.append(f'<div class="w k-{_e(c["type"]).replace(" ", "-")}" title="{_e(c.get("name"))} ({_e(c["type"])})" '
                     f'style="{";".join(style)}">{_mock_widget(c)}</div>')
    doc = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>{_e(form.get('title'))} — mockup</title>
<style>
body{{font-family:"Segoe UI",system-ui,sans-serif;background:#e5e9f0;margin:0;padding:32px;}}
.win{{width:{w}px;margin:auto;box-shadow:0 12px 40px rgba(15,23,42,.18);border-radius:8px;overflow:hidden}}
.bar{{background:#1f2937;color:#f9fafb;padding:8px 12px;font-weight:600;font-size:13px}}
.form{{position:relative;width:{w}px;height:{h}px;background:{bg};font-size:13px}}
.w{{position:absolute;box-sizing:border-box;overflow:hidden}}
.w>button,.w>input,.w>select,.w>textarea,.w>progress,.w>table,.w>fieldset,.w>ul,.w>.tabs,.w>.html,.w>.ph,.w>img{{width:100%;height:100%;box-sizing:border-box}}
button{{border:1px solid #cbd5e1;border-radius:4px;background:#f8fafc;font:inherit;color:inherit}}
input,select,textarea{{border:1px solid #cbd5e1;border-radius:3px;padding:3px 6px;font:inherit;background:#fff}}
input[type=checkbox],input[type=radio]{{width:auto;height:auto}}
label{{display:flex;align-items:center;gap:6px;height:100%}}
table{{border-collapse:collapse;background:#fff;border:1px solid #cbd5e1}} th,td{{border:1px solid #e2e8f0;padding:3px 6px;text-align:left}} th{{background:#f1f5f9}}
.list{{list-style:none;margin:0;padding:2px;border:1px solid #cbd5e1;background:#fff}} .list li{{padding:2px 6px}}
fieldset{{border:1px solid #cbd5e1;border-radius:4px;margin:0}} .tabs span{{display:inline-block;padding:4px 12px;border:1px solid #cbd5e1;border-bottom:0;background:#f1f5f9;margin-right:2px}}
.tabs{{border-bottom:1px solid #cbd5e1}} .ph{{display:flex;align-items:center;justify-content:center;background:#f1f5f9;border:1px dashed #94a3b8;color:#64748b}}
.lcd{{font-family:monospace;font-size:28px;text-align:right;background:#111827;color:#a3e635;height:100%;padding:0 8px}}
.stars{{color:#f59e0b;font-size:22px}} .k-Label span{{display:flex;align-items:center;height:100%}} img{{object-fit:contain}}
footer{{text-align:center;color:#64748b;font-size:12px;margin-top:16px}}
</style></head><body>
<div class="win"><div class="bar">{_e(form.get('title'))}</div><div class="form">
{chr(10).join(parts)}
</div></div>
<footer>Static mockup exported by WaterPyDesktop {__version__} — not interactive.</footer>
</body></html>
"""
    Path(path).write_text(doc, encoding="utf-8")


# ---------------------------------------------------------------------------
# Documentation
# ---------------------------------------------------------------------------
def documentation_markdown(project: dict) -> str:
    form = project.get("form", {})
    lines = [f"# {project.get('name', 'Project')} — form documentation", "",
             f"*Window:* **{form.get('title', '')}** — {form.get('width')} × {form.get('height')} px  ",
             f"*Generated by:* WaterPyDesktop {__version__}", "", "## Controls", "",
             "| # | Name | Type | Qt class | Position | Size | Text / content |", "|---|---|---|---|---|---|---|"]
    events = []
    for i, c in enumerate(project.get("controls", []), 1):
        spec = REGISTRY.get(c["type"])
        content = c.get("text") or c.get("title") or c.get("placeholder") or ", ".join(c.get("items") or [])[:60]
        lines.append(f"| {i} | `{c['name']}` | {c['type']} | {spec.qt_class if spec else '?'} | "
                     f"{c.get('x')}, {c.get('y')} | {c.get('width', '')} × {c.get('height', '')} | {str(content).replace('|', '/')} |")
        for sig, code in (c.get("events") or {}).items():
            events.append((c["name"], sig, code))
    lines += ["", "## Event handlers", ""]
    if not events:
        lines.append("_No event handlers yet._")
    for name, sig, code in events:
        lines += [f"### `{name}.{sig}`", "", "```python", code.strip(), "```", ""]
    methods = (project.get("custom_methods") or "").strip()
    if methods:
        lines += ["## Helper methods", "", "```python", methods, "```", ""]
    order = form.get("tab_order") or []
    if order:
        lines += ["## Keyboard tab order", "", " → ".join(f"`{n}`" for n in order), ""]
    return "\n".join(lines) + "\n"


def export_documentation(project: dict, path) -> None:
    path = Path(path)
    md = documentation_markdown(project)
    if path.suffix.lower() in (".html", ".htm"):
        try:
            from PySide6.QtGui import QTextDocument
            doc = QTextDocument()
            doc.setMarkdown(md)
            body = doc.toHtml()
        except Exception:
            body = f"<pre>{_e(md)}</pre>"
        path.write_text(body, encoding="utf-8")
    else:
        path.write_text(md, encoding="utf-8")


# ---------------------------------------------------------------------------
# PyQt6 conversion
# ---------------------------------------------------------------------------
_RENAMES = {"Signal": "pyqtSignal", "Slot": "pyqtSlot", "Property": "pyqtProperty"}


def to_pyqt6(source: str) -> str:
    """Convert generated PySide6 source to PyQt6 (imports, Signal/Slot/Property names)."""
    lines = source.replace("PySide6", "PyQt6").split("\n")
    out, i = [], 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("from PyQt6.QtCore import"):
            chunk = line.split("import", 1)[1]
            while "(" in chunk and ")" not in chunk and i + 1 < len(lines):
                i += 1
                chunk += " " + lines[i]
            names = [n.strip() for n in chunk.replace("(", " ").replace(")", " ").split(",") if n.strip()]
            names = [f"{_RENAMES[n]} as {n}" if n in _RENAMES else n for n in names]
            out.append("from PyQt6.QtCore import " + ", ".join(names))
        else:
            out.append(line)
        i += 1
    return "\n".join(out).replace("generated by WaterPyDesktop", "generated by WaterPyDesktop (PyQt6 export)")
