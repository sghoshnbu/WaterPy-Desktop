"""Build settings, PyInstaller arguments and installer (setup.exe) scripts for user apps.

* ``pyinstaller_args`` turns the project's build settings into a PyInstaller command line
  (one-file / one-folder, console, icon, Windows version resource, hidden imports, assets).
* ``inno_script`` / ``nsis_script`` write installer scripts that package the PyInstaller
  output into a single ``setup.exe`` with Start-menu / desktop shortcuts and an uninstaller.
* ``find_inno`` / ``find_nsis`` locate the compilers (Inno Setup 6, NSIS 3).
"""
from __future__ import annotations

import os
import re
import shutil
import uuid
from pathlib import Path

DEFAULT_BUILD = {
    "app_name": "", "version": "1.0.0", "company": "", "description": "", "copyright": "",
    "icon": "", "onefile": False, "console": False, "hidden_imports": "", "extra_args": "",
}
DEFAULT_INSTALLER = {
    "publisher": "", "url": "", "app_id": "", "desktop_icon": True, "start_menu": True,
    "run_after": True, "license_file": "", "per_user": False, "compiler": "auto",
}


def safe_exe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "", name or "") or "WaterPyApp"


def version_tuple(version: str) -> tuple[int, int, int, int]:
    parts = [int(re.sub(r"\D", "", p) or 0) for p in str(version or "1.0.0").split(".")][:4]
    return tuple(parts + [0] * (4 - len(parts)))  # type: ignore[return-value]


def version_file_text(build: dict, exe_name: str) -> str:
    """PyInstaller ``--version-file`` content (Windows file properties)."""
    v = version_tuple(build.get("version"))
    def s(x):
        return str(x or "").replace("'", "’")
    return f"""VSVersionInfo(
  ffi=FixedFileInfo(filevers={v}, prodvers={v}, mask=0x3f, flags=0x0, OS=0x40004, fileType=0x1,
                    subtype=0x0, date=(0, 0)),
  kids=[
    StringFileInfo([StringTable('040904B0', [
      StringStruct('CompanyName', '{s(build.get("company"))}'),
      StringStruct('FileDescription', '{s(build.get("description") or build.get("app_name") or exe_name)}'),
      StringStruct('FileVersion', '{".".join(map(str, v))}'),
      StringStruct('InternalName', '{exe_name}'),
      StringStruct('LegalCopyright', '{s(build.get("copyright"))}'),
      StringStruct('OriginalFilename', '{exe_name}.exe'),
      StringStruct('ProductName', '{s(build.get("app_name") or exe_name)}'),
      StringStruct('ProductVersion', '{".".join(map(str, v))}')])]),
    VarFileInfo([VarStruct('Translation', [1033, 1200])])
  ]
)
"""


def pyinstaller_args(build: dict, base: Path, script: Path, project_name: str) -> tuple[list[str], str, Path]:
    """Return (args, exe_name, output_dir).  ``args`` excludes the interpreter."""
    b = {**DEFAULT_BUILD, **(build or {})}
    name = safe_exe_name(b["app_name"] or project_name)
    out = base / "build_output"
    out.mkdir(parents=True, exist_ok=True)
    args = ["-m", "PyInstaller", "--noconfirm", "--clean",
            "--onefile" if b["onefile"] else "--onedir",
            "--console" if b["console"] else "--windowed",
            "--name", name, "--distpath", str(out / "dist"), "--workpath", str(out / "work"), "--specpath", str(out)]
    assets = base / "assets"
    if assets.is_dir() and any(assets.iterdir()):
        args += ["--add-data", f"{assets}{os.pathsep}assets"]
    icon = base / b["icon"] if b["icon"] else base / "app.ico"
    if icon.is_file() and icon.suffix.lower() in (".ico", ".exe"):
        args += ["--icon", str(icon)]
    vfile = out / "version_info.txt"
    vfile.write_text(version_file_text(b, name), encoding="utf-8")
    args += ["--version-file", str(vfile)]
    for mod in re.split(r"[\s,;]+", b["hidden_imports"] or ""):
        if mod.strip():
            args += ["--hidden-import", mod.strip()]
    if b["extra_args"].strip():
        import shlex
        args += shlex.split(b["extra_args"], posix=os.name != "nt")
    return args, name, out / "dist"


# ---------------------------------------------------------------------------
# Installer scripts
# ---------------------------------------------------------------------------
def app_guid(installer: dict, name: str) -> str:
    gid = installer.get("app_id") or str(uuid.uuid5(uuid.NAMESPACE_DNS, f"waterpydesktop.{name}")).upper()
    return gid.strip("{}")


def inno_script(build: dict, installer: dict, dist: Path, exe_name: str, out_dir: Path) -> str:
    b, i = {**DEFAULT_BUILD, **build}, {**DEFAULT_INSTALLER, **installer}
    app = b["app_name"] or exe_name
    onefile = (dist / f"{exe_name}.exe").is_file()
    source = dist / f"{exe_name}.exe" if onefile else dist / exe_name
    files = (f'Source: "{source}"; DestDir: "{{app}}"; Flags: ignoreversion' if onefile else
             f'Source: "{source}\\*"; DestDir: "{{app}}"; Flags: ignoreversion recursesubdirs createallsubdirs')
    lic = f'LicenseFile={i["license_file"]}\n' if i["license_file"] else ""
    priv = "lowest" if i["per_user"] else "admin"
    icon = f"SetupIconFile={b['icon_abs']}\n" if b.get("icon_abs") else ""
    tasks = []
    if i["desktop_icon"]:
        tasks.append('Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"')
    icons = [f'Name: "{{group}}\\{app}"; Filename: "{{app}}\\{exe_name}.exe"',
             f'Name: "{{group}}\\Uninstall {app}"; Filename: "{{uninstallexe}}"'] if i["start_menu"] else []
    if i["desktop_icon"]:
        icons.append(f'Name: "{{autodesktop}}\\{app}"; Filename: "{{app}}\\{exe_name}.exe"; Tasks: desktopicon')
    run = (f'[Run]\nFilename: "{{app}}\\{exe_name}.exe"; Description: "{{cm:LaunchProgram,{app}}}"; '
           f'Flags: nowait postinstall skipifsilent\n') if i["run_after"] else ""
    return f"""; Inno Setup script generated by WaterPyDesktop
[Setup]
AppId={{{{{app_guid(i, exe_name)}}}
AppName={app}
AppVersion={b['version']}
AppPublisher={i['publisher'] or b['company']}
AppPublisherURL={i['url']}
DefaultDirName={{autopf}}\\{app}
DefaultGroupName={app}
UninstallDisplayIcon={{app}}\\{exe_name}.exe
OutputDir={out_dir}
OutputBaseFilename={exe_name}-{b['version']}-setup
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired={priv}
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesInstallIn64BitMode=x64compatible
{lic}{icon}
[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
{chr(10).join(tasks)}

[Files]
{files}

[Icons]
{chr(10).join(icons)}

{run}"""


def nsis_script(build: dict, installer: dict, dist: Path, exe_name: str, out_dir: Path) -> str:
    b, i = {**DEFAULT_BUILD, **build}, {**DEFAULT_INSTALLER, **installer}
    app = b["app_name"] or exe_name
    publisher = i["publisher"] or b["company"] or app
    onefile = (dist / f"{exe_name}.exe").is_file()
    source = (dist / f"{exe_name}.exe") if onefile else (dist / exe_name)
    files = f'File "{source}"' if onefile else f'File /r "{source}{os.sep}*.*"'
    v = ".".join(map(str, version_tuple(b["version"])))
    level = "user" if i["per_user"] else "admin"
    root = "HKCU" if i["per_user"] else "HKLM"
    instdir = "$LOCALAPPDATA\\Programs" if i["per_user"] else "$PROGRAMFILES64"
    lic = f'!insertmacro MUI_PAGE_LICENSE "{i["license_file"]}"\n' if i["license_file"] else ""
    icon = f'!define MUI_ICON "{b["icon_abs"]}"\n!define MUI_UNICON "{b["icon_abs"]}"\n' if b.get("icon_abs") else ""
    run = f'!define MUI_FINISHPAGE_RUN "$INSTDIR\\{exe_name}.exe"\n' if i["run_after"] else ""
    start = (f'  CreateDirectory "$SMPROGRAMS\\{app}"\n'
             f'  CreateShortCut "$SMPROGRAMS\\{app}\\{app}.lnk" "$INSTDIR\\{exe_name}.exe"\n'
             f'  CreateShortCut "$SMPROGRAMS\\{app}\\Uninstall {app}.lnk" "$INSTDIR\\Uninstall.exe"\n') if i["start_menu"] else ""
    desk = f'  CreateShortCut "$DESKTOP\\{app}.lnk" "$INSTDIR\\{exe_name}.exe"\n' if i["desktop_icon"] else ""
    key = f"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\{exe_name}"
    return f"""; NSIS script generated by WaterPyDesktop
Unicode true
!include "MUI2.nsh"
!include "x64.nsh"
Name "{app}"
OutFile "{out_dir}{os.sep}{exe_name}-{b['version']}-setup.exe"
InstallDir "{instdir}\\{app}"
InstallDirRegKey {root} "Software\\{exe_name}" "InstallDir"
RequestExecutionLevel {level}
SetCompressor /SOLID lzma
VIProductVersion "{v}"
VIAddVersionKey "ProductName" "{app}"
VIAddVersionKey "CompanyName" "{publisher}"
VIAddVersionKey "FileVersion" "{b['version']}"
VIAddVersionKey "ProductVersion" "{b['version']}"
VIAddVersionKey "FileDescription" "{app} Setup"
VIAddVersionKey "LegalCopyright" "{b['copyright'] or publisher}"
{icon}!define MUI_ABORTWARNING
{run}!insertmacro MUI_PAGE_WELCOME
{lic}!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

Section "Install"
  SetOutPath "$INSTDIR"
  {files}
  WriteUninstaller "$INSTDIR\\Uninstall.exe"
  WriteRegStr {root} "Software\\{exe_name}" "InstallDir" "$INSTDIR"
  WriteRegStr {root} "{key}" "DisplayName" "{app}"
  WriteRegStr {root} "{key}" "DisplayVersion" "{b['version']}"
  WriteRegStr {root} "{key}" "Publisher" "{publisher}"
  WriteRegStr {root} "{key}" "DisplayIcon" "$INSTDIR\\{exe_name}.exe"
  WriteRegStr {root} "{key}" "UninstallString" '"$INSTDIR\\Uninstall.exe"'
  WriteRegDWORD {root} "{key}" "NoModify" 1
  WriteRegDWORD {root} "{key}" "NoRepair" 1
{start}{desk}SectionEnd

Section "Uninstall"
  Delete "$DESKTOP\\{app}.lnk"
  RMDir /r "$SMPROGRAMS\\{app}"
  RMDir /r "$INSTDIR"
  DeleteRegKey {root} "{key}"
  DeleteRegKey {root} "Software\\{exe_name}"
SectionEnd
"""


def find_inno() -> str | None:
    candidates = [shutil.which("ISCC"), shutil.which("iscc")]
    for env in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"):
        root = os.environ.get(env)
        if root:
            candidates += [str(Path(root) / "Inno Setup 6" / "ISCC.exe"), str(Path(root) / "Programs" / "Inno Setup 6" / "ISCC.exe")]
    return next((c for c in candidates if c and Path(c).is_file()), None)


def find_nsis() -> str | None:
    candidates = [shutil.which("makensis")]
    for env in ("ProgramFiles(x86)", "ProgramFiles"):
        root = os.environ.get(env)
        if root:
            candidates.append(str(Path(root) / "NSIS" / "makensis.exe"))
    return next((c for c in candidates if c and Path(c).is_file()), None)
