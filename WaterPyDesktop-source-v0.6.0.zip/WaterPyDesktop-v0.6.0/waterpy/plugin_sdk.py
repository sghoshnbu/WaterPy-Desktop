"""WaterPyDesktop Plugin SDK (API 2.0).

A plugin is either a single ``.py`` file or a package folder with ``plugin.json``
and ``__init__.py``.  It exposes ``register(api)`` (and optionally
``unregister(api)``) and receives a :class:`HostAPI` instance::

    PLUGIN_ID = "hello"
    PLUGIN_NAME = "Hello"
    PLUGIN_VERSION = "1.0.0"
    PLUGIN_API_VERSION = "2.0"

    def register(api):
        api.add_menu_action("Say hello", lambda: api.notify("Hello!"))

Everything a plugin contributes through ``api`` is tracked and removed again when
the plugin is disabled or reloaded, so plugins can be developed with hot reload.
Plugins are trusted code: they run inside the IDE process with full permissions.

See PLUGIN_SDK.md for the complete reference.
"""
from __future__ import annotations

import json
import traceback
from pathlib import Path
from typing import Any, Callable

from .events import EVENTS
from .registry import REGISTRY, ComponentSpec, FormTemplate, PropertySpec  # re-exported for plugins

PLUGIN_API_VERSION = "2.0"
__all__ = ["HostAPI", "ComponentSpec", "PropertySpec", "FormTemplate", "PLUGIN_API_VERSION", "EVENTS",
           "add_menu_action", "notify", "add_designer_control"]


# ---------------------------------------------------------------------------
# v1 helpers (kept so plugins written for 0.4 keep working)
# ---------------------------------------------------------------------------
def add_menu_action(window, text: str, callback, menu_name: str = "Extensions"):
    api = getattr(window, "plugin_host", None)
    if api is not None:
        return api.menu(menu_name).addAction(text, callback)
    target = window.menuBar().addMenu(menu_name)
    action = target.addAction(text)
    action.triggered.connect(callback)
    return action


def notify(window, message: str, timeout_ms: int = 4000):
    bar = getattr(window, "statusBar", lambda: None)()
    if bar is not None:
        bar.showMessage(str(message), int(timeout_ms))


def add_designer_control(window, kind: str, properties: dict | None = None):
    canvas = getattr(window, "canvas", None)
    if canvas is None:
        raise RuntimeError("WaterPyDesktop host does not expose a designer canvas")
    return canvas.add_control(kind, data=dict(properties or {}))


# ---------------------------------------------------------------------------
class PluginSettings:
    """Small JSON key/value store private to one plugin (survives restarts)."""
    def __init__(self, path: Path):
        self.path = Path(path)
        try:
            self._data = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            self._data = {}

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def set(self, key: str, value: Any):
        self._data[key] = value
        self.save()

    def remove(self, key: str):
        self._data.pop(key, None)
        self.save()

    def all(self) -> dict:
        return dict(self._data)

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self._data, indent=2, ensure_ascii=False), encoding="utf-8")


class ProjectAPI:
    """Read and modify the open project without touching IDE internals."""
    def __init__(self, window):
        self._w = window

    @property
    def name(self) -> str:
        return self._w.project_name

    @property
    def directory(self) -> Path | None:
        return self._w.project_dir

    @property
    def form(self) -> dict:
        return dict(self._w.canvas.form_settings)

    def set_form(self, **values):
        self._w.canvas.apply_form_settings(**values)
        self._w.canvas.commit()

    def controls(self) -> list[dict]:
        return self._w.canvas.controls()

    def find(self, name: str) -> dict | None:
        c = self._w.canvas.find(name)
        return c.to_dict() if c else None

    def selected(self) -> dict | None:
        c = self._w.canvas.selected
        return c.to_dict() if c else None

    def selected_names(self) -> list[str]:
        return [c.objectName() for c in self._w.canvas.selection]

    def add_control(self, kind: str, **props) -> str | None:
        c = self._w.canvas.add_control(kind, data=props)
        return c.objectName() if c else None

    def update_control(self, name: str, **props) -> bool:
        c = self._w.canvas.find(name)
        if not c:
            return False
        c.set_props(**props)
        self._w.canvas.changed.emit()
        self._w.canvas.commit()
        return True

    def remove_control(self, name: str) -> bool:
        c = self._w.canvas.find(name)
        if c:
            self._w.canvas.delete_control(c)
        return bool(c)

    def load_layout(self, controls: list[dict], form: dict | None = None, custom_methods: str | None = None):
        self._w.apply_layout({"controls": controls, "form": form or {}, "custom_methods": custom_methods})

    @property
    def custom_methods(self) -> str:
        return self._w.custom_methods_code

    @custom_methods.setter
    def custom_methods(self, code: str):
        self._w.set_custom_methods(code)

    def get_source(self) -> str:
        return self._w.editor.toPlainText()

    def set_source(self, text: str):
        self._w.set_source(text, user_edit=True)

    def regenerate(self) -> str:
        return self._w.refresh_code(force=True)

    def save(self) -> bool:
        return self._w.save_project()

    def to_dict(self) -> dict:
        return self._w.project_data()


class HostAPI:
    """The object passed to ``register(api)``.  All contributions are tracked per plugin."""
    api_version = PLUGIN_API_VERSION

    def __init__(self, window, info):
        self.window = window
        self.info = info
        self.plugin_id: str = info.id
        self.plugin_dir: Path = info.path if info.path.is_dir() else info.path.parent
        self.project = ProjectAPI(window)
        self.settings = PluginSettings(window.plugins.user_folder / "_data" / f"{info.id}.json")
        self._actions, self._menus, self._docks, self._toolbar = [], [], [], []
        self._components, self._transforms, self._exporters, self._ai_actions, self._ai_providers = [], [], [], [], []
        self._context_actions = []

    # -- utilities -----------------------------------------------------------
    def safe(self, fn: Callable) -> Callable:
        """Wrap a callback so an exception is logged instead of crashing the IDE."""
        def wrapper(*args, **kwargs):
            try:
                return fn(*args, **kwargs)
            except Exception as exc:
                self.log(f"{exc}\n{traceback.format_exc(limit=4)}", "error")
        wrapper.__name__ = getattr(fn, "__name__", "callback")
        return wrapper

    def log(self, message: str, level: str = "info"):
        self.window.log(f"[{self.plugin_id}] {message}", level)

    def notify(self, message: str, timeout_ms: int = 4000):
        self.window.statusBar().showMessage(str(message), int(timeout_ms))

    # -- UI contributions ------------------------------------------------------
    def menu(self, title: str = "Extensions"):
        menu = self.window.plugin_menu(title)
        if menu not in self._menus:
            self._menus.append(menu)
        return menu

    def add_menu_action(self, text: str, callback: Callable, menu: str = "Extensions",
                        shortcut: str | None = None, tooltip: str = ""):
        action = self.menu(menu).addAction(text)
        action.triggered.connect(lambda checked=False: self.safe(callback)())
        if shortcut:
            action.setShortcut(shortcut)
        if tooltip:
            action.setToolTip(tooltip)
            action.setStatusTip(tooltip)
        self._actions.append(action)
        return action

    def add_toolbar_action(self, text: str, callback: Callable, tooltip: str = "", icon=None):
        bar = self.window.plugin_toolbar()
        action = bar.addAction(text)
        if icon is not None:
            from PySide6.QtGui import QIcon
            action.setIcon(icon if isinstance(icon, QIcon) else QIcon(str(icon)))
        action.setToolTip(tooltip or text)
        action.triggered.connect(lambda checked=False: self.safe(callback)())
        bar.setVisible(True)
        self._toolbar.append(action)
        return action

    def add_dock_panel(self, title: str, widget, area: str = "right"):
        from PySide6.QtCore import Qt
        from PySide6.QtWidgets import QDockWidget
        dock = QDockWidget(title, self.window)
        dock.setObjectName(f"plugin_{self.plugin_id}_{len(self._docks)}")
        dock.setWidget(widget)
        areas = {"left": Qt.DockWidgetArea.LeftDockWidgetArea, "right": Qt.DockWidgetArea.RightDockWidgetArea,
                 "bottom": Qt.DockWidgetArea.BottomDockWidgetArea, "top": Qt.DockWidgetArea.TopDockWidgetArea}
        self.window.addDockWidget(areas.get(area, Qt.DockWidgetArea.RightDockWidgetArea), dock)
        anchor = {"right": self.window.right_dock, "left": self.window.left_dock,
                  "bottom": self.window.console_dock}.get(area)
        if anchor is not None and not anchor.isFloating():
            self.window.tabifyDockWidget(anchor, dock)
            anchor.raise_()
        self.window.view_menu.addAction(dock.toggleViewAction())
        self._docks.append(dock)
        return dock

    def add_context_action(self, text: str, callback: Callable[[list], None]):
        """Add an entry to the designer's right-click menu; ``callback(selected_names)``."""
        from PySide6.QtGui import QAction
        action = QAction(text, self.window)
        action.triggered.connect(lambda checked=False: self.safe(callback)(self.project.selected_names()))
        self.window.canvas.context_actions.append(action)
        self._context_actions.append(action)
        return action

    # -- designer / codegen contributions ----------------------------------
    def register_component(self, spec: ComponentSpec, replace: bool = False) -> ComponentSpec:
        if spec.category in ("", None):
            spec.category = "Plugins"
        REGISTRY.register(spec, source=self.plugin_id, replace=replace)
        self._components.append(spec.kind)
        return spec

    def register_template(self, name: str, controls: list, description: str = "", custom_methods: str = "",
                          form: dict | None = None, category: str | None = None):
        return REGISTRY.register_template(FormTemplate(name, description, list(controls), custom_methods,
                                                       dict(form or {}), category or self.info.name), source=self.plugin_id)

    def register_snippet(self, snippet_id: str, code: str, imports: dict | None = None):
        """Register module-level helper code that components can request via ``snippets=(id,)``."""
        REGISTRY.register_snippet(snippet_id, code, imports)

    def register_code_transform(self, fn: Callable[[str, dict], str]):
        """``fn(source, project) -> source`` runs after every code generation."""
        self.window.code_transforms.append((self.plugin_id, fn))
        self._transforms.append(fn)
        return fn

    def register_exporter(self, name: str, file_filter: str, fn: Callable[[dict, Path], None]):
        """Adds File → Export → <name>.  ``fn(project_dict, target_path)`` writes the file."""
        self.window.exporters.append((self.plugin_id, name, file_filter, fn))
        self._exporters.append(name)
        self.window.rebuild_export_menu()

    def register_ai_action(self, label: str, prompt: str, mode: str = "chat", tooltip: str = ""):
        """Adds a one-click prompt to the AI Assistant panel.  ``{selected}``, ``{project}``
        and ``{source}`` placeholders are filled in automatically."""
        self.window.ai_panel.add_quick_action(label, prompt, mode, tooltip, owner=self.plugin_id)
        self._ai_actions.append(label)

    def register_ai_provider(self, provider):
        """Register an extra AI back-end (subclass of ``waterpy.ai.providers.Provider``)."""
        from .ai.providers import register_provider
        register_provider(provider)
        self._ai_providers.append(provider.id)

    # -- events & AI -------------------------------------------------------------
    def on(self, event: str, callback: Callable):
        if event not in EVENTS:
            self.log(f"subscribing to unknown event '{event}'", "warning")
        return self.window.events.subscribe(event, callback, owner=self.plugin_id)

    def open_ai_panel(self, mode: str = "chat", prompt: str = "", send: bool = False):
        """Show the AI Assistant with a task mode selected and (optionally) send ``prompt``."""
        self.window.focus_ai(mode, prompt, send=send)

    def ask_ai(self, prompt: str, callback: Callable[[str], None], mode: str = "chat",
               on_error: Callable[[str], None] | None = None, include_context: bool = True):
        """Send a prompt to the configured AI provider; ``callback(text)`` runs on the GUI thread."""
        self.window.ai_panel.run_background(prompt, mode, self.safe(callback),
                                            self.safe(on_error) if on_error else (lambda e: self.log(e, "error")),
                                            include_context=include_context)

    # -- lifecycle -----------------------------------------------------------------
    def _dispose(self):
        from .ai.providers import unregister_provider
        self.window.events.unsubscribe_owner(self.plugin_id)
        REGISTRY.unregister_source(self.plugin_id)
        self.window.code_transforms[:] = [t for t in self.window.code_transforms if t[0] != self.plugin_id]
        self.window.exporters[:] = [e for e in self.window.exporters if e[0] != self.plugin_id]
        self.window.rebuild_export_menu()
        self.window.ai_panel.remove_quick_actions(self.plugin_id)
        for pid in self._ai_providers:
            unregister_provider(pid)
        for action in self._actions:
            for menu in self._menus:
                menu.removeAction(action)
            action.deleteLater()
        for menu in self._menus:
            self.window.prune_plugin_menu(menu)
        bar = self.window.plugin_toolbar()
        for action in self._toolbar:
            bar.removeAction(action)
        bar.setVisible(bool(bar.actions()))
        for dock in self._docks:
            self.window.view_menu.removeAction(dock.toggleViewAction())
            self.window.removeDockWidget(dock)
            dock.deleteLater()
        for action in self._context_actions:
            if action in self.window.canvas.context_actions:
                self.window.canvas.context_actions.remove(action)
        self._actions.clear(); self._docks.clear(); self._toolbar.clear()

    def __getattr__(self, name):
        # Convenience for v1-style code: api.menuBar(), api.statusBar(), api.canvas …
        return getattr(self.window, name)
