"""Python code editor widget: line numbers, syntax highlighting, smart indentation."""
from __future__ import annotations

import keyword
import re

from PySide6.QtCore import QRect, QRegularExpression, QSize, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QSyntaxHighlighter, QTextCharFormat, QTextCursor, QTextFormat
from PySide6.QtWidgets import QPlainTextEdit, QTextEdit, QWidget

LIGHT = {"bg": "#ffffff", "fg": "#1f2937", "gutter": "#f3f4f6", "gutter_fg": "#9ca3af", "line": "#f1f5ff",
         "keyword": "#7c3aed", "builtin": "#0369a1", "string": "#15803d", "comment": "#6b7280", "number": "#c2410c",
         "def": "#1d4ed8", "decorator": "#a16207", "self": "#be185d", "qt": "#0f766e"}
DARK = {"bg": "#1b1f27", "fg": "#e5e7eb", "gutter": "#1f2430", "gutter_fg": "#5b6475", "line": "#232a36",
        "keyword": "#c792ea", "builtin": "#82aaff", "string": "#c3e88d", "comment": "#7f8c98", "number": "#f78c6c",
        "def": "#82aaff", "decorator": "#ffcb6b", "self": "#f07178", "qt": "#89ddff"}


def _fmt(color, bold=False, italic=False):
    f = QTextCharFormat()
    f.setForeground(QColor(color))
    if bold:
        f.setFontWeight(QFont.Weight.Bold)
    f.setFontItalic(italic)
    return f


class PythonHighlighter(QSyntaxHighlighter):
    def __init__(self, document, palette=LIGHT):
        super().__init__(document)
        self.set_palette(palette)

    def set_palette(self, pal):
        builtins = r"\b(print|len|range|str|int|float|bool|list|dict|set|tuple|open|super|isinstance|enumerate|zip|min|max|sum|sorted|any|all|round|abs|getattr|setattr|hasattr)\b"
        self.rules = [
            (QRegularExpression(r"\b(" + "|".join(keyword.kwlist) + r")\b"), _fmt(pal["keyword"], bold=True)),
            (QRegularExpression(builtins), _fmt(pal["builtin"])),
            (QRegularExpression(r"\bQ[A-Za-z]+\b|\bQt\b"), _fmt(pal["qt"])),
            (QRegularExpression(r"\bself\b"), _fmt(pal["self"], italic=True)),
            (QRegularExpression(r"\b[0-9]+(\.[0-9]+)?\b"), _fmt(pal["number"])),
            (QRegularExpression(r"^\s*@[\w.]+"), _fmt(pal["decorator"])),
            (QRegularExpression(r"\b(?:def|class)\s+(\w+)"), _fmt(pal["def"], bold=True)),
            (QRegularExpression(r"(?:[rbfu]{0,2})'[^'\\\n]*(\\.[^'\\\n]*)*'"), _fmt(pal["string"])),
            (QRegularExpression(r'(?:[rbfu]{0,2})"[^"\\\n]*(\\.[^"\\\n]*)*"'), _fmt(pal["string"])),
            (QRegularExpression(r"#[^\n]*"), _fmt(pal["comment"], italic=True)),
        ]
        self.tri = _fmt(pal["string"])
        self.rehighlight()

    def highlightBlock(self, text):
        for regex, fmt in self.rules:
            it = regex.globalMatch(text)
            while it.hasNext():
                m = it.next()
                group = 1 if regex.pattern().startswith(r"\b(?:def") else 0
                self.setFormat(m.capturedStart(group), m.capturedLength(group), fmt)
        # triple-quoted strings spanning lines
        self.setCurrentBlockState(0)
        prev = self.previousBlockState()
        if prev in (1, 2):
            delim, start, search_from = ('"""' if prev == 1 else "'''"), 0, 0
        else:
            m = re.search(r'("""|\'\'\')', text)
            if not m:
                return
            delim, start, search_from = m.group(1), m.start(), m.start() + 3
        while True:
            end = text.find(delim, search_from)
            if end == -1:
                self.setCurrentBlockState(1 if delim == '"""' else 2)
                self.setFormat(start, len(text) - start, self.tri)
                return
            self.setFormat(start, end + 3 - start, self.tri)
            m = re.search(r'("""|\'\'\')', text[end + 3:])
            if not m:
                return
            delim, start = m.group(1), end + 3 + m.start()
            search_from = start + 3


class _Gutter(QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self):
        return QSize(self.editor.gutter_width(), 0)

    def paintEvent(self, event):
        self.editor.paint_gutter(event)


class CodeEditor(QPlainTextEdit):
    def __init__(self, parent=None, dark=False):
        super().__init__(parent)
        font = QFont("Cascadia Code")
        font.setStyleHint(QFont.StyleHint.Monospace)
        if not font.exactMatch():
            font = QFont("Consolas")
            font.setStyleHint(QFont.StyleHint.Monospace)
        font.setPointSize(10)
        self.setFont(font)
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.setTabStopDistance(self.fontMetrics().horizontalAdvance(" ") * 4)
        self.gutter = _Gutter(self)
        self.highlighter = PythonHighlighter(self.document())
        self.blockCountChanged.connect(lambda _: self.setViewportMargins(self.gutter_width(), 0, 0, 0))
        self.updateRequest.connect(self._update_gutter)
        self.cursorPositionChanged.connect(self._highlight_line)
        self.set_dark(dark)
        self.setViewportMargins(self.gutter_width(), 0, 0, 0)

    def set_dark(self, dark: bool):
        self.pal = DARK if dark else LIGHT
        self.highlighter.set_palette(self.pal)
        self.setStyleSheet(f"QPlainTextEdit {{ background:{self.pal['bg']}; color:{self.pal['fg']}; border:none; }}")
        self._highlight_line()
        self.gutter.update()

    def set_font_size(self, size: int):
        f = self.font()
        f.setPointSize(max(6, int(size)))
        self.setFont(f)
        self.setTabStopDistance(self.fontMetrics().horizontalAdvance(" ") * 4)
        self.setViewportMargins(self.gutter_width(), 0, 0, 0)

    def gutter_width(self):
        digits = max(3, len(str(self.blockCount())))
        return 14 + self.fontMetrics().horizontalAdvance("9") * digits

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.gutter.setGeometry(QRect(cr.left(), cr.top(), self.gutter_width(), cr.height()))

    def _update_gutter(self, rect, dy):
        if dy:
            self.gutter.scroll(0, dy)
        else:
            self.gutter.update(0, rect.y(), self.gutter.width(), rect.height())

    def paint_gutter(self, event):
        painter = QPainter(self.gutter)
        painter.fillRect(event.rect(), QColor(self.pal["gutter"]))
        block = self.firstVisibleBlock()
        number = block.blockNumber()
        top = round(self.blockBoundingGeometry(block).translated(self.contentOffset()).top())
        bottom = top + round(self.blockBoundingRect(block).height())
        current = self.textCursor().blockNumber()
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                painter.setPen(QColor(self.pal["fg"] if number == current else self.pal["gutter_fg"]))
                painter.drawText(0, top, self.gutter.width() - 6, self.fontMetrics().height(),
                                 Qt.AlignmentFlag.AlignRight, str(number + 1))
            block = block.next()
            top = bottom
            bottom = top + round(self.blockBoundingRect(block).height())
            number += 1
        painter.end()

    def _highlight_line(self):
        sel = QTextEdit.ExtraSelection()
        sel.format.setBackground(QColor(self.pal["line"]))
        sel.format.setProperty(QTextFormat.Property.FullWidthSelection, True)
        sel.cursor = self.textCursor()
        sel.cursor.clearSelection()
        self.setExtraSelections([sel])

    def go_to_line(self, line: int):
        block = self.document().findBlockByLineNumber(max(0, line - 1))
        cursor = QTextCursor(block)
        self.setTextCursor(cursor)
        self.centerCursor()
        self.setFocus()

    def keyPressEvent(self, event):
        key = event.key()
        if key == Qt.Key.Key_Tab and not event.modifiers():
            cursor = self.textCursor()
            if cursor.hasSelection():
                self._indent_selection(+1)
            else:
                self.insertPlainText("    ")
            return
        if key == Qt.Key.Key_Backtab:
            self._indent_selection(-1)
            return
        if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            line = self.textCursor().block().text()
            indent = re.match(r"\s*", line).group(0)
            if line.rstrip().endswith(":"):
                indent += "    "
            super().keyPressEvent(event)
            self.insertPlainText(indent)
            return
        if key == Qt.Key.Key_Slash and event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self._toggle_comment()
            return
        super().keyPressEvent(event)

    def _selected_blocks(self):
        cursor = self.textCursor()
        start = self.document().findBlock(cursor.selectionStart())
        end = self.document().findBlock(cursor.selectionEnd())
        blocks, b = [], start
        while b.isValid():
            blocks.append(b)
            if b == end:
                break
            b = b.next()
        return blocks

    def _indent_selection(self, direction):
        cursor = self.textCursor()
        cursor.beginEditBlock()
        for block in self._selected_blocks():
            c = QTextCursor(block)
            if direction > 0:
                c.insertText("    ")
            else:
                text = block.text()
                n = len(text) - len(text.lstrip(" "))
                for _ in range(min(4, n)):
                    c.deleteChar()
        cursor.endEditBlock()

    def _toggle_comment(self):
        blocks = self._selected_blocks()
        cursor = self.textCursor()
        cursor.beginEditBlock()
        uncomment = all(b.text().lstrip().startswith("#") for b in blocks if b.text().strip())
        for block in blocks:
            text = block.text()
            if not text.strip():
                continue
            c = QTextCursor(block)
            pos = len(text) - len(text.lstrip())
            c.setPosition(block.position() + pos)
            if uncomment:
                n = 2 if text.lstrip().startswith("# ") else 1
                for _ in range(n):
                    c.deleteChar()
            else:
                c.insertText("# ")
        cursor.endEditBlock()


# ---------------------------------------------------------------------------
# Find / replace bar and code outline
# ---------------------------------------------------------------------------
from PySide6.QtCore import Signal  # noqa: E402
from PySide6.QtGui import QTextDocument  # noqa: E402
from PySide6.QtWidgets import QCheckBox, QComboBox, QHBoxLayout, QLabel, QLineEdit, QPushButton, QToolButton  # noqa: E402


class FindBar(QWidget):
    """Incremental find / replace for a CodeEditor (Ctrl+F, Ctrl+H, F3, Shift+F3, Esc)."""

    def __init__(self, editor: CodeEditor, parent=None):
        super().__init__(parent)
        self.editor = editor
        lay = QHBoxLayout(self)
        lay.setContentsMargins(6, 3, 6, 3)
        lay.setSpacing(4)
        self.find = QLineEdit()
        self.find.setPlaceholderText("Find")
        self.find.setClearButtonEnabled(True)
        self.replace = QLineEdit()
        self.replace.setPlaceholderText("Replace with")
        self.case = QCheckBox("Aa")
        self.case.setToolTip("Match case")
        self.word = QCheckBox("Word")
        self.word.setToolTip("Whole words")
        self.regex = QCheckBox(".*")
        self.regex.setToolTip("Regular expression")
        self.status = QLabel("")
        self.status.setMinimumWidth(80)
        prev_b, next_b = QToolButton(), QToolButton()
        prev_b.setText("▲")
        next_b.setText("▼")
        prev_b.clicked.connect(lambda: self.find_next(backward=True))
        next_b.clicked.connect(lambda: self.find_next())
        rep = QPushButton("Replace")
        rep.clicked.connect(self.replace_one)
        rep_all = QPushButton("Replace all")
        rep_all.clicked.connect(self.replace_all)
        close = QToolButton()
        close.setText("✕")
        close.clicked.connect(self.hide)
        for w in (self.find, prev_b, next_b, self.case, self.word, self.regex, self.replace, rep, rep_all, self.status, close):
            lay.addWidget(w)
        lay.setStretch(0, 2)
        lay.setStretch(6, 2)
        self.find.returnPressed.connect(self.find_next)
        self.find.textChanged.connect(lambda: self.find_next(from_start=True))
        self.replace.returnPressed.connect(self.replace_one)
        self.hide()

    def open(self, replace=False):
        cursor = self.editor.textCursor()
        if cursor.hasSelection() and " " not in cursor.selectedText():
            self.find.setText(cursor.selectedText())
        self.replace.setVisible(True)
        self.show()
        (self.replace if replace and self.find.text() else self.find).setFocus()
        self.find.selectAll()

    def _flags(self, backward=False):
        f = QTextDocument.FindFlag(0)
        if self.case.isChecked():
            f |= QTextDocument.FindFlag.FindCaseSensitively
        if self.word.isChecked():
            f |= QTextDocument.FindFlag.FindWholeWords
        if backward:
            f |= QTextDocument.FindFlag.FindBackward
        return f

    def _pattern(self):
        text = self.find.text()
        if self.regex.isChecked():
            rx = QRegularExpression(text)
            if not self.case.isChecked():
                rx.setPatternOptions(QRegularExpression.PatternOption.CaseInsensitiveOption)
            return rx if rx.isValid() else None
        return text

    def count(self) -> int:
        text, pat = self.editor.toPlainText(), self.find.text()
        if not pat:
            return 0
        if self.regex.isChecked():
            try:
                return len(re.findall(pat, text, 0 if self.case.isChecked() else re.I))
            except re.error:
                return 0
        if self.word.isChecked():
            return len(re.findall(r"\b" + re.escape(pat) + r"\b", text, 0 if self.case.isChecked() else re.I))
        return text.count(pat) if self.case.isChecked() else text.lower().count(pat.lower())

    def find_next(self, backward=False, from_start=False):
        pat = self._pattern()
        if not self.find.text() or pat is None:
            self.status.setText("" if pat is not None else "bad regex")
            return False
        doc = self.editor.document()
        cursor = self.editor.textCursor()
        if from_start:
            cursor.setPosition(cursor.selectionStart())
        found = doc.find(pat, cursor, self._flags(backward))
        if found.isNull():  # wrap around
            start = QTextCursor(doc)
            if backward:
                start.movePosition(QTextCursor.MoveOperation.End)
            found = doc.find(pat, start, self._flags(backward))
        n = self.count()
        if found.isNull():
            self.status.setText("no matches")
            return False
        self.editor.setTextCursor(found)
        self.status.setText(f"{n} match{'es' if n != 1 else ''}")
        return True

    def replace_one(self):
        cursor = self.editor.textCursor()
        if cursor.hasSelection():
            cursor.insertText(self._replacement(cursor.selectedText()))
        self.find_next()

    def _replacement(self, matched):
        if self.regex.isChecked():
            try:
                return re.sub(self.find.text(), self.replace.text(), matched, count=1, flags=0 if self.case.isChecked() else re.I)
            except re.error:
                return self.replace.text()
        return self.replace.text()

    def replace_all(self):
        text, pat, rep = self.editor.toPlainText(), self.find.text(), self.replace.text()
        if not pat:
            return
        flags = 0 if self.case.isChecked() else re.I
        try:
            if self.regex.isChecked():
                new, n = re.subn(pat, rep, text, flags=flags)
            else:
                expr = re.escape(pat)
                if self.word.isChecked():
                    expr = r"\b" + expr + r"\b"
                new, n = re.subn(expr, lambda m: rep, text, flags=flags)
        except re.error as exc:
            self.status.setText(f"regex: {exc}")
            return
        if n:
            cursor = QTextCursor(self.editor.document())
            cursor.beginEditBlock()
            cursor.select(QTextCursor.SelectionType.Document)
            cursor.insertText(new)
            cursor.endEditBlock()
        self.status.setText(f"replaced {n}")

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.hide()
            self.editor.setFocus()
            return
        super().keyPressEvent(event)


class OutlineCombo(QComboBox):
    """Jump list of classes, methods and functions in the editor."""
    jumped = Signal(int)

    def __init__(self, editor: CodeEditor, parent=None):
        super().__init__(parent)
        self.editor = editor
        self.setMinimumWidth(260)
        self.setToolTip("Go to class / method (Ctrl+Shift+O)")
        self.activated.connect(self._go)
        self._timer = None

    def refresh(self):
        current = self.currentText()
        self.blockSignals(True)
        self.clear()
        self.addItem("⌕ Go to symbol…", 0)
        for i, line in enumerate(self.editor.toPlainText().splitlines(), 1):
            m = re.match(r"^(\s*)(class|def)\s+(\w+)", line)
            if m:
                indent = "    " * (len(m.group(1)) // 4)
                icon = "◆" if m.group(2) == "class" else "ƒ"
                self.addItem(f"{indent}{icon} {m.group(3)}", i)
        idx = self.findText(current)
        self.setCurrentIndex(max(0, idx))
        self.blockSignals(False)

    def showPopup(self):
        self.refresh()
        super().showPopup()

    def _go(self, index):
        line = self.itemData(index)
        if line:
            self.editor.go_to_line(int(line))
            self.jumped.emit(int(line))
