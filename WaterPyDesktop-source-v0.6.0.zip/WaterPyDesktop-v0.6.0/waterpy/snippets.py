"""Ready-to-insert code snippets for event handlers and helper methods.

``{control}`` is replaced with the selected control's attribute name (``self.<name>``)
when the snippet is inserted; everything else is plain PySide6 code.  Any ``Q…`` class
used here is imported automatically by the code generator.
"""
from __future__ import annotations

SNIPPETS: dict[str, list[tuple[str, str]]] = {
    "Dialogs": [
        ("Information message", 'QMessageBox.information(self, "Information", "Operation completed successfully.")'),
        ("Warning message", 'QMessageBox.warning(self, "Warning", "Please check your input.")'),
        ("Yes / No question", 'answer = QMessageBox.question(self, "Confirm", "Do you want to continue?")\n'
                              'if answer == QMessageBox.StandardButton.Yes:\n    pass  # continue here'),
        ("Ask for text", 'text, ok = QInputDialog.getText(self, "Input", "Enter a value:")\n'
                         'if ok and text.strip():\n    self.statusBar().showMessage(f"You entered: {text}", 3000)'),
        ("Open file dialog", 'path, _ = QFileDialog.getOpenFileName(self, "Open file", "", "All files (*.*)")\n'
                             'if path:\n    self.statusBar().showMessage(path, 3000)'),
        ("Save file dialog", 'path, _ = QFileDialog.getSaveFileName(self, "Save file", "untitled.txt", "Text files (*.txt)")\n'
                             'if path:\n    pass  # write the file here'),
        ("Choose folder", 'folder = QFileDialog.getExistingDirectory(self, "Choose folder")\nif folder:\n    print(folder)'),
        ("Choose colour", 'colour = QColorDialog.getColor(parent=self)\nif colour.isValid():\n'
                          '    {control}.setStyleSheet(f"background-color: {colour.name()};")'),
    ],
    "Files": [
        ("Read text file into control", 'path, _ = QFileDialog.getOpenFileName(self, "Open", "", "Text (*.txt *.md *.py);;All (*.*)")\n'
                                        'if path:\n    with open(path, encoding="utf-8") as fh:\n        {control}.setPlainText(fh.read())'),
        ("Save control text to file", 'path, _ = QFileDialog.getSaveFileName(self, "Save", "notes.txt", "Text (*.txt)")\n'
                                      'if path:\n    with open(path, "w", encoding="utf-8") as fh:\n        fh.write({control}.toPlainText())'),
        ("Load CSV into grid", 'import csv\npath, _ = QFileDialog.getOpenFileName(self, "Open CSV", "", "CSV (*.csv)")\n'
                               'if path:\n    with open(path, newline="", encoding="utf-8-sig") as fh:\n        rows = list(csv.reader(fh))\n'
                               '    if rows:\n        {control}.setColumnCount(len(rows[0]))\n        {control}.setHorizontalHeaderLabels(rows[0])\n'
                               '        {control}.setRowCount(len(rows) - 1)\n        for r, values in enumerate(rows[1:]):\n'
                               '            for c, value in enumerate(values):\n                {control}.setItem(r, c, QTableWidgetItem(value))'),
        ("Export grid to CSV", 'import csv\npath, _ = QFileDialog.getSaveFileName(self, "Export CSV", "data.csv", "CSV (*.csv)")\n'
                               'if path:\n    with open(path, "w", newline="", encoding="utf-8") as fh:\n        writer = csv.writer(fh)\n'
                               '        writer.writerow([{control}.horizontalHeaderItem(c).text() if {control}.horizontalHeaderItem(c) else ""\n'
                               '                         for c in range({control}.columnCount())])\n'
                               '        for r in range({control}.rowCount()):\n'
                               '            writer.writerow([{control}.item(r, c).text() if {control}.item(r, c) else ""\n'
                               '                             for c in range({control}.columnCount())])'),
    ],
    "Database (SQLite)": [
        ("Create table", 'import sqlite3\nwith sqlite3.connect("data.db") as db:\n'
                         '    db.execute("CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY, name TEXT, qty INTEGER)")'),
        ("Insert row", 'import sqlite3\nwith sqlite3.connect("data.db") as db:\n'
                       '    db.execute("INSERT INTO items (name, qty) VALUES (?, ?)", ("Book", 1))'),
        ("Query into grid", 'import sqlite3\nwith sqlite3.connect("data.db") as db:\n    cur = db.execute("SELECT * FROM items")\n'
                            '    headers = [d[0] for d in cur.description]\n    rows = cur.fetchall()\n'
                            '{control}.setColumnCount(len(headers))\n{control}.setHorizontalHeaderLabels(headers)\n'
                            '{control}.setRowCount(len(rows))\nfor r, values in enumerate(rows):\n'
                            '    for c, value in enumerate(values):\n        {control}.setItem(r, c, QTableWidgetItem(str(value)))'),
    ],
    "Controls": [
        ("Read text of control", 'value = {control}.text().strip()\nif not value:\n    QMessageBox.warning(self, "Missing", "Please fill in this field.")\n    return'),
        ("Clear control", '{control}.clear()'),
        ("Enable / disable", '{control}.setEnabled(not {control}.isEnabled())'),
        ("Show / hide", '{control}.setVisible(not {control}.isVisible())'),
        ("Add item to list", '{control}.addItem("New item")'),
        ("Selected list item", 'item = {control}.currentItem()\nif item is not None:\n    print(item.text())'),
        ("Set progress value", '{control}.setValue(min({control}.maximum(), {control}.value() + 10))'),
        ("Focus control", '{control}.setFocus()'),
    ],
    "Application": [
        ("Status bar message", 'self.statusBar().showMessage("Ready", 3000)'),
        ("Run once after delay", 'QTimer.singleShot(1000, lambda: self.statusBar().showMessage("One second later", 2000))'),
        ("Open web page", 'QDesktopServices.openUrl(QUrl("https://www.python.org"))'),
        ("Copy to clipboard", 'QApplication.clipboard().setText("copied text")\nself.statusBar().showMessage("Copied", 2000)'),
        ("Close window", 'self.close()'),
        ("Current date and time", 'from datetime import datetime\nnow = datetime.now().strftime("%d-%m-%Y %H:%M")\n'
                                  'self.statusBar().showMessage(now, 3000)'),
        ("Try / except with message", 'try:\n    pass  # risky work\nexcept Exception as exc:\n'
                                      '    QMessageBox.critical(self, "Error", str(exc))'),
    ],
}


def render(code: str, control_name: str | None) -> str:
    target = f"self.{control_name}" if control_name else "self.widget"
    return code.replace("{control}", target)
