"""Schema-driven property inspector generated from ``PropertySpec`` lists."""
from __future__ import annotations

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (QCheckBox, QColorDialog, QComboBox, QDoubleSpinBox, QFontDialog, QFormLayout, QFrame,
                               QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit, QPushButton, QScrollArea, QSpinBox,
                               QToolButton, QVBoxLayout, QWidget)

from .registry import PropertySpec, valid_color

FORM_PROPERTIES = [
    PropertySpec("title", "Window title", "str", "My PySide6 App", group="Form"),
    PropertySpec("width", "Width", "int", 900, group="Form", minimum=200, maximum=8000),
    PropertySpec("height", "Height", "int", 600, group="Form", minimum=150, maximum=8000),
    PropertySpec("background", "Background", "color", "", group="Form"),
    PropertySpec("icon", "Window icon", "file", "", group="Form", tooltip="Image or .ico from the assets folder"),
]
GROUP_ORDER = ["Identity", "Form", "Layout", "Appearance", "Behaviour"]


class _Debounce:
    """Single-shot timer owned by the editor widget, so it can never fire after the widget is gone."""
    def __init__(self, ms, fn, owner, grid):
        self.grid = grid
        self.timer = QTimer(owner)
        self.timer.setSingleShot(True)
        self.timer.setInterval(ms)
        self.timer.timeout.connect(fn)

    def __call__(self, *a):
        if not self.grid._loading:      # ignore programmatic updates
            self.timer.start()


class ColorEditor(QWidget):
    changed = Signal(str)

    def __init__(self, value=""):
        super().__init__()
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(3)
        self.button = QPushButton()
        self.button.clicked.connect(self.pick)
        clear = QToolButton()
        clear.setText("×")
        clear.setToolTip("Use the default colour")
        clear.clicked.connect(lambda: self.set_value("", emit=True))
        lay.addWidget(self.button, 1)
        lay.addWidget(clear)
        self.value = ""
        self.set_value(value)

    def set_value(self, value, emit=False):
        self.value = valid_color(value)
        if self.value:
            text = "#000000" if QColor(self.value).lightness() > 140 else "#ffffff"
            self.button.setText(self.value)
            self.button.setStyleSheet(f"background:{self.value}; color:{text}; border:1px solid #94a3b8; border-radius:4px; padding:4px;")
        else:
            self.button.setText("(default)")
            self.button.setStyleSheet("")
        if emit:
            self.changed.emit(self.value)

    def pick(self):
        col = QColorDialog.getColor(QColor(self.value or "#ffffff"), self, "Choose colour",
                                    QColorDialog.ColorDialogOption.ShowAlphaChannel)
        if col.isValid():
            self.set_value(col.name(QColor.NameFormat.HexArgb if col.alpha() < 255 else QColor.NameFormat.HexRgb), emit=True)


class PropertyGrid(QScrollArea):
    """Shows the selected control's properties (or the form's when nothing is selected)."""
    propertyEdited = Signal(str, object)   # key, value
    formEdited = Signal(str, object)
    fontEdited = Signal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.asset_picker = None            # callable(parent) -> relative path or ""
        self._editors: dict[str, tuple] = {}
        self._loading = False
        self.control = None
        self.show_form({})

    # -- building ------------------------------------------------------------
    def _reset(self, title, subtitle=""):
        self._editors.clear()
        host = QWidget()
        self.vbox = QVBoxLayout(host)
        self.vbox.setContentsMargins(6, 6, 6, 6)
        self.vbox.setSpacing(6)
        head = QLabel(f"<b>{title}</b><br><span style='color:#64748b'>{subtitle}</span>")
        head.setWordWrap(True)
        self.vbox.addWidget(head)
        self.setWidget(host)

    def _section(self, name):
        label = QLabel(name.upper())
        label.setObjectName("propSection")
        label.setStyleSheet("QLabel#propSection { font-weight:700; color:#64748b; padding-top:6px; letter-spacing:1px; }")
        self.vbox.addWidget(label)
        form = QFormLayout()
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        form.setHorizontalSpacing(8)
        form.setVerticalSpacing(4)
        self.vbox.addLayout(form)
        return form

    def show_form(self, settings: dict):
        self.control = None
        self._reset("Form", "Nothing selected — editing the window itself")
        form = self._section("Form")
        for prop in FORM_PROPERTIES:
            self._add_editor(form, prop, settings.get(prop.key, prop.default), self.formEdited)
        hint = QLabel("Tip: Ctrl/Shift-click or drag a rectangle to select several controls. "
                      "Arrow keys nudge (Shift = grid, Alt = resize).")
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#64748b;")
        self.vbox.addWidget(hint)
        self.vbox.addStretch(1)

    def show_control(self, control, selection_count: int = 1):
        if control is None:
            return
        self.control = control
        spec = control.spec
        sub = f"{spec.qt_class} · {spec.category}"
        if selection_count > 1:
            sub += f"<br><b>{selection_count} controls selected</b> — edits apply to all that share the property"
        self._reset(f"{control.props.get('name')}  ({spec.kind})", sub)
        groups: dict[str, list[PropertySpec]] = {}
        for prop in spec.all_properties():
            groups.setdefault(prop.group or spec.kind, []).append(prop)
        order = {g: i for i, g in enumerate(GROUP_ORDER)}
        ordered = sorted(groups, key=lambda g: (order.get(g, 2.5 if g == spec.kind else 3), g))
        for group in ordered:
            form = self._section(group)
            for prop in groups[group]:
                self._add_editor(form, prop, control.props.get(prop.key, prop.default), self.propertyEdited)
        self.vbox.addStretch(1)

    def _add_editor(self, form, prop: PropertySpec, value, signal):
        emit = lambda v, k=prop.key, s=signal: None if self._loading else s.emit(k, v)
        t = prop.type
        if t == "bool":
            w = QCheckBox()
            w.setChecked(bool(value))
            w.toggled.connect(emit)
            setter = lambda v, w=w: w.setChecked(bool(v))
        elif t == "int":
            w = QSpinBox()
            w.setRange(int(max(prop.minimum, -2_000_000_000)), int(min(prop.maximum, 2_000_000_000)))
            w.setValue(int(value or 0))
            w.setKeyboardTracking(False)
            w.valueChanged.connect(emit)
            setter = lambda v, w=w: w.setValue(int(v or 0))
        elif t == "float":
            w = QDoubleSpinBox()
            w.setDecimals(4)
            w.setRange(prop.minimum, prop.maximum)
            w.setValue(float(value or 0))
            w.setKeyboardTracking(False)
            w.valueChanged.connect(emit)
            setter = lambda v, w=w: w.setValue(float(v or 0))
        elif t == "choice":
            w = QComboBox()
            w.addItems([str(c) for c in prop.choices])
            w.setCurrentText(str(value))
            w.currentTextChanged.connect(emit)
            setter = lambda v, w=w: w.setCurrentText(str(v))
        elif t == "color":
            w = ColorEditor(value)
            w.changed.connect(emit)
            setter = lambda v, w=w: w.set_value(v)
        elif t in ("text", "list"):
            w = QPlainTextEdit()
            w.setFont(QFont("Consolas", 9))
            w.setFixedHeight(72 if t == "list" else 84)
            w.setPlainText("\n".join(value) if t == "list" else str(value or ""))
            if t == "list":
                w.setPlaceholderText("One entry per line")
            deb = _Debounce(450, lambda w=w, t=t: emit(w.toPlainText().splitlines() if t == "list" else w.toPlainText()), w, self)
            w._debounce = deb
            w.textChanged.connect(deb)
            def setter(v, w=w, t=t):
                text = "\n".join(v or []) if t == "list" else str(v or "")
                if w.toPlainText() != text:
                    w.setPlainText(text)
        elif t in ("file", "font"):
            w = QWidget()
            lay = QHBoxLayout(w)
            lay.setContentsMargins(0, 0, 0, 0)
            lay.setSpacing(3)
            edit = QLineEdit(str(value or ""))
            edit.setPlaceholderText("(default)" if t == "font" else "assets/…")
            edit.editingFinished.connect(lambda e=edit: emit(e.text().strip()))
            btn = QToolButton()
            btn.setText("…")
            btn.clicked.connect(lambda checked=False, e=edit, t=t: self._browse(t, e, emit))
            lay.addWidget(edit, 1)
            lay.addWidget(btn)
            setter = lambda v, e=edit: e.setText(str(v or ""))
        else:
            w = QLineEdit(str(value or ""))
            w.editingFinished.connect(lambda w=w: emit(w.text()))
            setter = lambda v, w=w: w.setText(str(v or ""))
        if prop.tooltip:
            w.setToolTip(prop.tooltip)
        form.addRow(prop.label, w)
        self._editors[prop.key] = (w, setter)

    def _browse(self, kind, edit, emit):
        if kind == "font":
            current = QFont(edit.text() or self.font().family())
            if self.control is not None and int(self.control.props.get("font_size") or 0) > 0:
                current.setPointSize(int(self.control.props["font_size"]))
            font, ok = QFontDialog.getFont(current, self, "Choose font")
            if ok:
                edit.setText(font.family())
                self.fontEdited.emit({"font_family": font.family(), "font_size": font.pointSize(),
                                      "bold": font.bold(), "italic": font.italic()})
            return
        if callable(self.asset_picker):
            path = self.asset_picker(self)
            if path:
                edit.setText(path)
                emit(path)

    # -- live refresh ----------------------------------------------------------
    def refresh_values(self, values: dict):
        """Update editors in place (e.g. X/Y while dragging) without rebuilding."""
        self._loading = True
        try:
            for key, (widget, setter) in self._editors.items():
                if key in values and not widget.hasFocus():
                    setter(values[key])
        finally:
            self._loading = False
