from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication, QMessageBox

from . import __version__

ICON = Path(__file__).resolve().parent / "resources" / "waterpy.ico"


def main():
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    if sys.platform == "win32":  # own taskbar icon instead of python.exe's
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(f"WaterPyDesktop.IDE.{__version__}")
        except Exception:
            pass
    app = QApplication(sys.argv)
    app.setApplicationName("WaterPyDesktop")
    app.setOrganizationName("WaterPyDesktop")
    app.setApplicationVersion(__version__)
    app.setStyle("Fusion")
    from .main_window import MainWindow, glyph_icon
    app.setWindowIcon(QIcon(str(ICON)) if ICON.is_file() else glyph_icon("💧", "#0ea5e9", 32))
    window = MainWindow()
    window.show()
    arg = sys.argv[1] if len(sys.argv) > 1 else ""
    if arg.lower().endswith(".json"):
        window.open_project(arg)
    elif arg.lower().endswith((".wpplugin", ".zip")) and Path(arg).is_file():
        if QMessageBox.question(window, "Install plugin", f"Install the plugin package\n{arg}?") == QMessageBox.StandardButton.Yes:
            try:
                info = window.plugins.install(Path(arg), window)
                window.after_plugins_changed()
                QMessageBox.information(window, "Plugin installed", f"{info.name} {info.version}: {info.status}")
            except Exception as exc:
                QMessageBox.critical(window, "Install failed", str(exc))
    elif arg.lower().endswith(".ui") and Path(arg).is_file():
        from . import io_formats
        layout, warnings = io_formats.import_ui(arg)
        window.apply_layout(layout, confirm=False)
        for w in warnings:
            window.log(f"Import: {w}", "warning")
    raise SystemExit(app.exec())
